//
//  AppController.h
//  GoogleStreetView
//
//  Created by Matteo Bertozzi on 1/16/09.
//  Copyright 2009 Matteo Bertozzi. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <WebKit/WebKit.h>


@interface AppController : NSObject {
	IBOutlet NSTextField *statusLabel;
	IBOutlet NSTextField *textField;
	IBOutlet WebView *webView;
}

- (void)loadAddress:(NSString *)address;
- (IBAction)loadStreetView:(id)sender;

@end
