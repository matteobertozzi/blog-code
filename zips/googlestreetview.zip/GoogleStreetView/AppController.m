//
//  AppController.m
//  GoogleStreetView
//
//  Created by Matteo Bertozzi on 1/16/09.
//  Copyright 2009 Matteo Bertozzi. All rights reserved.
//

#import "AppController.h"


@implementation AppController

- (void)awakeFromNib {
	NSFileManager *fileManager = [NSFileManager defaultManager];
	NSString *path = [[NSBundle mainBundle] pathForResource:@"StreetView" ofType:@"html"];
	NSData *data = [fileManager contentsAtPath:path];
	NSString *htmlString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
	[[webView mainFrame] loadHTMLString:htmlString baseURL:nil];
}

- (void)webView:(WebView *)sender runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WebFrame *)frame 
{
	if ([message hasPrefix:@"/StreetView/"] == YES) {
		[statusLabel setStringValue:[message substringFromIndex:12]];
	}
}

- (void)webView:(WebView *)sender didFinishLoadForFrame:(WebFrame *)frame
{
	[self loadAddress:@"San Francisco, Golden Gate Bridge"];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)app {
	return YES;
}

- (void)loadAddress:(NSString *)address {
	[textField setStringValue:address];
	
	NSArray *args = [NSArray arrayWithObjects:address, nil];
	[[webView windowScriptObject] callWebScriptMethod:@"showAddress" withArguments:args];	
}

- (IBAction)loadStreetView:(id)sender {
	[self loadAddress:[textField stringValue]];
}

@end
