//
//  AppController.m
//  Filterbar
//
//  Created by Matteo Bertozzi on 11/9/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "AppController.h"


@implementation AppController

- (void)awakeFromNib {
	[filterBar addLabel:@"Test Label 1"];
	[filterBar addSeparator];
	[filterBar addGroup:@"Group1"];
	[filterBar addSeparator];
	[filterBar addLabel:@"Test Label 2"];
	[filterBar addImage:[NSImage imageNamed:NSImageNameUser]];
	[filterBar insertImage:[NSImage imageNamed:NSImageNameComputer] atIndex:0];
	[filterBar addSeparator];
	[filterBar addGroup:@"Group2"];
	[filterBar addSeparator];
	[filterBar addLabel:@"Test Label 3"];

	[filterBar selectItem:@"C" inGroup:@"Group2" selected:YES];
	[filterBar selectItems:[NSArray arrayWithObjects:@"Item3", @"Item1", nil] inGroup:@"Group1" selected:YES];
}

- (NSArray *)filterbar:(Filterbar *)filterBar
		itemIdentifiersForGroup:(NSString *)groupIdentifier
{
	if (groupIdentifier == @"Group1")
		return [NSArray arrayWithObjects:@"Item1", @"Item2", @"Item3", nil];
	return [NSArray arrayWithObjects:@"A", @"B", @"C", @"D", nil];
}

- (NSString *)filterbar:(Filterbar *)filterBar
				labelForItemIdentifier:(NSString *)itemIdentifier
				groupIdentifier:(NSString *)groupIdentifier
{
	return itemIdentifier;
}

- (NSImage *)filterbar:(Filterbar *)filterBar
				imageForItemIdentifier:(NSString *)itemIdentifier
				groupIdentifier:(NSString *)groupIdentifier
{
	return nil;
}

- (BOOL)filterbar:(Filterbar *)filterBar
			hasMultipleSelection:(NSString *)groupIdentifier
{
	return (groupIdentifier == @"Group1");
}

- (void)filterbar:(Filterbar *)filterBar
			selectedStateChanged:(BOOL)selected
			fromItem:(NSString *)itemIdentifier
			groupIdentifier:(NSString *)groupIdentifier
{
	NSString *toDisplay = [NSString stringWithFormat:@"\"%@\" %@ in group %@.", 
							   itemIdentifier, 
							   (selected) ? @"Selected" : @"Deselected", 
							   groupIdentifier];
	[bodyText setStringValue:toDisplay];
}

- (BOOL)windowShouldClose:(id)window {
	return YES;
}
@end
