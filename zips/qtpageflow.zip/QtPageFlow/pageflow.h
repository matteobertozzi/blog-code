#ifndef _PAGEFLOW_H_
#define _PAGEFLOW_H_

#include <QWidget>

class THPageFlowPrivate;

class THPageFlow : public QWidget {
	Q_OBJECT

	public:
		THPageFlow (QWidget *parent = 0);
		~THPageFlow();

		void addItem (	const QImage& image,
						const QString& title = QString(),
						const QString& info = QString());

	public Q_SLOTS:		
		void showNext (void);
		void showPrevious (void);

	protected:
		void paintEvent (QPaintEvent *event);

		void mouseReleaseEvent (QMouseEvent *event);
		void mousePressEvent (QMouseEvent *event);
		void mouseMoveEvent (QMouseEvent *event);

	private:
		void drawSelectedItem (QPainter *painter);
		void drawItemsAfterSelected (QPainter *painter);
		void drawItemsBeforeSelected (QPainter *painter);

		void drawItem (QPainter *painter, int x, int y, const QImage *image);
		void drawOpaqueItem (QPainter *painter, int x, int y, const QImage *image);
		void drawPagesIndex (QPainter *painter);

	private:
		THPageFlowPrivate *d;
};

#endif /* !_PAGEFLOW_H_ */

