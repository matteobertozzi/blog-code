#include <cmath>

#include <QPaintEvent>
#include <QMouseEvent>
#include <QPainter>

#include "pageflow.h"

/* ============================================================================
 *  PRIVATE Consts
 */
#define SWIPE_AREA			125
#define ITEM_SPACE			40
#define ITEM_WIDTH			195
#define ITEM_HEIGHT			250
#define ITEM_SHADOW			20
#define ITEM_OPACITY		100
#define ITEM_SPACED_WIDTH	(ITEM_WIDTH + ITEM_SPACE)

/* ============================================================================
 *  PUBLIC THPageFlow Item Class
 */
class THPageFlowItem {
	public:
		THPageFlowItem (	const QImage& image, 
							const QString& title = QString(),
							const QString& info = QString());
		~THPageFlowItem();

		const QImage *image (void) const;
		const QString& info (void) const;
		const QString& title (void) const;

	private:
		QString m_title;
		QString m_info;
		QImage m_image;
};

THPageFlowItem::THPageFlowItem (const QImage& image, 
								const QString& title,
								const QString& info)
{
	m_info = info;
	m_title = title;
	m_image = image;
}

THPageFlowItem::~THPageFlowItem() {
}

const QImage *THPageFlowItem::image (void) const {
	return(&m_image);
}

const QString& THPageFlowItem::info (void) const {
	return(m_info);
}

const QString& THPageFlowItem::title (void) const {
	return(m_title);
}

/* ============================================================================
 *  PRIVATE Class
 */
class THPageFlowPrivate {
	public:
		QList<THPageFlowItem> items;
		int selected;

		int startSwipeX;
		bool startSwipe;

	public:
		const QImage *itemImage (int index);
};

const QImage *THPageFlowPrivate::itemImage (int index) {
	return(items.at(index).image());
}

/* ============================================================================
 *  PUBLIC Constructor/Destructor
 */
THPageFlow::THPageFlow (QWidget *parent)
	: QWidget(parent), d(new THPageFlowPrivate)
{
	d->selected = 0;
}

THPageFlow::~THPageFlow() {
	delete d;
}

/* ============================================================================
 *  PUBLIC Methods
 */
void THPageFlow::addItem (	const QImage& image,
							const QString& title,
							const QString& info)
{
	d->items.append(THPageFlowItem(image, title, info));
}

/* ============================================================================
 *  PUBLIC Slots
 */
void THPageFlow::showNext (void) {
	if ((d->selected + 1) < d->items.size()) {
		d->selected++;
		update();
	}
}

void THPageFlow::showPrevious (void) {
	if (d->selected > 0) {
		d->selected--;
		update();
	}
}


/* ============================================================================
 *  PROTECTED Methods
 */
void THPageFlow::paintEvent (QPaintEvent *event) {
	QPainter p(this);

	// Draw Background
	QLinearGradient gradient(0, 0, 0, height());
	gradient.setColorAt(0.0, QColor(0xa6, 0xb1, 0xba));
	gradient.setColorAt(1.0, QColor(0x69, 0x7c, 0x8c));
	p.setClipRect(event->rect());
	p.fillRect(rect(), gradient);

	// Set Painter Features
	p.setRenderHint(QPainter::SmoothPixmapTransform);
	p.setRenderHint(QPainter::Antialiasing);

	// Draw Items
	if (d->items.size() > 0) {
		drawItemsBeforeSelected(&p);
		drawItemsAfterSelected(&p);
		drawSelectedItem(&p);
		drawPagesIndex(&p);
	}

	p.end();
}

/* ============================================================================
 *  PROTECTED Methods (Mouse Events, Swipe)
 */
void THPageFlow::mouseReleaseEvent (QMouseEvent *event) {
	Q_UNUSED(event)
	d->startSwipe = false;
}

void THPageFlow::mousePressEvent (QMouseEvent *event) {
	d->startSwipeX = event->x();
	d->startSwipe = true;
}

void THPageFlow::mouseMoveEvent (QMouseEvent *event) {
	int dx = event->x() - d->startSwipeX;
	if (d->startSwipe && qAbs(dx) > SWIPE_AREA) {
		d->startSwipe = false;

		if (dx > 0)
			showPrevious();
		else
			showNext();
	}
}

/* ============================================================================
 *  PRIVATE Methods
 */
void THPageFlow::drawSelectedItem (QPainter *painter) {
	const THPageFlowItem& item = d->items.at(d->selected);
	const QImage *img = d->itemImage(d->selected);

	int cw = width() / 2;
	int wh = height();
	int ch = wh / 2;
	int h = img->height();
	int w = img->width();

	// Draw Image
	drawItem(painter, cw - w / 2, ch - h / 2, img);

	painter->save();
	painter->setPen(Qt::white);

	// Draw Title
	painter->setFont(QFont(painter->font().family(), 18, QFont::Bold));
	int titleWidth = painter->fontMetrics().width(item.title());
	painter->drawText(cw - titleWidth / 2, 35, item.title());

	// Draw Notes
	painter->setPen(QColor(0xd2, 0xd6, 0xdb));
	painter->setFont(QFont(painter->font().family(), 11, QFont::Bold));
	int notesWidth = painter->fontMetrics().width(item.info());
	painter->drawText(cw - notesWidth / 2, 55, item.info());

	painter->restore();
}

void THPageFlow::drawItemsAfterSelected (QPainter *painter) {
	const QImage *imgSelected = d->itemImage(d->selected);

	int winWidth = width();
	QPoint ptSelected(	(winWidth / 2) + (imgSelected->width() / 2),
						(height() / 2) - (imgSelected->height() / 2));

	int widthAvail = winWidth - ptSelected.x();
	int endIdx = ceil((qreal)widthAvail / ITEM_SPACED_WIDTH);
	int availItems = d->items.size() - (d->selected + 1);
	if (endIdx > availItems) endIdx = availItems;

	for (int i = 0, idx = d->selected + 1; i < endIdx; ++i, ++idx) {
		const QImage *img = d->itemImage(idx);

		int x = ptSelected.x() + ITEM_SPACE + (i * ITEM_SPACED_WIDTH);
		drawOpaqueItem(painter, x, ptSelected.y(), img);
	}
}

void THPageFlow::drawItemsBeforeSelected (QPainter *painter) {
	const QImage *imgSelected = d->itemImage(d->selected);

	QPoint ptSelected(	(width() / 2) - (imgSelected->width() / 2),
						(height() / 2) - (imgSelected->height() / 2));

	int widthAvail = ptSelected.x();
	int startIdx = d->selected - ceil((qreal)widthAvail / ITEM_SPACED_WIDTH);
	if (startIdx < 0) startIdx = 0;

	for (int i = 0, idx = startIdx; idx < d->selected; ++i, ++idx) {
		const QImage *img = d->itemImage(idx);

		int x = widthAvail - ((i + 1) * ITEM_SPACED_WIDTH);
		drawOpaqueItem(painter, x, ptSelected.y(), img);
	}
}

void THPageFlow::drawItem (QPainter *painter, int x, int y, const QImage *image) {
	QColor shadowColor(0x00, 0x00, 0x00, ITEM_SHADOW);
	painter->fillRect(x + 3, y + 3, ITEM_WIDTH, ITEM_HEIGHT, shadowColor);
	painter->fillRect(x + 4, y + 3, ITEM_WIDTH, ITEM_HEIGHT, shadowColor);
	painter->fillRect(x + 3, y + 4, ITEM_WIDTH, ITEM_HEIGHT, shadowColor);
	painter->fillRect(x + 3, y + 3, ITEM_WIDTH, ITEM_HEIGHT, shadowColor);
	painter->drawImage(x, y, *image);
}

void THPageFlow::drawOpaqueItem (QPainter *painter, int x, int y, const QImage *image) {
	drawItem(painter, x, y, image);

	QColor shadowColor(0x00, 0x00, 0x00, ITEM_OPACITY);
	painter->fillRect(x, y, ITEM_WIDTH, ITEM_HEIGHT, shadowColor);
}

void THPageFlow::drawPagesIndex (QPainter *painter) {
	int itemCount = d->items.size();
	int idxWidth = (itemCount * 16) - 10;
	int x = width() / 2 - idxWidth / 2;
	int y = height() - 35;

	painter->save();
	painter->setPen(Qt::NoPen);
	QColor unselectColor(0x9d, 0xa9, 0xb3);
	for (int i = 0; i < itemCount; ++i) {
		painter->setBrush((i == d->selected) ? Qt::white : unselectColor);
		painter->drawEllipse(x, y, 6, 6);
		x += 10;
	}
	painter->restore();
}

