#include <QApplication>
#include "pageflow.h"

int main (int argc, char **argv) {
	QApplication app(argc, argv);

	THPageFlow flow;
	flow.addItem(QImage("pics/macpro.png"), 
				 "MacPro", "http://www.apple.com/macpro");
	flow.addItem(QImage("pics/iphone.png"), 
				 "iPhone", "http://www.apple.com/iphone");
	flow.addItem(QImage("pics/mac-wwdc.png"), 
				 "Mac WWDC", "http://developer.apple.com/wwdc/mac");
	flow.addItem(QImage("pics/iphone-wwdc.png"), 
				 "iPhone WWDC", "http://developer.apple.com/wwdc/iphone");
	flow.addItem(QImage("pics/displays.png"), 
				 "Displays", "http://www.apple.com/displays");
	flow.resize(520, 390);
	flow.show();

	return(app.exec());
}

