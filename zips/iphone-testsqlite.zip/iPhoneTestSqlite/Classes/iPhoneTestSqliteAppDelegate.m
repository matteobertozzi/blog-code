//
//  iPhoneTestSqliteAppDelegate.m
//  iPhoneTestSqlite
//
//  Created by Matteo Bertozzi on 11/22/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import "iPhoneTestSqliteAppDelegate.h"
#import "Sqlite.h"

@implementation iPhoneTestSqliteAppDelegate

@synthesize window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    

    // Override point for customization after application launch
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [window release];
    [super dealloc];
}

- (IBAction)clickMe:(id)sender {
	Sqlite *sqlite = [[Sqlite alloc] init];

    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *writableDBPath = [documentsDirectory stringByAppendingPathComponent:@"SQLiteTest.db"];
	if (![sqlite open:writableDBPath])
		return;

	[sqlite executeNonQuery:@"DROP TABLE test"];
	[sqlite executeNonQuery:@"CREATE TABLE test (key TEXT NOT NULL, num INTEGER, value TEXT);"];
	[sqlite executeNonQuery:@"DELETE FROM test;"];
	[sqlite executeNonQuery:@"INSERT INTO test VALUES (?, ?, ?);", [Sqlite createUuid], [NSNumber numberWithInt:2], @"PROVA"];
	[sqlite executeNonQuery:@"INSERT INTO test VALUES (?, ?, ?);", [Sqlite createUuid], [NSNumber numberWithInt:3], @"PROVA 2"];
	[sqlite executeNonQuery:@"INSERT INTO test VALUES (?, ?, ?);", [Sqlite createUuid], [NSNull null], [NSNull null]];
	
	NSArray *results = [sqlite executeQuery:@"SELECT * FROM test;"];
	NSMutableString *text = [[NSMutableString alloc] init];
	for (NSDictionary *dictionary in results) {
		[text appendFormat:@"Row\n"];
		for (NSString *key in [dictionary keyEnumerator])
			[text appendFormat:@" - %@ %@\n", key, [dictionary objectForKey:key]];
	}
	[textView setText:text];
	
	[results release];
	[sqlite release];
}

@end
