//
//  iPhoneTestSqliteAppDelegate.h
//  iPhoneTestSqlite
//
//  Created by Matteo Bertozzi on 11/22/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface iPhoneTestSqliteAppDelegate : NSObject <UIApplicationDelegate> {
	IBOutlet UITextView *textView;
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

- (IBAction)clickMe:(id)sender;

@end

