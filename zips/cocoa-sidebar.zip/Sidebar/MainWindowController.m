//
//  MainWindowController.m
//  Tahsis
//
//  Created by Matteo Bertozzi on 11/30/08.
//  Copyright 2008 Matteo Bertozzi. All rights reserved.
//

#import "MainWindowController.h"
#import "SidebarNode.h"

@implementation MainWindowController

- (void)awakeFromNib {
	[NSThread detachNewThreadSelector:@selector(populateOutlineContents:) toTarget:self withObject:nil];
}

- (float)splitView:(NSSplitView *)splitView constrainMinCoordinate:(float)proposedCoordinate ofSubviewAt:(int)index
{
	return proposedCoordinate + 210;
}

- (void)splitView:(NSSplitView*)sender resizeSubviewsWithOldSize:(NSSize)oldSize
{
	NSRect newFrame = [sender frame]; // get the new size of the whole splitView
	NSView *left = [[sender subviews] objectAtIndex:0];
	NSRect leftFrame = [left frame];
	NSView *right = [[sender subviews] objectAtIndex:1];
	NSRect rightFrame = [right frame];
 
	CGFloat dividerThickness = [sender dividerThickness];
	  
	leftFrame.size.height = newFrame.size.height;

	rightFrame.size.width = newFrame.size.width - leftFrame.size.width - dividerThickness;
	rightFrame.size.height = newFrame.size.height;
	rightFrame.origin.x = leftFrame.size.width + dividerThickness;

	[left setFrame:leftFrame];
	[right setFrame:rightFrame];
}

- (void)populateOutlineContents:(id)inObject {
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];

	[sidebar addRootFolder:@"1" name:@"DEVICES"];
	[sidebar addChild:@"1.1" name:@"Machintosh HD" icon:[NSImage imageNamed:NSImageNameComputer] action:@selector(buttonPres:) target:self];
	[sidebar addChild:@"1.2" name:@"Network" icon:[NSImage imageNamed:NSImageNameNetwork] action:@selector(buttonPres:) target:self];

	[sidebar addRootFolder:@"2" name:@"PLACES"];
	[sidebar addChild:@"2.1" url:NSHomeDirectory() action:@selector(buttonPres:) target:self];
	[sidebar addChild:@"2.2" url:[NSHomeDirectory() stringByAppendingPathComponent:@"Desktop"] action:@selector(buttonPres:) target:self];
	[sidebar addChild:@"2.3" url:[NSHomeDirectory() stringByAppendingPathComponent:@"Pictures"] action:@selector(buttonPres:) target:self];
	[sidebar addChild:@"2.4" url:[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] action:@selector(buttonPres:) target:self];
	[sidebar addChild:@"2.5" url:@"/Applications" action:@selector(buttonPres:) target:self];
	[sidebar addChild:@"2.6" url:NSHomeDirectory() action:@selector(buttonPres:) target:self];
	[sidebar addChild:@"2.7" url:[NSHomeDirectory() stringByAppendingPathComponent:@"Desktop"] action:@selector(buttonPres:) target:self];
	[sidebar addChild:@"2.8" url:[NSHomeDirectory() stringByAppendingPathComponent:@"Pictures"] action:@selector(buttonPres:) target:self];
	[sidebar addChild:@"2.9" url:[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] action:@selector(buttonPres:) target:self];
	[sidebar addChild:@"2.10" url:@"/Applications" action:@selector(buttonPres:) target:self];
	
	[sidebar addRootFolder:@"3" name:@"OTHER."];
	[sidebar addChild:@"3.1" name:@"Bonjour" icon:[NSImage imageNamed:NSImageNameBonjour] action:@selector(buttonPres:) target:self];
	[sidebar addChild:@"3.2" name:@"Mobile Me" icon:[NSImage imageNamed:NSImageNameDotMac] action:@selector(buttonPres:) target:self];
	[sidebar addChild:@"3.3" name:@"Users" icon:[NSImage imageNamed:NSImageNameUserGroup] action:@selector(buttonPres:) target:self];
	[sidebar addChild:@"3.4" name:@"Bonjour" icon:[NSImage imageNamed:NSImageNameBonjour] action:@selector(buttonPres:) target:self];
	[sidebar addChild:@"3.5" name:@"Mobile Me" icon:[NSImage imageNamed:NSImageNameDotMac] action:@selector(buttonPres:) target:self];
	[sidebar addChild:@"3.6" name:@"Users" icon:[NSImage imageNamed:NSImageNameUserGroup] action:@selector(buttonPres:) target:self];
		
	[sidebar clearSelection];

	[sidebar setBadge:@"2.2" count:5];
	[sidebar setBadge:@"3" count:3];
	[sidebar setBadge:@"3.1" count:4];
	
	[pool release];
}

- (void)buttonPres:(id)sender {
	NSLog(@"Button Press %@", [sender nodeTitle]);
}

@end
