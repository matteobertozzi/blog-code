/*
* Copyright (C) 2009 Matteo Bertozzi.
*
* This file is part of THLibrary.
*
* THLibrary is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* THLibrary is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with THLibrary. If not, see <http://www.gnu.org/licenses/>.
*/

#include <QApplication>

#include "GKMapView.h"

int main (int argc, char **argv) {
    QApplication app(argc, argv);

    GKMapView mapView;
    QObject::connect(&mapView, SIGNAL(destroyed()), &app, SLOT(quit()));
    mapView.resize(580, 410);
    mapView.setMapType(GKMapTypeSatellite);
    mapView.locationFromAddress("San Mateo");
    mapView.addressFromLocation(32.718834, -117.164);
    mapView.addMarkerWithWindow("Bedford MA Marker", "<b>Bedford MA</b> Marker", "Bedford MA");
    mapView.addInfoWindow("Hello from <b>San Mateo</b>", "San Mateo");
    mapView.addInfoWindow("Hello from <b>San Diego</b>", 32.718834, -117.164);
    //mapView.setLocation("Mesa, AZ");
    mapView.show();

    return(app.exec());
}

