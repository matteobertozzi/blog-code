/* 
 * Copyright (C) 2009 Matteo Bertozzi.
 *
 * Qt Jump Away is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Qt Jump Away is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Qt Jump Away.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <QDesktopWidget>
#include <QApplication>

#include "jumpy.h"

#define JUMPY_WINSIZE(screenSize)		((screenSize) / 2)

int main (int argc, char **argv) {
	QApplication app(argc, argv);
	
	QWidget *screen = app.desktop()->screen();
	
	THJumpy w(QPixmap::grabWindow(QApplication::desktop()->winId()));

	if (app.arguments().contains("-fullscreen")) {
		w.resize(screen->size());
		w.setWindowState(w.windowState() ^ Qt::WindowFullScreen);
	} else {
		w.resize(JUMPY_WINSIZE(screen->size()));
	}

	w.show();
	
	return(app.exec());
}
