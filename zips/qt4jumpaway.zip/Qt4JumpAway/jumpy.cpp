/* 
 * Copyright (C) 2009 Matteo Bertozzi.
 *
 * Qt Jump Away is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Qt Jump Away is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Qt Jump Away.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <QApplication>
#include <QPaintEvent>
#include <QTimeLine>
#include <QPainter>
#include <QTimer>

#include "jumpy.h"

/* ============================================================================
 *  PRIVATE Consts
 */
#define ANIMATION_DURATION	(4000)
#define CLOSE_TIMEOUT		(1500)

/* ============================================================================
 *  PRIVATE Methods
 */
static QPixmap mirrorImage (const QImage& image) {
	QImage tmpImage = image.mirrored(false, true);

	QPoint p1, p2;
	p2.setY(tmpImage.height());

	QLinearGradient gradient(p1, p2);
	gradient.setColorAt(0, QColor(0, 0, 0, 100));
	gradient.setColorAt(1, Qt::transparent);

	QPainter p(&tmpImage);
	p.setCompositionMode(QPainter::CompositionMode_DestinationIn);
	p.fillRect(0, 0, tmpImage.width(), tmpImage.height(), gradient);
	p.end();

	QImage finalImage(	tmpImage.width(), tmpImage.height() * 2,
						QImage::Format_ARGB32_Premultiplied);
	p.begin(&finalImage);
	p.drawImage(0, 0, image);
	p.drawImage(0, image.height(), tmpImage);
	p.end();

	return(QPixmap::fromImage(finalImage));
}

/* ============================================================================
 *  PRIVATE Class
 */
class THJumpyPrivate {
	public:
		QTimeLine *timeLine;
		QPainterPath path;
		QPixmap pixmap;
		qreal perc;
	
	public:
		void initObject (void);
};

/* ============================================================================
 *  PUBLIC Constructors
 */
THJumpy::THJumpy (const QPixmap& pixmap, QWidget *parent)
	: QWidget(parent), d(new THJumpyPrivate)
{
	d->perc = 1.0;
	d->pixmap = pixmap;
	
	QTimer::singleShot(0, this, SLOT(initObject()));
}

THJumpy::~THJumpy() {
	delete d;
}

/* ============================================================================
 *  PROTECTED Methods
 */
void THJumpy::paintEvent (QPaintEvent *event) {
	QPainter p(this);
	p.setRenderHint(QPainter::SmoothPixmapTransform);

	// Draw Window Background
	p.fillRect(event->rect(), Qt::black);

	// Setup Jump Away Image Scale
	QSize winSize = geometry().size() / 2;
	QTransform transform;
	transform.translate(winSize.width(), winSize.height());
	transform.scale(d->perc, d->perc);
	transform.translate(-winSize.width(), -winSize.height());

	// Draw Jump Away Image
	p.setOpacity(d->perc);
	p.setTransform(transform, false);
	p.drawPixmap(d->path.pointAtPercent(1.0 - d->perc) - 
				 QPoint(0, winSize.height()), d->pixmap);
	
	p.end();
}

/* ============================================================================
 *  PRIVATE SLOTS
 */
void THJumpy::initObject (void) {
	QSize winSize = geometry().size();
	qreal x = 0;
	qreal y = winSize.height() / 2;
	
	// Setup Path
	d->path.moveTo(x, y);
	d->path.quadTo(x, y, x, y);
	d->path.quadTo(x, y / 2, x, y);
	d->path.quadTo(x, y / 6, x, y);
	d->path.quadTo(x, y / 24, x, y);
	d->path.quadTo(x, - y * 2, x, y);
	
	// Setup Jump Away Image
	d->pixmap = mirrorImage(d->pixmap.scaled(winSize, 
				 			Qt::IgnoreAspectRatio, 
							Qt::SmoothTransformation).toImage());
	update();
	
	// Setup Animation Timeline
	d->timeLine = new QTimeLine(ANIMATION_DURATION, this);
	d->timeLine->setCurveShape(QTimeLine::EaseInCurve);
	d->timeLine->setFrameRange(0, 100);
	connect(d->timeLine, SIGNAL(frameChanged(int)), 
			this, SLOT(frameChanged(int)));
	connect(d->timeLine, SIGNAL(finished()), this, SLOT(finished()));
	d->timeLine->start();
}

void THJumpy::frameChanged (int frame) {
	int revFrame = d->timeLine->endFrame() - frame;
	d->perc = qreal(revFrame) / 100;
	update();
}

void THJumpy::finished (void) {
	QTimer::singleShot(CLOSE_TIMEOUT, qApp, SLOT(quit()));
}

