#include "vector2d.h"

void gdVector2dCopy (GDVector2d *dst, const GDVector2d *src) {
    dst->x = src->x;
    dst->y = src->y;
}

