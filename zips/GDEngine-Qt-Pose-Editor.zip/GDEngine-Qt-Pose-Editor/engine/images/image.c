#include "imagepool.h"
#include "object.h"
#include "macros.h"
#include "alloc.h"
#include "image.h"

static void gdImageDataInit (GDImageData *image) {
    image->height = 0;
    image->width = 0;
    image->blob = NULL;
    image->size = 0;
}

static void gdImageDataCopy (GDImageData *dst, const GDImageData *src) {
    dst->height = src->height;
    dst->width = src->width;

    dst->blob = gdAllocArray(GDByte, dst->size);
    memcpy(dst->blob, src->blob, dst->size);
}

static void gdImageDataRelease (GDImageData *image) {
    if (image->blob != NULL)
        gdZFree(&(image->blob));
}

GDBool gdImageFormatIsCompressed (GDImageFormat format) {
    switch (format) {
        case GD_IMAGE_FORMAT_RGB:
        case GD_IMAGE_FORMAT_RGBA:
            return(GD_FALSE);
        case GD_IMAGE_FORMAT_DXT1:
        case GD_IMAGE_FORMAT_DXT2:
        case GD_IMAGE_FORMAT_DXT5:
        case GD_IMAGE_FORMAT_RGB_PVR2:
        case GD_IMAGE_FORMAT_RGB_PVR4:
        case GD_IMAGE_FORMAT_RGBA_PVR2:
        case GD_IMAGE_FORMAT_RGBA_PVR4:
            return(GD_TRUE);
        default:
            break;
    }
    return(GD_FALSE);
}

GDImage *gdImageInit (GDImage *image) {
    image = _gdObjectInit(GDImage, image);
    gdReturnValueIfNull(image, NULL);

    gdImageDataInit(&(image->data));
    image->format = GD_IMAGE_FORMAT_UNKNOWN;
    image->name = NULL;

    image->nMipMaps = 0;
    image->mipMaps = NULL;

    image->id = 0;
    return(image);
}

GDImage *gdImageRetain (GDImage *image) {
    _gdObjectRetain(gdObject(image));
    return(image);
}

void gdImageRelease (GDImage *image) {
    if (!_gdObjectRelease(gdObject(image)))
        return;

    gdImagePoolRemove(image);

    gdImageDataRelease(&(image->data));
    if (image->mipMaps != NULL) {
        GDUInt i;

        for (i = 0; i < image->nMipMaps; ++i)
            gdImageDataRelease(&(image->mipMaps[i]));
        image->nMipMaps = 0;
    }

    if (image->name != NULL)
        gdZFree(&(image->name));

    if (_gdObjectInternalAlloc(image))
        gdFree(image);
}

GDBool gdImageInitMipMaps (GDImage *image, GDUInt nMipMaps) {
    GDUInt i;

    if ((image->nMipMaps = nMipMaps) < 1)
        return(GD_TRUE);

    /* Alloc MipMaps array */
    image->mipMaps = gdAllocArray(GDImageData, nMipMaps);
    gdReturnValueIfNull(image->mipMaps, GD_FALSE);

    for (i = 0; i < nMipMaps; ++i)
        gdImageDataInit(&(image->mipMaps[i]));

    return(GD_TRUE);
}

GDImage *gdImageCopy (GDImage *dst, const GDImage *src) {
    dst->format = src->format;
    dst->name = strdup(src->name);
    gdImageDataCopy(&(dst->data), &(src->data));

    if ((dst->nMipMaps = src->nMipMaps) > 0) {
        GDUInt i;

        dst->mipMaps = gdAllocArray(GDImageData, dst->nMipMaps);
        for (i = 0; i < dst->nMipMaps; ++i)
            gdImageDataCopy(&(dst->mipMaps[i]), &(src->mipMaps[i]));
    }

    return(dst);
}

void gdImageSetName (GDImage *image, const char *name) {    
    if (image->name == NULL)
        image->name = strdup(name);
}

void gdImageSetFormat (GDImage *image, GDImageFormat format) {
    image->format = format;
}

void gdImageSetSize (GDImage *image, GDUInt width, GDUInt height) {
    image->data.height = height;
    image->data.width = width;
}

void gdImageSetData (GDImage *image, GDByte *data, GDUInt size) {
    image->data.blob = data;
    image->data.size = size;
}

void gdImageSetMipMapSize (GDImage *image, GDUInt level,
                           GDUInt width, GDUInt height)
{
    GDImageData *mipMap;

    mipMap = (level > 0) ? &(image->mipMaps[level-1]) : &(image->data);
    mipMap->height = height;
    mipMap->width = width;
}

void gdImageSetMipMapData (GDImage *image, GDUInt level,
                           GDByte *data, GDUInt size)
{
    GDImageData *mipMap;

    mipMap = (level > 0) ? &(image->mipMaps[level-1]) : &(image->data);
    mipMap->blob = data;
    mipMap->size = size;
}

