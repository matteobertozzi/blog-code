#include "imagereader.h"
#include "macros.h"
#include "alloc.h"

GDImagePlugin __image_dds = {
    .name = "DDS",
    .isFormat = NULL,
    .readImage = NULL,
};
