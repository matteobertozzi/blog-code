#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <errno.h>
#include <stdio.h>

#include "debug.h"

void __gdWarningSysFail (const char *file, unsigned int line, const char *func,
                         const char *format, ...)
{
    va_list arg_list;

    fprintf(stderr, "%s %u: %s - ", file, line, func);

    va_start(arg_list, format);
    vfprintf(stderr, format, arg_list);
    va_end(arg_list);

    fprintf(stderr, ": %s\n", strerror(errno));
}


void __gdAssert (const char *file, unsigned int line, const char *func,
                 int expr, const char *expression,
                 const char *format, ...)
{
    va_list arg_list;

    if (expr)
        return;

    fprintf(stderr, "%s %u: %s - ", file, line, func);
    fprintf(stderr, "Assert (%s) = %d - ", expression, expr);

    va_start(arg_list, format);
    vfprintf(stderr, format, arg_list);
    va_end(arg_list);

    fprintf(stderr, ": %s\n", strerror(errno));
    abort();
}

