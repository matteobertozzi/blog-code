#include "particle.h"
#include "macros.h"
#include "alloc.h"

GDParticle *gdParticleInit (GDParticle *particle,
                            const GDVector3d *position,
                            const GDVector3d *direction)
{
    particle = _gdObjectInit(GDParticle, particle);
    gdReturnValueIfNull(particle, NULL);

    gdVector3dCopy(&(particle->position), position);
    gdVector3dNormalized(&(particle->direction), direction);
    particle->speed = 1.0f;
    particle->mass = 1.0f;
    particle->age = 0.0f;
    particle->lifetime = 1.0f;
    
    return(particle);
}

GDParticle *gdParticleRetain (GDParticle *particle) {
    _gdObjectRetain(gdObject(particle));
    return(particle);
}

void gdParticleRelease (GDParticle *particle) {
    if (!_gdObjectRelease(gdObject(particle)))
        return;

    if (_gdObjectInternalAlloc(particle))
        gdFree(particle);
}

GDBool gdParticleUpdate (GDParticle *particle) {
    if (particle->age == particle->lifetime)
        return(GD_FALSE);
    
    particle->position.x += particle->direction.x * particle->speed;
    particle->position.y += particle->direction.y * particle->speed;
    particle->position.z += particle->direction.z * particle->speed;
    particle->age += 0.1f;
    
    return(GD_TRUE);
}
