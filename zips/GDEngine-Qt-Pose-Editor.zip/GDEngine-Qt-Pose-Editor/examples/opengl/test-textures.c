#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include <GDEngine/OpenGL.h>

#include <GDEngine/ModelReader.h>
#include <GDEngine/ImageReader.h>
#include <GDEngine/Particle.h>
#include <GDEngine/Camera.h>
#include <GDEngine/Maths.h>
#include <GDEngine/Alloc.h>

#define NUM_PARTICLES                 (500)

#define ANIMATION_TIMEOUT             (250)
#define CAMERA2_TRANSLATION_STEP      (1.0f)
#define CAMERA2_ROTATION_STEP         (1.0f)

typedef struct {
    unsigned int frame;
    int timebase;
    char fps[16];
    
    GLuint tex[2];

    GLfloat tx, ty, tz;
    GLfloat rx, ry, rz;
} AppContext;

static AppContext __appContext = {
    .tx = 0.0f, .ty = 0.0f, .tz = -5.0f,
    .rx = 0.0f, .ry = 0.0f, .rz = 0.0f,

    .timebase = 0,
    .frame = 0,
};

static void init (void) {
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    glShadeModel(GL_SMOOTH);    

    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);

    glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    {
        GDImage image0, image1;

        gdImageReadFromFile(&image0, "/home/mbertozzi/Desktop/TombRaider/DATA/LARA-TEXTURES/297.dds.png");
        gdImageReadFromFile(&image1, "/home/mbertozzi/Desktop/TombRaider/DATA/LARA-TEXTURES/292.dds.png");

        __appContext.tex[0] = gdOpenGlInitTexture(&image0);
        __appContext.tex[1] = gdOpenGlInitTexture(&image1);
    }
}

static void __drawRect (void) {   
    GLfloat vertices[] = {
        -2.0f, -1.0f, 0.0f,
        -2.0f,  1.0f, 0.0f,
         0.0f,  1.0f, 0.0f,
         0.0f, -1.0f, 0.0f
    };

    GLfloat uvs[] = {   
        0.0f, 0.0f,
        0.0f, 1.0f,
        1.0f, 1.0f,
        1.0f, 0.0f
    };

    GLshort indices[] = {0, 1, 2, 3};

    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnable(GL_TEXTURE_2D);

    glActiveTexture(GL_TEXTURE0);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
    glBindTexture(GL_TEXTURE_2D, __appContext.tex[0]);
    glTexCoordPointer(2, GL_FLOAT, 0, uvs);

    glActiveTexture(GL_TEXTURE1);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
    glTexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_MODULATE);
    glTexEnvi(GL_TEXTURE_ENV, GL_COMBINE_ALPHA, GL_MODULATE);
    glBindTexture(GL_TEXTURE_2D, __appContext.tex[1]);
    glTexCoordPointer(2, GL_FLOAT, 0, uvs);

    glVertexPointer(3, GL_FLOAT, 0, vertices);
    glDrawElements(GL_QUADS, 4, GL_UNSIGNED_SHORT, indices);

    glDisable(GL_TEXTURE_2D);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glDisableClientState(GL_VERTEX_ARRAY);
}

static void displayFps (void) {
    int time;
    float tc;

    __appContext.frame++;
    time = glutGet(GLUT_ELAPSED_TIME);        
    if ((tc = (time - __appContext.timebase)) > 1000) {
        float fps = (__appContext.frame * 1000.0f) / tc;
        snprintf(__appContext.fps, 15, "FPS %.2f", fps);

        __appContext.timebase = time;
        __appContext.frame = 0;
    }

    glColor3f(1.0f, 1.0f, 1.0f);
    gdOpenGlDrawString(-2.6f, 1.9f, __appContext.fps);
}

static void displayHandler (void) {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glPushMatrix();

    /* Setup Second Camera Translation */
    glTranslatef(__appContext.tx, __appContext.ty, __appContext.tz);

    /* Draw Frame per Seconds */
    displayFps();

    /* Setup Second Camera Rotation */
    glRotatef(__appContext.rx, 1.0f, 0.0f, 0.0f);
    glRotatef(__appContext.ry, 0.0f, 1.0f, 0.0f);
    glRotatef(__appContext.rz, 0.0f, 0.0f, 1.0f);

    __drawRect();

    glPopMatrix();
    glutSwapBuffers();
}

static void reshapeHandler (int w, int h) {
    glViewport(0, 0, (GLsizei) w, (GLsizei)h); 

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
	gluPerspective(45.0f, (GLfloat)w/(GLfloat)h, 0.1f, 256.0f);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

static void keyboardHandler (unsigned char key, int x, int y) {
    if (key == 'x') {
        __appContext.rx = gdMathWrapDegAngle(__appContext.rx + CAMERA2_ROTATION_STEP);
    } else if (key == 'y') {
        __appContext.ry = gdMathWrapDegAngle(__appContext.ry + CAMERA2_ROTATION_STEP);
    } else if (key == 'z') {
        __appContext.rz = gdMathWrapDegAngle(__appContext.rz + CAMERA2_ROTATION_STEP);
    } else if (key == 'i') {
        __appContext.tz += CAMERA2_TRANSLATION_STEP;
    } else if (key == 'o') {
        __appContext.tz -= CAMERA2_TRANSLATION_STEP;
    } else if (key == 'l') {
        __appContext.tx -= CAMERA2_TRANSLATION_STEP;
    } else if (key == 'r') {
        __appContext.tx += CAMERA2_TRANSLATION_STEP;
    } else if (key == 'u') {
        __appContext.ty -= CAMERA2_TRANSLATION_STEP;
    } else if (key == 'd') {
        __appContext.ty += CAMERA2_TRANSLATION_STEP;
    } else if (key == 'p') {
        printf("STATE\n");
        printf(" - T %.2f %.2f %.2f\n", __appContext.tx, __appContext.ty, __appContext.tz);
        printf(" - R %.2f %.2f %.2f\n", __appContext.rx, __appContext.ry, __appContext.rz);
    }
        
    glutPostRedisplay();
}

int main (int argc, char **argv) {
    gdMathRandomInit(time(NULL));

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_ALPHA | GLUT_DEPTH);

    glutInitWindowSize(800, 600); 
    glutInitWindowPosition(10, 10);
    
    glutCreateWindow("OpenGL Test Particles");

    printf("Renderer: %s\n", glGetString(GL_RENDERER));
    printf("Version:  %s\n", glGetString(GL_VERSION));
    printf("Vendor:   %s\n", glGetString(GL_VENDOR));

    init();
    glutDisplayFunc(displayHandler);
    glutReshapeFunc(reshapeHandler);
    glutKeyboardFunc(keyboardHandler);

    glutMainLoop();
    return(0);
}
