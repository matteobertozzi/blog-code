#include <GDEngine/Config.h>

#if defined(GD_ENGINE_OPENGL_SUPPORT)

#include "opengl.h"
#include "macros.h"
#include "image.h"

static GDBool __initModelTexture (GDUInt index, void *data, void *args) {
    gdOpenGlInitTexture(gdImage(data));
    return(GD_FALSE);
}

static void __setGlTextImage2d (GDImage *image, GDImageData *data) {
    GLuint format;

    format = gdOpenGlImageFormat(image->format);
    if (gdImageFormatIsCompressed(image->format)) {
        /* TODO: Handle Compression */
    } else {
        glTexImage2D(GL_TEXTURE_2D, 0, format,
                     data->width, data->height, 
                     0, format, GL_UNSIGNED_BYTE, data->blob);
    }
}

GLuint gdOpenGlImageFormat (GDImageFormat format) {
    switch (format) {
        case GD_IMAGE_FORMAT_RGB:
            return(GL_RGB);
        case GD_IMAGE_FORMAT_RGBA:
            return(GL_RGBA);
        default:
            break;
    }

    return(0);
}

GLuint gdOpenGlInitTexture (GDImage *image) {
    GLuint texId;
    GDUInt i;

    gdReturnValueIfTrue(glIsTexture(image->id), image->id);

    glGenTextures(1, &texId);
    glBindTexture(GL_TEXTURE_2D, texId);
    gdImageSetId(image, texId);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); 
    glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE); 

    __setGlTextImage2d(image, &(image->data));
    for (i = 0; i < image->nMipMaps; ++i)
        __setGlTextImage2d(image, &(image->mipMaps[i]));

    return(texId);
}

void gdOpenGlInitModelTextures (GDModel *model) {
    GDUInt i;

    for (i = 0; i < model->nmeshes; ++i)
        gdListForeach(model->meshes[i].textures, __initModelTexture, NULL);
}

#endif /* GD_ENGINE_OPENGL_SUPPORT */

