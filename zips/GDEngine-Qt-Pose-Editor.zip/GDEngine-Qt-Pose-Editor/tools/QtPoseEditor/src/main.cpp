#include <QApplication>

#include "GDPoseEditorWindow.h"

int main (int argc, char **argv) {
    QApplication app(argc, argv);

    GDPoseEditorWindow window;
    window.show();

    return(app.exec());
}

