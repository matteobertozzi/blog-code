#ifndef _GD_MODEL_VIEW_H_
#define _GD_MODEL_VIEW_H_

#include <QGLWidget>

#include <GDEngine/Model.h>

class GDModelViewPrivate;
class GDModelView : public QGLWidget {
    Q_OBJECT

    public:
        GDModelView (QWidget *parent = 0);
        ~GDModelView();

    public Q_SLOTS:
        void setModel (GDModel *model);

        void setCurrentBone (uint boneIndex);

        void rotateX (int value);
        void rotateY (int value);
        void rotateZ (int value);

        void translateX (int value);
        void translateY (int value);
        void translateZ (int value);

        void toggleBonesView (bool enabled);
        void toggleWireframe (bool enabled);

    protected:
        void mouseReleaseEvent (QMouseEvent *event);
        void mousePressEvent (QMouseEvent *event);
        void mouseMoveEvent (QMouseEvent *event);
        void keyReleaseEvent (QKeyEvent *event);
        void wheelEvent (QWheelEvent *event);

        void resizeGL (int w, int h);
        void initializeGL (void);
        void paintGL (void);

    private:
        GDModelViewPrivate *d;
};

#endif /* !_GD_MODEL_VIEW_H_ */

