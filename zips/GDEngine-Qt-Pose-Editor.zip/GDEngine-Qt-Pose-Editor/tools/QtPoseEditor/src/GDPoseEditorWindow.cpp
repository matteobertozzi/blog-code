#include <QFileDialog>
#include <QFileInfo>
#include <QFile>
#include <QDir>
#include <QSet>

#include "ui_GDPoseEditorWindow.h"
#include "GDPoseEditorWindow.h"

#include <GDEngine/ModelReader.h>
#include <GDEngine/List.h>

class BoneTransform {
    public:
        int rx, ry, rz;
        int tx, ty, tz;

    public:
        BoneTransform() {
            rx = ry = rz = 0;
            tx = ty = tz = 0;
        }

        bool isModified (void) const {
            return(rx != 0 || ry != 0 || rz != 0 ||
                   tx != 0 || ty != 0 || tz != 0);
        }
};

class GDPoseEditorWindowPrivate {
    public:
        QList<BoneTransform> boneTransforms;
        Ui::GDPoseEditorWindow ui;
        bool applyChanges;

    public:
        void initComboBoxBones (GDModel *model);
        void initTextures (GDModel *model);

        uint currentBoneIndex (void) const;

        void addBone (const QString& boneName, uint id);
        void clearBones (void);
};

uint GDPoseEditorWindowPrivate::currentBoneIndex (void) const {
    int index = ui.comboBoxBones->currentIndex();
    return(ui.comboBoxBones->itemData(index).toUInt());
}

void GDPoseEditorWindowPrivate::initComboBoxBones (GDModel *model) {
    GDModelBone *bone;
    GDUInt i;

    boneTransforms.clear();
    ui.comboBoxBones->clear();
    for (i = 0; i < model->nbones; ++i) {
        bone = &(model->bones[i]);

        boneTransforms.append(BoneTransform());
        if (bone->name == NULL)
            addBone(QString("Bone %1").arg(bone->index), bone->index);
        else
            addBone(bone->name, bone->index);
    }
}

void GDPoseEditorWindowPrivate::addBone (const QString& boneName, uint id) {
    ui.comboBoxBones->addItem(boneName, QVariant(id));
}

void GDPoseEditorWindowPrivate::clearBones (void) {
    ui.comboBoxBones->clear();
}

void GDPoseEditorWindowPrivate::initTextures (GDModel *model) {
    QListWidgetItem *item;
    QSet<QString> paths;
    GDUInt i, j;

    for (i = 0; i < model->nmeshes; ++i) {
        if (model->meshes[i].textures == NULL)
            continue;

        for (j = 0; j < gdListSize(model->meshes[i].textures); ++j) {
            GDImage *image = gdImage(gdListAt(model->meshes[i].textures, j));
            paths.insert(QString(image->name));
        }
    }

    ui.listWidgetTextures->clear();
    foreach (QString path, paths) {
        item = new QListWidgetItem(QIcon(path), QFileInfo(path).fileName());
        ui.listWidgetTextures->addItem(item);
    }
}


GDPoseEditorWindow::GDPoseEditorWindow (QWidget *parent)
    : QMainWindow(parent), d(new GDPoseEditorWindowPrivate)
{   
    d->ui.setupUi(this);
    d->applyChanges = true;
    d->ui.listWidgetTextures->setIconSize(QSize(72, 72));
    d->ui.listWidgetTextures->setViewMode(QListView::IconMode);
    d->ui.groupBoxBoneTransformation->setEnabled(false);

    // Open Model
    connect(d->ui.actionOpen, SIGNAL(triggered()), this, SLOT(openModel()));
    connect(d->ui.actionSave, SIGNAL(triggered()), this, SLOT(savePose()));

    connect(d->ui.comboBoxBones, SIGNAL(currentIndexChanged(int)),
            this, SLOT(boneChanged(int)));

    // Show Wireframe Event
    connect(d->ui.actionShowWireframe, SIGNAL(triggered(bool)),
            d->ui.checkBoxShowWireframe, SLOT(setChecked(bool)));
    connect(d->ui.checkBoxShowWireframe, SIGNAL(toggled(bool)),
            d->ui.modelView, SLOT(toggleWireframe(bool)));
    connect(d->ui.checkBoxShowWireframe, SIGNAL(toggled(bool)),
            d->ui.actionShowWireframe, SLOT(setChecked(bool)));

    // Show Bones Event
    connect(d->ui.actionShowBones, SIGNAL(triggered(bool)),
            d->ui.checkBoxShowBones, SLOT(setChecked(bool)));
    connect(d->ui.checkBoxShowBones, SIGNAL(toggled(bool)),
            d->ui.modelView, SLOT(toggleBonesView(bool)));
    connect(d->ui.checkBoxShowBones, SIGNAL(toggled(bool)),
            d->ui.actionShowBones, SLOT(setChecked(bool)));

    // Initialize ModelBone Transformation Events
    connect(d->ui.sliderRotationX, SIGNAL(valueChanged(int)), 
            this, SLOT(rotateX(int)));
    connect(d->ui.sliderRotationY, SIGNAL(valueChanged(int)), 
            this, SLOT(rotateY(int)));
    connect(d->ui.sliderRotationZ, SIGNAL(valueChanged(int)), 
            this, SLOT(rotateZ(int)));

    connect(d->ui.sliderTranslationX, SIGNAL(valueChanged(int)), 
            this, SLOT(translateX(int)));
    connect(d->ui.sliderTranslationY, SIGNAL(valueChanged(int)), 
            this, SLOT(translateY(int)));
    connect(d->ui.sliderTranslationZ, SIGNAL(valueChanged(int)), 
            this, SLOT(translateZ(int)));

    // Help About
    connect(d->ui.actionAboutQt, SIGNAL(triggered()), qApp, SLOT(aboutQt()));
}

GDPoseEditorWindow::~GDPoseEditorWindow() {
    delete d;
}

void GDPoseEditorWindow::openModel (void) {
    QString fileName;

    fileName = QFileDialog::getOpenFileName(this, tr("Open Model"), 
                                            QDir::homePath(), 
                                            tr("GDT Files (*.gdt)"));
    if (!fileName.isEmpty())
        openModel(fileName);
}

void GDPoseEditorWindow::savePose (void) {
    QString fileName;

    fileName = QFileDialog::getSaveFileName(this, tr("Save Pose"), 
                                            QDir::homePath(), 
                                            tr("GDT Files (*.gdt)"));
    if (!fileName.isEmpty())
        savePose(fileName);
}

void GDPoseEditorWindow::savePose (const QString& fileName) {
    QFile file;

    file.setFileName(fileName);
    if (!file.open(QIODevice::WriteOnly))
        return;

    file.write("POSE\n");
    for (int i = 0; i < d->boneTransforms.size(); ++i) {
        if (!d->boneTransforms[i].isModified())
            continue;

        QString line = QString("%1 %2 %3 %4 %5 %6 %7\n");
        line = line.arg(i);
        line = line.arg(d->boneTransforms[i].rx);
        line = line.arg(d->boneTransforms[i].ry);
        line = line.arg(d->boneTransforms[i].rz);
        line = line.arg(d->boneTransforms[i].tx);
        line = line.arg(d->boneTransforms[i].ty);
        line = line.arg(d->boneTransforms[i].tz);
        file.write(line.toAscii());
    }

    file.close();
}

void GDPoseEditorWindow::openModel (const QString& fileName) {
    GDModelReader reader;
    GDModel *model;

    d->ui.groupBoxBoneTransformation->setEnabled(true);

    gdModelReaderInit(&reader);
    gdModelReaderRead(&reader, (const char *)fileName.toAscii());

    /* Take model from List */
    model = gdModel(gdListTakeAt(reader.models, 0));
    d->ui.modelView->setModel(model);

    gdModelReaderRelease(&reader);

    /* Setup Bones ComboBox */
    d->initComboBoxBones(model);
    d->initTextures(model);
}

void GDPoseEditorWindow::boneChanged (int index) {
    uint boneIndex = d->ui.comboBoxBones->itemData(index).toUInt();
    d->ui.modelView->setCurrentBone(boneIndex);

    // Reset Sliders
    d->applyChanges = false;
    d->ui.sliderRotationX->setValue(d->boneTransforms[boneIndex].rx);
    d->ui.sliderRotationY->setValue(d->boneTransforms[boneIndex].ry);
    d->ui.sliderRotationZ->setValue(d->boneTransforms[boneIndex].rz);
    d->ui.sliderTranslationX->setValue(d->boneTransforms[boneIndex].tx);
    d->ui.sliderTranslationY->setValue(d->boneTransforms[boneIndex].ty);
    d->ui.sliderTranslationZ->setValue(d->boneTransforms[boneIndex].tz);
    d->applyChanges = true;
}

void GDPoseEditorWindow::rotateX (int value) {
    if (!d->applyChanges) return;
    d->boneTransforms[d->currentBoneIndex()].rx = value;
    d->ui.modelView->rotateX(value);
}

void GDPoseEditorWindow::rotateY (int value) {
    if (!d->applyChanges) return;
    d->boneTransforms[d->currentBoneIndex()].ry = value;
    d->ui.modelView->rotateY(value);
}

void GDPoseEditorWindow::rotateZ (int value) {
    if (!d->applyChanges) return;
    d->boneTransforms[d->currentBoneIndex()].rz = value;
    d->ui.modelView->rotateZ(value);
}

void GDPoseEditorWindow::translateX (int value) {
    if (!d->applyChanges) return;
    d->boneTransforms[d->currentBoneIndex()].tx = value;
    d->ui.modelView->translateX(value);
}

void GDPoseEditorWindow::translateY (int value) {
    if (!d->applyChanges) return;
    d->boneTransforms[d->currentBoneIndex()].ty = value;
    d->ui.modelView->translateY(value);
}

void GDPoseEditorWindow::translateZ (int value) {
    if (!d->applyChanges) return;
    d->boneTransforms[d->currentBoneIndex()].tz = value;
    d->ui.modelView->translateZ(value);
}

