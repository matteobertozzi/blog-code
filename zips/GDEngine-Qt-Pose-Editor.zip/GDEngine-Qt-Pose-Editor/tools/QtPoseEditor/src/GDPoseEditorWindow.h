#ifndef _GD_POSE_EDITOR_WINDOW_H_
#define _GD_POSE_EDITOR_WINDOW_H_

#include <QMainWindow>

class GDPoseEditorWindowPrivate;
class GDPoseEditorWindow : public QMainWindow {
    Q_OBJECT

    public:
        GDPoseEditorWindow (QWidget *parent = 0);
        ~GDPoseEditorWindow();

    public Q_SLOTS:
        void openModel (void);
        void openModel (const QString& fileName);

        void savePose (void);
        void savePose (const QString& fileName);

    private Q_SLOTS:
        void boneChanged (int index);

        void rotateX (int value);
        void rotateY (int value);
        void rotateZ (int value);

        void translateX (int value);
        void translateY (int value);
        void translateZ (int value);

    private:
        GDPoseEditorWindowPrivate *d;
};

#endif /* !_GD_POSE_EDITOR_WINDOW_H_ */

