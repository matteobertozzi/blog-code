#include <QWheelEvent>
#include <QDebug>

#include "GDModelView.h"

#include <GDEngine/OpenGL.h>
#include <GDEngine/Matrix.h>
#include <GDEngine/Camera.h>
#include <GDEngine/Maths.h>

class GDModelViewPrivate {
    public:
        int boneTx, boneTy, boneTz;
        int boneRx, boneRy, boneRz;    
        uint currentBone;
        GDModel *model;

        GLfloat tx, ty, tz;
        GLfloat rx, ry, rz;
        GDCamera camera;
        QPoint mousePos;
        bool mouseMove;

        bool drawWireframe;
        bool drawBones;

    public:
        void drawModelBones (GDModel *model);
        void drawModelBone (GDModelBone *bone);
};


void GDModelViewPrivate::drawModelBone (GDModelBone *bone) {
    GDMatrix matrix;
    GDVector3d b;

    glPushMatrix();

    gdModelBoneCalculateAbsPosition(bone, &matrix);
    gdVector3dInit(&b, 0.0f, 0.0f, 0.0f);
    gdMatrixVector3dMultiply(&b, &b, &matrix);

    if (bone->parent != NULL) {
        GDVector3d p;

        gdModelBoneCalculateAbsPosition(bone->parent, &matrix);
        gdVector3dInit(&p, 0.0f, 0.0f, 0.0f);
        gdMatrixVector3dMultiply(&p, &p, &matrix);

        if (currentBone == bone->index) {
            glColor3f(1.0f, 0.0f, 0.0f);
            glLineWidth(5.0f);
        } else {
            glColor3f(0.5f, 0.5f, 0.5f);
            glLineWidth(1.5f);
        }
        glBegin(GL_LINES);
        glVertex3f(b.x, b.y, b.z);
        glVertex3f(p.x, p.y, p.z);
        glEnd();
        glLineWidth(1.0f);
    }

    glColor3f(0.0f, 1.0f, 0.0f);
    glPointSize(4.0);
    glBegin(GL_POINTS);
    glVertex3f(b.x, b.y, b.z);
    glEnd();
    glPointSize(1.0);

    glColor3f(1.0f, 1.0f, 1.0f);
    glPopMatrix();
}

void GDModelViewPrivate::drawModelBones (GDModel *model) {
    GDUInt i;

    for (i = 1; i < model->nbones; ++i)
        drawModelBone(&(model->bones[i]));
}

GDModelView::GDModelView (QWidget *parent)
    : QGLWidget(parent), d(new GDModelViewPrivate)
{
    d->model = NULL;
    d->currentBone = 0;
    d->drawBones = false;
    d->drawWireframe = false;

    d->tx = 0.0f; d->ty = 0.0f; d->tz = 0.0f;
    d->rx = 0.0f; d->ry = 0.0f; d->rz = 0.0f;
    d->mouseMove = false;

    d->boneTx = d->boneTy = d->boneTz = 0;
    d->boneRx = d->boneRy = d->boneRz = 0;

    setFocusPolicy(Qt::StrongFocus);
    setMouseTracking(true);
}

GDModelView::~GDModelView() {
    if (d->model != NULL)
        gdModelRelease(d->model);
    delete d;
}

void GDModelView::setModel (GDModel *model) {
    if (d->model != NULL)
        gdModelRelease(d->model);

    /* Set Model */
    d->model = model;

    /* Initialize Model Textures */
    gdOpenGlInitModelTextures(d->model);

    update();
}

void GDModelView::setCurrentBone (uint boneIndex) {
    d->currentBone = boneIndex;
    update();
}

void GDModelView::rotateX (int value) {
    GDModelBone *bone = &(d->model->bones[d->currentBone]);
    gdMatrixRotateX(&(bone->transform), gdMathDegToRad(value - d->boneRx));
    d->boneRx = value;
    update();
}

void GDModelView::rotateY (int value) {
    GDModelBone *bone = &(d->model->bones[d->currentBone]);
    gdMatrixRotateY(&(bone->transform), gdMathDegToRad(value - d->boneRy));
    d->boneRy = value;
    update();
}

void GDModelView::rotateZ (int value) {
    GDModelBone *bone = &(d->model->bones[d->currentBone]);
    gdMatrixRotateZ(&(bone->transform), gdMathDegToRad(value - d->boneRz));
    d->boneRz = value;
    update();
}

void GDModelView::translateX (int value) {
    GDModelBone *bone = &(d->model->bones[d->currentBone]);
    gdMatrixTranslate(&(bone->transform), value*0.01f - d->boneTx, 0.0f, 0.0f);
    d->boneTx = value;
    update();
}

void GDModelView::translateY (int value) {
    GDModelBone *bone = &(d->model->bones[d->currentBone]);
    gdMatrixTranslate(&(bone->transform), 0.0f, value*0.01f - d->boneTy, 0.0f);
    d->boneTy = value;
    update();
}

void GDModelView::translateZ (int value) {
    GDModelBone *bone = &(d->model->bones[d->currentBone]);
    gdMatrixTranslate(&(bone->transform), 0.0f, 0.0f, value*0.01f - d->boneTz);
    d->boneTz = value;
    update();
}

void GDModelView::toggleBonesView (bool enabled) {
    d->drawBones = enabled;
    update();
}

void GDModelView::toggleWireframe (bool enabled) {
    d->drawWireframe = enabled;
    glPolygonMode(GL_FRONT_AND_BACK, d->drawWireframe ? GL_LINE : GL_FILL);
    update();
}

void GDModelView::mouseReleaseEvent (QMouseEvent *event) {
    d->mouseMove = false;
}

void GDModelView::mousePressEvent (QMouseEvent *event) {
    d->mousePos = event->pos();
    d->mouseMove = true;
}

void GDModelView::mouseMoveEvent (QMouseEvent *event) {
    if (!d->mouseMove)
        return;

    QPoint pos = (event->pos() - d->mousePos);
    d->ry = gdMathWrapDegAngle(d->ry + pos.x());

    d->mousePos = event->pos();
    update();
}

void GDModelView::keyReleaseEvent (QKeyEvent *event) {
    int moveDelta = 1;

    switch (event->key()) {
        case Qt::Key_Up:
            d->ty += moveDelta;
            break;
        case Qt::Key_Down:
            d->ty -= moveDelta;
            break;
        case Qt::Key_Left:
            d->tx += moveDelta;
            break;
        case Qt::Key_Right:
            d->tx -= moveDelta;
            break;
    }
    update();
}

void GDModelView::wheelEvent (QWheelEvent *event) {
    d->tz += event->delta() * 0.001f;
    update();
}

void GDModelView::resizeGL (int w, int h) {
    glViewport(0, 0, (GLsizei) w, (GLsizei)h); 

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
	gluPerspective(45.0f, (GLfloat)w/(GLfloat)h, 0.1f, 2048.0f);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void GDModelView::initializeGL (void) {
    qglClearColor(Qt::black);

    glShadeModel(GL_SMOOTH);    

    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
    glPolygonMode(GL_FRONT_AND_BACK, d->drawWireframe ? GL_LINE : GL_FILL);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);

    glEnable(GL_CULL_FACE);

    glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    /* Initialize Camera */
    gdCameraInit(&(d->camera));

    gdVector3dInit(&(d->camera.position), 0.0f, 0.87f, -48.0f);
    d->camera.theta = 120.0f;
    d->ty = -1.0f;
    d->tz = 4.0f;
    d->ry = 41.0f;
}

void GDModelView::paintGL (void) {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    if (d->model != NULL) {
        glPushMatrix();

        glTranslatef(0.0f, -1.0f, -60.0f);

        /* Setup Camera */
        gdOpenGlSetCamera(&(d->camera));

        /* Setup Second Camera Translation */
        glTranslatef(d->tx, d->ty, d->tz);

        /* Setup Second Camera Rotation */
        glRotatef(d->rx, 1.0f, 0.0f, 0.0f);
        glRotatef(d->ry, 0.0f, 1.0f, 0.0f);
        glRotatef(d->rz, 0.0f, 0.0f, 1.0f);

        glPushMatrix();
            glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);

            if (d->drawBones && d->model->bones != NULL) {
                /* Draw Model Bones */
                d->drawModelBones(d->model);
            } else {
                /* Draw Model */
                gdOpenGlModelDraw(d->model);
            }
        glPopMatrix();

        glPopMatrix();
    }

    swapBuffers();
}

