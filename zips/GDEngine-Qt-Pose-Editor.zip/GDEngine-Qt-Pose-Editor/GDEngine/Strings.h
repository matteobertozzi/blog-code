#ifndef _GDENGINE_STRINGS_H_
#define _GDENGINE_STRINGS_H_

#include <GDEngine/Macros.h>
__GD_ENGINE_BEGIN_DECLS

char *  gdStringTrim    (char *s);

__GD_ENGINE_END_DECLS

#endif /* !_GDENGINE_STRINGS_H_ */

