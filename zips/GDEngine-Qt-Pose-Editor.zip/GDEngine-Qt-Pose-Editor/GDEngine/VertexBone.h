#ifndef _GDENGINE_VERTEX_BONE_H_
#define _GDENGINE_VERTEX_BONE_H_

#include <GDEngine/Macros.h>
__GD_ENGINE_BEGIN_DECLS

#include <GDEngine/Types.h>

typedef struct {
    GDFloat *boneWeights;
    GDUInt *boneIndices;
    GDUInt nbones;
} GDVertexBone;

GDBool gdVertexBoneInit    (GDVertexBone *vbone, GDUInt nbones);
void   gdVertexBoneRelease (GDVertexBone *vbone);

__GD_ENGINE_END_DECLS

#endif /* !_GDENGINE_VERTEX_BONE_H_ */

