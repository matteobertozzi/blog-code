#ifndef _GDENGINE_IMAGE_H_
#define _GDENGINE_IMAGE_H_

#include <GDEngine/Macros.h>
__GD_ENGINE_BEGIN_DECLS

#include <GDEngine/Object.h>
#include <GDEngine/Types.h>

typedef enum {
    GD_IMAGE_FORMAT_UNKNOWN,
    GD_IMAGE_FORMAT_RGB,
    GD_IMAGE_FORMAT_RGBA,

    GD_IMAGE_FORMAT_DXT1,
    GD_IMAGE_FORMAT_DXT2,
    GD_IMAGE_FORMAT_DXT5,
    GD_IMAGE_FORMAT_RGB_PVR2,
    GD_IMAGE_FORMAT_RGB_PVR4,
    GD_IMAGE_FORMAT_RGBA_PVR2,
    GD_IMAGE_FORMAT_RGBA_PVR4,
} GDImageFormat;

typedef struct {
    GDUInt height;
    GDUInt width;
    GDUInt size;
    GDByte *blob;
} GDImageData;

typedef struct {
    GD_OBJECT

    GDImageData *mipMaps;
    GDUInt nMipMaps;

    GDImageFormat format;
    GDImageData data;
    char *name;

    GDUInt id;
} GDImage;

#define  gdImage(p)      ((GDImage *)(p))

GDBool gdImageFormatIsCompressed (GDImageFormat format);

GDImage *gdImageInit        (GDImage *image);
GDImage *gdImageRetain      (GDImage *image);
void     gdImageRelease     (GDImage *image);

GDImage *gdImageCopy        (GDImage *dst, const GDImage *src);

GDBool   gdImageInitMipMaps (GDImage *image, GDUInt nMipMaps);

#define  gdImageSetId(image, texId)      (image)->id = texId
void     gdImageSetName     (GDImage *image, const char *name);
void     gdImageSetFormat   (GDImage *image, GDImageFormat format);
void     gdImageSetSize     (GDImage *image, GDUInt width, GDUInt height);
void     gdImageSetData     (GDImage *image, GDByte *data, GDUInt size);

void     gdImageSetMipMapSize (GDImage *image, GDUInt level,
                               GDUInt width, GDUInt height);
void     gdImageSetMipMapData (GDImage *image, GDUInt level,
                               GDByte *data, GDUInt size);

__GD_ENGINE_END_DECLS

#endif /* !_GDENGINE_IMAGE_H_ */

