#ifndef _GDENGINE_DEBUG_
#define _GDENGINE_DEBUG_

#include <GDEngine/Macros.h>
__GD_ENGINE_BEGIN_DECLS

void __gdWarningSysFail (const char *file, unsigned int line, const char *func,
                         const char *format, ...);

void __gdAssert (const char *file, unsigned int line, const char *func,
                 int expr, const char *expression,
                 const char *format, ...);

#define gdWarningSysFail(frmt, ...)                     \
    do {                                                \
        __gdWarningSysFail(__FILE__, __LINE__,          \
                           __PRETTY_FUNCTION__,         \
                           frmt, __VA_ARGS__);          \
    } while (0)

#define GD_ASSERT(expr, frmt, ...)              \
    do {                                        \
        __gdAssert(__FILE__, __LINE__,          \
                   __PRETTY_FUNCTION__,         \
                   expr, #expr,                 \
                   frmt, __VA_ARGS__);          \
    } while (0)

__GD_ENGINE_END_DECLS

#endif /* !_GDENGINE_DEBUG_ */

