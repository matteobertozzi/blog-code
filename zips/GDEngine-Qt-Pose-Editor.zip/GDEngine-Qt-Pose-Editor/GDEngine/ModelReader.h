#ifndef _GDENGINE_MODEL_READER_H_
#define _GDENGINE_MODEL_READER_H_

#include <GDEngine/Macros.h>
__GD_ENGINE_BEGIN_DECLS

#include <GDEngine/Model.h>
#include <GDEngine/List.h>

typedef struct {
    GDList *models;
} GDModelReader;

GDBool gdModelReaderInit            (GDModelReader *reader);
void   gdModelReaderRelease         (GDModelReader *reader);

GDBool gdModelReaderRead (GDModelReader *reader, const char *filename);

GDBool gdModelReaderAddModel        (GDModelReader *reader,
                                     GDModel *model);

__GD_ENGINE_END_DECLS

#endif /* !_GDENGINE_MODEL_READER_H_ */

