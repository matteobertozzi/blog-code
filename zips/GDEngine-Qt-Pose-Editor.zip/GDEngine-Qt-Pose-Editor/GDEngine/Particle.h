#ifndef _GDENGINE_PARTICLE_H_
#define _GDENGINE_PARTICLE_H_

#include <GDEngine/Macros.h>
__GD_ENGINE_BEGIN_DECLS

#include <GDEngine/Vector3d.h>
#include <GDEngine/Object.h>
#include <GDEngine/Types.h>

typedef struct {
    GD_OBJECT
    
    GDVector3d position;
    GDVector3d direction;
    GDFloat    speed;
    GDFloat    mass;
    GDFloat    age;
    GDFloat    lifetime;
} GDParticle;

GDParticle *gdParticleInit    (GDParticle *particle,
                               const GDVector3d *position,
                               const GDVector3d *direction);
GDParticle *gdParticleRetain  (GDParticle *particle);
void        gdParticleRelease (GDParticle *particle);

GDBool      gdParticleUpdate  (GDParticle *particle);

__GD_ENGINE_END_DECLS

#endif /* !_GDENGINE_PARTICLE_H_ */
