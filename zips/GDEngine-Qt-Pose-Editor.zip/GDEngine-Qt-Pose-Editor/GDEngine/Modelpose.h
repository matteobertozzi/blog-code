#ifndef _GDENGINE_MODEL_POSE_H_
#define _GDENGINE_MODEL_POSE_H_

#include <GDEngine/Macros.h>
__GD_ENGINE_BEGIN_DECLS

typedef struct {
} GDModelPose;

__GD_ENGINE_END_DECLS

#endif /* !_GDENGINE_MODEL_POSE_H_ */

