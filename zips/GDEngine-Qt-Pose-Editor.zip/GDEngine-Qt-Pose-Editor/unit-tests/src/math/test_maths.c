#include "unittest.h"

void test_maths (GDUnitTests *unitTests) {
    printf(" - MATH TEST\n");
}

