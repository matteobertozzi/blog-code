#define NEO_FREERUNNER_GTA02

#include <QTimerEvent>

#include "qaccelerometer.h"
#include "accelerometer_neo.cpp"

/* ============================================================================
 *  PRIVATE Class
 */
class QAccelerometerPrivate {
	public:
		int updateInterval;
		int cx, cy, cz;
		int timerId;
};

/* ============================================================================
 *  PUBLIC Constructor/Destructor
 */
QAccelerometer::QAccelerometer (QObject *parent)
	: QObject(parent), d(new QAccelerometerPrivate)
{
	__accelerometer_open();
	__accelerometer_process(&(d->cx), &(d->cy), &(d->cz));

	d->updateInterval = (1000 / 10);		// 10Hz
	d->timerId = startTimer(d->updateInterval);
}

QAccelerometer::~QAccelerometer() {
	killTimer(d->timerId);
	__accelerometer_close();
	delete d;
}

/* ============================================================================
 *  PUBLIC Properties
 */
int QAccelerometer::updateInterval (void) const {
	return(d->updateInterval);
}

void QAccelerometer::setUpdateInterval (int interval) {
	d->updateInterval = interval;

	killTimer(d->timerId);
	d->timerId = startTimer(interval);
}

/* ============================================================================
 *  PROTECTED Methods
 */
void QAccelerometer::timerEvent (QTimerEvent *event) {
	if (event->timerId() != d->timerId)
		return;

	int x, y, z;
	if (__accelerometer_process(&x, &y, &z) >= 0) {
		// Average with cached values
		x = d->cx = (x + d->cx) / 2;
		y = d->cy = (y + d->cy) / 2;
		z = d->cz = (z + d->cz) / 2;

		// Convert Moko Values in -1.00 - 1.00 Range
		qreal dx = ((qreal)x / 1000.0);
		qreal dy = ((qreal)y / 1000.0);
		qreal dz = ((qreal)z / 1000.0);

		dx = dx * 0.05 + dx * (1.0 - 0.05);
		dy = dy * 0.05 + dy * (1.0 - 0.05);
		dz = dz * 0.05 + dz * (1.0 - 0.05);

		emit acceleration(dx, dy, dz);
	}
}


