#include <QtopiaApplication>
#include "qaccelerometertest.h"

QTOPIA_ADD_APPLICATION(QTOPIA_TARGET, QAccelerometerTest)
QTOPIA_MAIN
