#ifndef _QACCELEROMETERTEST_H_
#define _QACCELEROMETERTEST_H_

#include <QWidget>
#include "qaccelerometer.h"

class QAccelerometerTest : public QWidget {
	Q_OBJECT

	public:
		QAccelerometerTest (QWidget *parent = 0, Qt::WindowFlags flags = 0);
		~QAccelerometerTest();

	protected:
		void paintEvent (QPaintEvent *event);

	private slots:
		void onAcceleration (qreal x, qreal y, qreal z);

	private:
		QAccelerometer m_accelerometer;
		QPointF m_point;
		qreal m_zaxis;
};

#endif /* !_QACCELEROMETERTEST_H_ */

