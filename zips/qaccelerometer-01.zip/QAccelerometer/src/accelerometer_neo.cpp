#ifdef NEO_FREERUNNER_GTA02

#include <sys/stat.h>
#include <unistd.h>
#include <stdint.h>
#include <fcntl.h>
#include <stdio.h>

/* ============================================================================
 *  Constants Devices
 */
#define ACCELEROMETER_DEVICE1		"/dev/input/event2"
#define ACCELEROMETER_DEVICE2		"/dev/input/event3"

/* ============================================================================
 *  Constants
 */
#define ACCELEROMETER_BUFFER		8
#define INPUT_EVENT_SIZE			sizeof(struct input_event)

/* ============================================================================
 *  Constants Event Codes
 */
#define EVENT_CODE_X		0x00
#define EVENT_CODE_Y		0x01
#define EVENT_CODE_Z		0x02

/* ============================================================================
 *  STRUCT Input Event
 */
struct input_event {
	char 			time[8];
	uint16_t		code;
	uint16_t		type;
	int32_t			value;
};

/* ============================================================================
 *  Devices Descriptor(s)
 */
static int _fds[2];

/* ============================================================================
 *  PRIVATE Methods
 */
static int __read_all (int fd, void *buf, int count) {
	int nread = 0;
	int res;

	while (nread != count) {
		if ((res = read(fd, (char *)buf + nread, count - nread)) < 0)
			return(res);

		if (res == 0)
			return(nread);

		nread += res;
	}

	return nread;
}

static int __accelerometer_device_process (int fd, int *x, int *y, int *z) {
	struct input_event ievent;

	do {
		if (__read_all(fd, &ievent, INPUT_EVENT_SIZE) != INPUT_EVENT_SIZE)
			return(-1);

		if (ievent.code != 0x00) {
			if (ievent.type == EVENT_CODE_X) {
				*x = ievent.value;
			} else if (ievent.type == EVENT_CODE_Y) {
				*y = ievent.value;
			} else if (ievent.type == EVENT_CODE_Z) {
				*z = ievent.value;
			}
		}
	} while (ievent.code != 0x00);

	return(0);
}

/* ============================================================================
 *  PUBLIC Methods
 */
void __accelerometer_open (void) {
	//_fds[0] = open(ACCELEROMETER_DEVICE1, O_RDONLY);
	_fds[1] = open(ACCELEROMETER_DEVICE2, O_RDONLY);
}

void __accelerometer_close (void) {
	//close(_fds[0]);
	close(_fds[1]);
}

int __accelerometer_process (int *x, int *y, int *z) {
	int d2[3] = { 0, 0, 0 };
	int retval = 0;
	int i;

	*x = *y = *z = 0;
	for (i = 0; i < ACCELEROMETER_BUFFER; ++i) {
		if (__accelerometer_device_process(_fds[1], &d2[0], &d2[1], &d2[2])) {
			retval = (i == 0) ? -1 : 1;
			break;
		}

		*x += d2[0];
		*y += d2[1];
		*z += d2[2];
	}

	*x /= ACCELEROMETER_BUFFER;
	*y /= ACCELEROMETER_BUFFER;
	*z /= ACCELEROMETER_BUFFER;

	return(retval);
}


#endif /* NEO_FREERUNNER_GTA02 */

