#ifndef _QACCELEROMETER_H_
#define _QACCELEROMETER_H_

#include <QObject>
class QAccelerometerPrivate;

class QAccelerometer : public QObject {
	Q_OBJECT

	Q_PROPERTY(int updateInterval READ updateInterval WRITE setUpdateInterval)

	public:
		QAccelerometer (QObject *parent = 0);
		~QAccelerometer();

		int updateInterval (void) const;
		void setUpdateInterval (int interval);

	signals:
		void acceleration (qreal x, qreal y, qreal z);

	protected:
		void timerEvent (QTimerEvent *event);

	private:
		QAccelerometerPrivate *d;
};

#endif /* !_QACCELEROMETER_H_ */

