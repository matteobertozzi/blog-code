#include <QPaintEvent>
#include <QPainter>
#include <QDebug>

#include "qaccelerometertest.h"

/* ============================================================================
 *  PRIVATE Macros Utils
 */
#define math_between(x, a, b)		((x) >= (a) && (x) <= (b))

/* ============================================================================
 *  PUBLIC Constructors
 */
QAccelerometerTest::QAccelerometerTest (QWidget *parent, Qt::WindowFlags flags)
	: QWidget(parent, flags)
{
	connect(&m_accelerometer, SIGNAL(acceleration(qreal, qreal, qreal)),
			this, SLOT(onAcceleration(qreal, qreal, qreal)));
}

QAccelerometerTest::~QAccelerometerTest() {
}

/* ============================================================================
 *  PROTECTED Methods
 */
void QAccelerometerTest::paintEvent (QPaintEvent *event) {
	QPainter p(this);

	p.translate(event->rect().x(), event->rect().y());

	int height = event->rect().height();
	int width = event->rect().width();
	int midY = (height / 2);
	int midX = (width / 2);

	// Draw Grid
	p.drawLine(0, midY, width, midY);
	p.drawLine(midX, 0, midX, height);

	qreal x = (m_point.x() * width);
	qreal y = (m_point.y() * height);

	x = (x < 0) ? (midX - (-1 * (x / 2))) : (midX + (x / 2));
	y = ((y < 0) ? (midY + (-1 * (y / 2))) : (midY - (y / 2)));

	QPainterPath path;
	path.addEllipse(QRectF(x - 15, y - 15, 30, 30));
	p.fillPath(path, Qt::red);

	int px = math_between(m_point.x(), -0.5, 0.5) ? 0 : (m_point.x() < 0 ? -1 : 1);
	int py = math_between(m_point.y(), -0.5, 0.5) ? 0 : (m_point.y() < 0 ? -1 : 1);
	int pz = math_between(m_zaxis, -0.5, 0.5) ? 0 : (m_zaxis < 0 ? -1 : 1);
	p.drawText(0, 30, tr("(%1,%2,%3)").arg(px, 2).arg(py, 2).arg(pz, 2));

	p.end();
}

/* ============================================================================
 *  PRIVATE Slots
 */
void QAccelerometerTest::onAcceleration (qreal x, qreal y, qreal z) {
	qDebug() << "X" << x << "Y" << y << "Z" << z;
	m_point.setX(x);
	m_point.setY(y);
	m_zaxis = z;

	update();
}

