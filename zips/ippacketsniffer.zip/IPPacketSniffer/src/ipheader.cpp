/* 
 * Copyright (C) 2009 Matteo Bertozzi.
 *
 * This file is part of THLibrary.
 * 
 * THLibrary is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * THLibrary is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with THLibrary.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <sys/socket.h>
#include <netinet/ip.h>
#include <arpa/inet.h>

#include "protocol.h"
#include "ipheader.h"

/* ============================================================================
 *  PRIVATE Methods
 */
static QString humanSize (quint32 size) {
    if (size >= 1048576)
        return(QString("%1 Kb").arg((qreal(size) / 1048576), 0, 'g', 3));

    if (size >= 1024)
        return(QString("%1 Kb").arg((qreal(size) / 1024), 0, 'g', 3));

    return(QString("%1 byte").arg(size));
}

/* ============================================================================
 *  PRIVATE Class
 */
class THIpHeaderPrivate {
    public:
        QByteArray ipData;

        QString protocolInfo;
        QString totLenInfo;
        QString sourceAddr;
        QString destAddr;
        QString ihlInfo;
};

/* ============================================================================
 *  PUBLIC Constructor/Destructor
 */
THIpHeader::THIpHeader (const char *data)
    : d(new THIpHeaderPrivate)
{
    d->ipData = QByteArray(data, sizeof(struct iphdr));

    struct iphdr *ip = (struct iphdr *)data;

    // Source Address
    struct in_addr source;
    source.s_addr = ip->saddr;
    d->sourceAddr = inet_ntoa(source);

    // Destination Address
    struct in_addr destination;
    destination.s_addr = ip->daddr;
    d->destAddr = inet_ntoa(destination);

    // Protocol Info
    THProtocol proto(ip->protocol);
    d->protocolInfo = QString("%1 (%2)").arg(proto.name()).arg(proto.id());

    d->totLenInfo = humanSize(ntohs(ip->tot_len));
    d->ihlInfo = humanSize(ip->ihl * 4);
}

THIpHeader::~THIpHeader() {
    delete d;
}

/* ============================================================================
 *  PUBLIC Methods
 */
QString THIpHeader::idInfo (void) const {
    struct iphdr *ip = (struct iphdr *)d->ipData.constData();
    return(QString("%1").arg(ntohs(ip->id)));
}

QString THIpHeader::sourceInfo (void) const {
    return(d->sourceAddr);
}

QString THIpHeader::versionInfo (void) const {
    struct iphdr *ip = (struct iphdr *)d->ipData.constData();
    return(QString("%1").arg(ip->version));
}

QString THIpHeader::protocolInfo (void) const {
    return(d->protocolInfo);
}

QString THIpHeader::checksumInfo (void) const {
    struct iphdr *ip = (struct iphdr *)d->ipData.constData();
    return(QString("%1").arg(ip->check));
}

QString THIpHeader::timeToLiveInfo (void) const {
    struct iphdr *ip = (struct iphdr *)d->ipData.constData();
    return(QString("%1").arg(ip->ttl));
}

QString THIpHeader::destinationInfo (void) const {
    return(d->destAddr);
}

QString THIpHeader::totalLengthInfo (void) const {
    return(d->totLenInfo);
}

QString THIpHeader::typeOfServiceInfo (void) const {
    struct iphdr *ip = (struct iphdr *)d->ipData.constData();
    return(QString("%1").arg(ip->tos));
}

QString THIpHeader::fragmentOffsetInfo (void) const {
    struct iphdr *ip = (struct iphdr *)d->ipData.constData();
    return(QString("%1").arg(ip->frag_off));
}

QString THIpHeader::internetHeaderLengthInfo (void) const {
    return(d->ihlInfo);
}

