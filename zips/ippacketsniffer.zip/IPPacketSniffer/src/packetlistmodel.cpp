/* 
 * Copyright (C) 2009 Matteo Bertozzi.
 *
 * This file is part of THLibrary.
 * 
 * THLibrary is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * THLibrary is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with THLibrary.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <QDateTime>

#include "packetlistmodel.h"
#include "ipheader.h"

/* ============================================================================
 *  PUBLIC Constructor/Destructor
 */
THPacketListModel::THPacketListModel (QObject *parent)
    : QStandardItemModel(0, 10, parent)
{
    setHeaderData(0, Qt::Horizontal, tr("ID"));
    setHeaderData(1, Qt::Horizontal, tr("Date"));
    setHeaderData(2, Qt::Horizontal, tr("Protocol"));
    setHeaderData(3, Qt::Horizontal, tr("Source"));
    setHeaderData(4, Qt::Horizontal, tr("Destination"));
    setHeaderData(5, Qt::Horizontal, tr("Length"));
    setHeaderData(6, Qt::Horizontal, tr("Checksum"));
    setHeaderData(7, Qt::Horizontal, tr("Version"));
    setHeaderData(8, Qt::Horizontal, tr("Priority"));
    setHeaderData(9, Qt::Horizontal, tr("Packet Data"));
}

THPacketListModel::~THPacketListModel() {
}

/* ============================================================================
 *  PUBLIC Methods
 */
Qt::ItemFlags THPacketListModel::flags (const QModelIndex& index) const {
    Q_UNUSED(index)
    return(Qt::ItemIsEnabled | Qt::ItemIsSelectable);
}

/* ============================================================================
 *  PUBLIC Slots
 */
void THPacketListModel::appendPacket (const QByteArray& data) {
    insertPacket(rowCount(), data);
}

void THPacketListModel::insertPacket (int rowIndex, const QByteArray& data) {
    THIpHeader ip(data.constData());

    QString date = QDateTime::currentDateTime().toString("d/M/yy hh:mm:ss");

    insertRow(rowIndex);
    setData(index(rowIndex, 0), ip.idInfo());
    setData(index(rowIndex, 1), date);
    setData(index(rowIndex, 2), ip.protocolInfo());
    setData(index(rowIndex, 3), ip.sourceInfo());
    setData(index(rowIndex, 4), ip.destinationInfo());
    setData(index(rowIndex, 5), ip.totalLengthInfo());
    setData(index(rowIndex, 6), ip.checksumInfo());
    setData(index(rowIndex, 7), ip.versionInfo());
    setData(index(rowIndex, 8), ip.typeOfServiceInfo());
    setData(index(rowIndex, 9), data);
}

