/* 
 * Copyright (C) 2009 Matteo Bertozzi.
 *
 * This file is part of THLibrary.
 * 
 * THLibrary is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * THLibrary is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with THLibrary.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <sys/socket.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>

#include "tcpheader.h"

/* ============================================================================
 *  PRIVATE Class
 */
class THTcpHeaderPrivate {
    public:
        QByteArray tcpData;
};

/* ============================================================================
 *  PUBLIC Constructor/Destructor
 */
THTcpHeader::THTcpHeader (const char *data)
    : d(new THTcpHeaderPrivate)
{
    d->tcpData = QByteArray(data, sizeof(struct tcphdr));
}

THTcpHeader::~THTcpHeader() {
    delete d;
}

/* ============================================================================
 *  PUBLIC Properties
 */
QString THTcpHeader::ackInfo (void) const {
    struct tcphdr *tcp = (struct tcphdr *)d->tcpData.constData();
    return(tcp->ack ? "ON" : "OFF");
}

QString THTcpHeader::pushInfo (void) const {
    struct tcphdr *tcp = (struct tcphdr *)d->tcpData.constData();
    return(tcp->psh ? "ON" : "OFF");
}

QString THTcpHeader::resetInfo (void) const {
    struct tcphdr *tcp = (struct tcphdr *)d->tcpData.constData();
    return(tcp->rst ? "ON" : "OFF");
}

QString THTcpHeader::finalInfo (void) const {
    struct tcphdr *tcp = (struct tcphdr *)d->tcpData.constData();
    return(tcp->fin ? "ON" : "OFF");
}

QString THTcpHeader::windowInfo (void) const {
    struct tcphdr *tcp = (struct tcphdr *)d->tcpData.constData();
    return(QString("%1").arg(ntohs(tcp->window)));
}

QString THTcpHeader::urgentInfo (void) const {
    struct tcphdr *tcp = (struct tcphdr *)d->tcpData.constData();
    return(tcp->urg ? "ON" : "OFF");
}

QString THTcpHeader::sequenceInfo (void) const {
    struct tcphdr *tcp = (struct tcphdr *)d->tcpData.constData();
    return(QString("%1").arg(ntohs(tcp->seq)));
}

QString THTcpHeader::checksumInfo (void) const {
    struct tcphdr *tcp = (struct tcphdr *)d->tcpData.constData();
    return(QString("%1").arg(tcp->check));
}

QString THTcpHeader::sourcePortInfo (void) const {
    struct tcphdr *tcp = (struct tcphdr *)d->tcpData.constData();
    return(QString("%1").arg(ntohs(tcp->source)));
}

QString THTcpHeader::ackSequenceInfo (void) const {
    struct tcphdr *tcp = (struct tcphdr *)d->tcpData.constData();
    return(QString("%1").arg(ntohs(tcp->ack_seq)));
}

QString THTcpHeader::segmentOffsetInfo (void) const {
    struct tcphdr *tcp = (struct tcphdr *)d->tcpData.constData();
    return(QString("%1").arg(ntohs(tcp->doff * 4)));
}

QString THTcpHeader::urgentPointerInfo (void) const {
    struct tcphdr *tcp = (struct tcphdr *)d->tcpData.constData();
    return(QString("%1").arg(tcp->urg_ptr));
}

QString THTcpHeader::synchronizationInfo (void) const {
    struct tcphdr *tcp = (struct tcphdr *)d->tcpData.constData();
    return(tcp->syn ? "ON" : "OFF");
}

QString THTcpHeader::destinationPortInfo (void) const {
    struct tcphdr *tcp = (struct tcphdr *)d->tcpData.constData();
    return(QString("%1").arg(ntohs(tcp->dest)));
}


