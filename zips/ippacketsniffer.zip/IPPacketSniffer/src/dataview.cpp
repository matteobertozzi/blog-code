/* 
 * Copyright (C) 2009 Matteo Bertozzi.
 *
 * This file is part of THLibrary.
 * 
 * THLibrary is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * THLibrary is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with THLibrary.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <QFileDialog>
#include <QMessageBox>
#include <QBuffer>
#include <QFile>

#include "ui_dataview.h"

#include "dataview.h"

/* ============================================================================
 *  PRIVATE Class
 */
class THDataViewPrivate {
    public:
        Ui::DataView ui;

        THDataView::GroupType groupType;
        QByteArray data;

    public:
        void updateDataView (void);
};

void THDataViewPrivate::updateDataView (void) {
    if (data.isEmpty()) {
        ui.plainTextEdit->setPlainText(QString());
        return;
    }

    QBuffer buffer(&data);

    QString formattedData;
    QChar zFiller('0');

    buffer.open(QIODevice::ReadOnly);
    while (!buffer.atEnd()) {
        if (groupType == THDataView::GroupAscii) {
            unsigned char ascii;
            buffer.read((char *)&ascii, 1);
            QChar chr(ascii);
            formattedData.append(ascii);
        } else if (groupType == THDataView::Group8Byte) {
            quint8 byte;
            buffer.read((char *)&byte, 1);
            formattedData.append(QString("%1 ").arg(byte, 2, 16, zFiller));
        } else if (groupType == THDataView::Group16Byte) {
            quint16 word;
            buffer.read((char *)&word, 2);
            formattedData.append(QString("%1 ").arg(word, 4, 16, zFiller));
        } else if (groupType == THDataView::Group32Byte) {
            quint32 longWord;
            buffer.read((char *)&longWord, 4);
            formattedData.append(QString("%1 ").arg(longWord, 8, 16, zFiller));
        }
    }

    buffer.close();

    ui.plainTextEdit->setPlainText(formattedData);
}

/* ============================================================================
 *  PUBLIC Constructor/Destructor
 */
THDataView::THDataView (QWidget *parent) 
    : QWidget(parent), d(new THDataViewPrivate)
{
    d->ui.setupUi(this);
    d->ui.plainTextEdit->setReadOnly(true);
    d->groupType = Group8Byte;

    QFont qFont = d->ui.plainTextEdit->font();
    qFont.setFamily("Monospace");
    d->ui.plainTextEdit->setFont(qFont);

    connect(d->ui.radio8bytes, SIGNAL(toggled(bool)), 
            this, SLOT(group8byte(bool)));
    connect(d->ui.radio16bytes, SIGNAL(toggled(bool)),
            this, SLOT(group16byte(bool)));
    connect(d->ui.radio32bytes, SIGNAL(toggled(bool)),
            this, SLOT(group32byte(bool)));
    connect(d->ui.radioAscii, SIGNAL(toggled(bool)),
            this, SLOT(groupAscii(bool)));
    connect(d->ui.buttonSave, SIGNAL(clicked()),
            this, SLOT(save()));
}

THDataView::~THDataView() {
    delete d;
}

/* ============================================================================
 *  PUBLIC Properties
 */
QByteArray THDataView::data (void) const {
    return(d->data);
}

void THDataView::setData (const QByteArray& data) {
    d->data = data;
    d->updateDataView();
}

/* ============================================================================
 *  PUBLIC Slots
 */
void THDataView::save (void) {
    QString fileName = QFileDialog::getSaveFileName(this);
    if (fileName.isEmpty()) return;

    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly)) {
        QMessageBox::critical(this, tr("Unable to Save File"), 
                              file.errorString());
    } else {
        file.write(d->data);
        file.close();
    }
}

void THDataView::groupAscii (void) {
    d->groupType = GroupAscii;
    d->updateDataView();
}

void THDataView::group8byte (void) {
    d->groupType = Group8Byte;
    d->updateDataView();
}

void THDataView::group16byte (void) {
    d->groupType = Group16Byte;
    d->updateDataView();
}

void THDataView::group32byte (void) {
    d->groupType = Group32Byte;
    d->updateDataView();
}

/* ============================================================================
 *  PRIVATE Slots
 */
void THDataView::groupAscii (bool checked) {
    if (checked) groupAscii();
}

void THDataView::group8byte (bool checked) {
    if (checked) group8byte();
}

void THDataView::group16byte (bool checked) {
    if (checked) group16byte();
}

void THDataView::group32byte (bool checked) {
    if (checked) group32byte();
}
