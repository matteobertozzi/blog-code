/* 
 * Copyright (C) 2009 Matteo Bertozzi.
 *
 * This file is part of THLibrary.
 * 
 * THLibrary is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * THLibrary is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with THLibrary.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <sys/socket.h>
#include <netinet/ip.h>

#include "sniffer.h"

#define BUFFER_SIZE     8192

/* ============================================================================
 *  PRIVATE Class
 */
class THSnifferPrivate {
    public:
        int protocol;
        bool abort;
};

/* ============================================================================
 *  PUBLIC Constructor/Destructor
 */
THSniffer::THSniffer (int protocol, QObject *parent)
    : QThread(parent), d(new THSnifferPrivate)
{
    d->abort = false;
    d->protocol = protocol;
}

THSniffer::~THSniffer() {
    delete d;
}

/* ============================================================================
 *  PUBLIC Slots
 */
void THSniffer::abort (void) {
    d->abort = true;
}

/* ============================================================================
 *  PROTECTED Methods
 */
void THSniffer::run (void) {
    char readBuf[BUFFER_SIZE];
    struct iphdr *ip_header;
    QByteArray buffer;
    ssize_t n;
    int sock;

    if ((sock = socket(PF_INET, SOCK_RAW, d->protocol)) < 0)
        return;

    while (!(d->abort) && (n = read(sock, readBuf, BUFFER_SIZE)) > 0) {
        buffer.append(readBuf, n);

        while (buffer.size() > 0) {
            /* Skip if There's no enought buffer for IP Header */
            if (buffer.size() < (int)sizeof(struct iphdr))
                break;

            /* Skif if Packet isn't in the buffer */
            ip_header = (struct iphdr *)buffer.constData();
            int packetSize = ntohs(ip_header->tot_len);
            if (buffer.size() < packetSize)
                break;

            /* Create new Packet, and emit Signal */
            emit newPacket(buffer.mid(0, packetSize));

            /* Remove the packet buffer */
            buffer.remove(0, packetSize);
        }
    }

    close(sock);
}

