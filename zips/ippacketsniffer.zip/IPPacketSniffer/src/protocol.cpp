/* 
 * Copyright (C) 2009 Matteo Bertozzi.
 *
 * This file is part of THLibrary.
 * 
 * THLibrary is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * THLibrary is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with THLibrary.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "protocol.h"

/* ============================================================================
 *  PRIVATE Class
 */
class THProtocolPrivate {
    public:
        int protocol;
};

/* ============================================================================
 *  PUBLIC Constructor/Destructor
 */
THProtocol::THProtocol (int protocol)
    : d(new THProtocolPrivate)
{
    d->protocol = protocol;
}

THProtocol::~THProtocol() {
    delete d;
}

/* ============================================================================
 *  PUBLIC Methods
 */
int THProtocol::id (void) const {
    return(d->protocol);
}

QString THProtocol::name (void) const {
    switch (d->protocol) {
        case   0: return("HOPOPT");
        case   1: return("ICMP");
        case   2: return("IGMP");
        case   3: return("GGP");
        case   4: return("IP");
        case   5: return("ST");
        case   6: return("TCP");
        case   7: return("CBT");
        case   8: return("EGP");
        case   9: return("IGP");
        case  10: return("BBN-RCC-MON");
        case  11: return("NVP-II");
        case  12: return("PUP");
        case  13: return("ARGUS");
        case  14: return("EMCON");
        case  15: return("XNET");
        case  16: return("CHAOS");
        case  17: return("UDP");
        case  18: return("MUX");
        case  19: return("DCN-MEAS");
        case  20: return("HMP");
        case  21: return("PRM");
        case  22: return("XNS-IDP");
        case  23: return("TRUNK-1");
        case  24: return("TRUNK-2");
        case  25: return("LEAF-1");
        case  26: return("LEAF-2");
        case  27: return("RDP");
        case  28: return("IRTP");
        case  29: return("ISO-TP4");
        case  30: return("NETBLT");
        case  31: return("MFE-NSP");
        case  32: return("MERIT-INP");
        case  33: return("DCCP");
        case  34: return("3PC");
        case  35: return("IDPR");
        case  36: return("XTP");
        case  37: return("DDP");
        case  38: return("IDPR-CMTP");
        case  39: return("TP++");
        case  40: return("IL");
        case  41: return("IPv6");
        case  42: return("SDRP");
        case  43: return("IPv6-Route");
        case  44: return("IPv6-Frag");
        case  45: return("IDRP");
        case  46: return("RSVP");
        case  47: return("GRE");
        case  48: return("DSR");
        case  49: return("BNA");
        case  50: return("ESP");
        case  51: return("AH");
        case  52: return("I-NLSP");
        case  53: return("SWIPE");
        case  54: return("NARP");
        case  55: return("MOBILE");
        case  56: return("TLSP");
        case  57: return("SKIP");
        case  58: return("IPv6-ICMP");
        case  59: return("IPv6-NoNxt");
        case  60: return("IPv6-Opts");
        case  61: return("any");
        case  62: return("CFTP");
        case  63: return("any");
        case  64: return("SAT-EXPAK");
        case  65: return("KRYPTOLAN");
        case  66: return("RVD");
        case  67: return("IPPC");
        case  68: return("any");
        case  69: return("SAT-MON");
        case  70: return("VISA");
        case  71: return("IPCV");
        case  72: return("CPNX");
        case  73: return("CPHB");
        case  74: return("WSN");
        case  75: return("PVP");
        case  76: return("BR-SAT-MON");
        case  77: return("SUN-ND");
        case  78: return("WB-MON");
        case  79: return("WB-EXPAK");
        case  80: return("ISO-IP");
        case  81: return("VMTP");
        case  82: return("SECURE-VMTP");
        case  83: return("VINES");
        case  84: return("TTP");
        case  85: return("NSFNET-IGP");
        case  86: return("DGP");
        case  87: return("TCF");
        case  88: return("EIGRP");
        case  89: return("OSPFIGP");
        case  90: return("Sprite-RPC");
        case  91: return("LARP");
        case  92: return("MTP");
        case  93: return("AX.25");
        case  94: return("IPIP");
        case  95: return("MICP");
        case  96: return("SCC-SP");
        case  97: return("ETHERIP");
        case  98: return("ENCAP");
        case  99: return("any");
        case 100: return("GMTP");
        case 101: return("IFMP");
        case 102: return("PNNI");
        case 103: return("PIM");
        case 104: return("ARIS");
        case 105: return("SCPS");
        case 106: return("QNX");
        case 107: return("A/N");
        case 108: return("IPComp");
        case 109: return("SNP");
        case 110: return("Compaq-Peer");
        case 111: return("IPX-in-IP");
        case 112: return("VRRP");
        case 113: return("PGM");
        case 114: return("any");
        case 115: return("L2TP");
        case 116: return("DDX");
        case 117: return("IATP");
        case 118: return("STP");
        case 119: return("SRP");
        case 120: return("UTI");
        case 121: return("SMP");
        case 122: return("SM");
        case 123: return("PTP");
        case 124: return("ISIS");
        case 125: return("FIRE");
        case 126: return("CRTP");
        case 127: return("CRUDP");
        case 128: return("SSCOPMCE");
        case 129: return("IPLT");
        case 130: return("SPS");
        case 131: return("PIPE");
        case 132: return("SCTP");
        case 133: return("FC");
        case 134: return("RSVP-E2E-IGNORE");
        case 135: return("Mobility");
        case 136: return("UDPLite");
        case 137: return("MPLS-in-IP");
        case 138: return("manet");
        case 139: return("HIP");
        case 140: return("Shim6");
    }
    return(QString());
}

QString THProtocol::description (void) const {
    switch (d->protocol) {
        case   0: return("IPv6 Hop-by-Hop Option [RFC1883]");
        case   1: return("Internet Control Message [RFC792]");
        case   2: return("Internet Group Management [RFC1112]");
        case   3: return("Gateway-to-Gateway [RFC823]");
        case   4: return("IP in IP (encapsulation) [RFC2003]");
        case   5: return("Stream [RFC1190][RFC1819]");
        case   6: return("Transmission Control [RFC793]");
        case   7: return("CBT [Ballardie]");
        case   8: return("Exterior Gateway Protocol [RFC888][DLM1]");
        case   9: return("any private interior gateway [IANA]");
        case  10: return("BBN RCC Monitoring [SGC]");
        case  11: return("Network Voice Protocol [RFC741][SC3]");
        case  12: return("PUP [PUP][XEROX]");
        case  13: return("ARGUS [RWS4]");
        case  14: return("EMCON [BN7]");
        case  15: return("Cross Net Debugger [IEN158][JFH2]");
        case  16: return("Chaos [NC3]");
        case  17: return("User Datagram [RFC768][JBP]");
        case  18: return("Multiplexing [IEN90][JBP]");
        case  19: return("DCN Measurement Subsystems [DLM1]");
        case  20: return("Host Monitoring [RFC869][RH6]");
        case  21: return("Packet Radio Measurement [ZSU]");
        case  22: return("XEROX NS IDP [ETHERNET][XEROX]");
        case  23: return("Trunk-1 [BWB6]");
        case  24: return("Trunk-2 [BWB6]");
        case  25: return("Leaf-1 [BWB6]");
        case  26: return("Leaf-2 [BWB6]");
        case  27: return("Reliable Data Protocol [RFC908][RH6]");
        case  28: return("Internet Reliable Transaction [RFC938][TXM]");
        case  29: return("ISO Transport Protocol Class 4 [RFC905][RC77]");
        case  30: return("Bulk Data Transfer Protocol [RFC969][DDC1]");
        case  31: return("MFE Network Services Protocol [MFENET][BCH2]");
        case  32: return("MERIT Internodal Protocol [HWB]");
        case  33: return("Datagram Congestion Control Protocol [RFC4340]");
        case  34: return("Third Party Connect Protocol [SAF3]");
        case  35: return("Inter-Domain Policy Routing Protocol [MXS1]");
        case  36: return("XTP [GXC]");
        case  37: return("Datagram Delivery Protocol [WXC]");
        case  38: return("IDPR Control Message Transport Proto [MXS1]");
        case  39: return("TP++ Transport Protocol [DXF]");
        case  40: return("IL Transport Protocol [Presotto]");
        case  41: return("Ipv6 [Deering]");
        case  42: return("Source Demand Routing Protocol [DXE1]");
        case  43: return("Routing Header for IPv6 [Deering]");
        case  44: return("Fragment Header for IPv6 [Deering]");
        case  45: return("Inter-Domain Routing Protocol [Hares]");
        case  46: return("Reservation Protocol [Braden]");
        case  47: return("General Routing Encapsulation [Li]");
        case  48: return("Dynamic Source Routing Protocol [RFC4728]");
        case  49: return("BNA [Salamon]");
        case  50: return("Encap Security Payload [RFC4303]");
        case  51: return("Authentication Header [RFC4302]");
        case  52: return("Integrated Net Layer Security TUBA [GLENN]");
        case  53: return("IP with Encryption [JI6]");
        case  54: return("NBMA Address Resolution Protocol [RFC1735]");
        case  55: return("IP Mobility [Perkins]");
        case  56: return("Transport Layer Security Protocol [Oberg]");
        case  57: return("SKIP [Markson]");
        case  58: return("ICMP for IPv6 [RFC1883]");
        case  59: return("No Next Header for IPv6 [RFC1883]");
        case  60: return("Destination Options for IPv6 [RFC1883]");
        case  61: return("host internal protocol [IANA]");
        case  62: return("CFTP [CFTP][HCF2]");
        case  63: return("local network [IANA]");
        case  64: return("SATNET and Backroom EXPAK [SHB]");
        case  65: return("Kryptolan [PXL1]");
        case  66: return("MIT Remote Virtual Disk Protocol [MBG]");
        case  67: return("Internet Pluribus Packet Core [SHB]");
        case  68: return("distributed file system [IANA]");
        case  69: return("SATNET Monitoring [SHB]");
        case  70: return("VISA Protocol [GXT1]");
        case  71: return("Internet Packet Core Utility [SHB]");
        case  72: return("Computer Protocol Network Executive [DXM2]");
        case  73: return("Computer Protocol Heart Beat [DXM2]");
        case  74: return("Wang Span Network [VXD]");
        case  75: return("Packet Video Protocol [SC3]");
        case  76: return("Backroom SATNET Monitoring [SHB]");
        case  77: return("SUN ND PROTOCOL-Temporary [WM3]");
        case  78: return("WIDEBAND Monitoring [SHB]");
        case  79: return("WIDEBAND EXPAK [SHB]");
        case  80: return("ISO Internet Protocol [MTR]");
        case  81: return("VMTP [DRC3]");
        case  82: return("SECURE-VMTP [DRC3]");
        case  83: return("VINES [BXH]");
        case  84: return("TTP [JXS]");
        case  85: return("NSFNET-IGP [HWB]");
        case  86: return("Dissimilar Gateway Protocol [DGP][ML109]");
        case  87: return("TCF [GAL5]");
        case  88: return("EIGRP [CISCO][GXS]");
        case  89: return("OSPFIGP [RFC1583][JTM4]");
        case  90: return("Sprite RPC Protocol [SPRITE][BXW]");
        case  91: return("Locus Address Resolution Protocol [BXH]");
        case  92: return("Multicast Transport Protocol [SXA]");
        case  93: return("AX.25 Frames [BK29]");
        case  94: return("IP-within-IP Encapsulation Protocol [JI6]");
        case  95: return("Mobile Internetworking Control Pro. [JI6]");
        case  96: return("Semaphore Communications Sec. Pro. [HXH]");
        case  97: return("Ethernet-within-IP Encapsulation [RFC3378]");
        case  98: return("Encapsulation Header [RFC1241,RXB3]");
        case  99: return("private encryption scheme [IANA]");
        case 100: return("GMTP [RXB5]");
        case 101: return("Ipsilon Flow Management Protocol [Hinden]");
        case 102: return("PNNI over IP [Callon]");
        case 103: return("Protocol Independent Multicast [Farinacci]");
        case 104: return("ARIS [Feldman]");
        case 105: return("SCPS [Durst]");
        case 106: return("QNX [Hunter]");
        case 107: return("Active Networks [Braden]");
        case 108: return("IP Payload Compression Protocol [RFC2393]");
        case 109: return("Sitara Networks Protocol [Sridhar]");
        case 110: return("Compaq Peer Protocol [Volpe]");
        case 111: return("IPX in IP [Lee]");
        case 112: return("Virtual Router Redundancy Protocol [RFC3768]");
        case 113: return("PGM Reliable Transport Protocol [Speakman]");
        case 114: return("0-hop protocol [IANA]");
        case 115: return("Layer Two Tunneling Protocol [Aboba]");
        case 116: return("D-II Data Exchange (DDX) [Worley]");
        case 117: return("Interactive Agent Transfer Protocol [Murphy]");
        case 118: return("Schedule Transfer Protocol [JMP]");
        case 119: return("SpectraLink Radio Protocol [Hamilton]");
        case 120: return("UTI [Lothberg]");
        case 121: return("Simple Message Protocol [Ekblad]");
        case 122: return("SM [Crowcroft]");
        case 123: return("Performance Transparency Protocol [Welzl]");
        case 124: return("over IPv4 [Przygienda]");
        case 125: return("[Partridge]");
        case 126: return("Combat Radio Transport Protocol [Sautter]");
        case 127: return("Combat Radio User Datagram [Sautter]");
        case 128: return("[Waber]");
        case 129: return("[Hollbach]");
        case 130: return("Secure Packet Shield [McIntosh]");
        case 131: return("Private IP Encapsulation within IP [Petri]");
        case 132: return("Stream Control Transmission Protocol [Stewart]");
        case 133: return("Fibre Channel [Rajagopal]");
        case 134: return("[RFC3175]");
        case 135: return("Header [RFC3775]");
        case 136: return("[RFC3828]");
        case 137: return("[RFC4023]");
        case 138: return("MANET Protocols [RFC5498]");
        case 139: return("Host Identity Protocol [RFC5201]");
        case 140: return("Shim6 Protocol [RFC-ietf-shim6-proto-12.txt]");
    }
    return(QString());
}

