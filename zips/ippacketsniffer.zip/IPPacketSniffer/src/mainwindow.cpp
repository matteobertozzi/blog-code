/* 
 * Copyright (C) 2009 Matteo Bertozzi.
 *
 * This file is part of THLibrary.
 * 
 * THLibrary is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * THLibrary is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with THLibrary.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <sys/socket.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>

#include <QFileDialog>
#include <QHeaderView>
#include <QTreeView>
#include <QFile>

#include "ui_mainwindow.h"

#include "packetlistmodel.h"
#include "mainwindow.h"
#include "tcpheader.h"
#include "ipheader.h"
#include "sniffer.h"

/* ============================================================================
 *  PRIVATE Class
 */
class THMainWindowPrivate {
    public:
        THPacketListModel *model; 
        THSniffer *sniffer;

        Ui::MainWindow ui;

    public:
        void displayIpHeader (const char *data) const;
        void displayNullIpHeader (void) const;

        void displayTcpHeader (const char *data) const;
        void displayNullTcpHeader (void) const;
};

void THMainWindowPrivate::displayIpHeader (const char *data) const {
    THIpHeader ip(data);

    ui.labelIpVersion->setText(ip.versionInfo());
    ui.labelIpIhl->setText(ip.internetHeaderLengthInfo());
    ui.labelIpTos->setText(ip.typeOfServiceInfo());
    ui.labelIpTotLen->setText(ip.totalLengthInfo());
    ui.labelIpId->setText(ip.idInfo());
    ui.labelIpOffset->setText(ip.fragmentOffsetInfo());
    ui.labelIpTtl->setText(ip.timeToLiveInfo());
    ui.labelIpProtocol->setText(ip.protocolInfo());
    ui.labelIpChecksum->setText(ip.checksumInfo());
    ui.labelIpSource->setText(ip.sourceInfo());
    ui.labelIpDestination->setText(ip.destinationInfo());
}

void THMainWindowPrivate::displayNullIpHeader (void) const {
    QString emptyString;

    ui.labelIpVersion->setText(emptyString);
    ui.labelIpIhl->setText(emptyString);
    ui.labelIpTos->setText(emptyString);
    ui.labelIpTotLen->setText(emptyString);
    ui.labelIpId->setText(emptyString);
    ui.labelIpOffset->setText(emptyString);
    ui.labelIpTtl->setText(emptyString);
    ui.labelIpProtocol->setText(emptyString);
    ui.labelIpChecksum->setText(emptyString);
    ui.labelIpSource->setText(emptyString);
    ui.labelIpDestination->setText(emptyString);
}

void THMainWindowPrivate::displayTcpHeader (const char *data) const {
    THTcpHeader tcp(data);

    ui.labelTcpSourcePort->setText(tcp.sourcePortInfo());
    ui.labelTcpDestPort->setText(tcp.destinationPortInfo());
    ui.labelTcpSeq->setText(tcp.sequenceInfo());
    ui.labelTcpAckSeq->setText(tcp.ackSequenceInfo());
    ui.labelTcpSegOff->setText(tcp.segmentOffsetInfo());
    ui.labelTcpUrg->setText(tcp.urgentInfo());
    ui.labelTcpAck->setText(tcp.ackInfo());
    ui.labelTcpPush->setText(tcp.pushInfo());
    ui.labelTcpReset->setText(tcp.resetInfo());
    ui.labelTcpSyn->setText(tcp.synchronizationInfo());
    ui.labelTcpFin->setText(tcp.finalInfo());
    ui.labelTcpWindow->setText(tcp.windowInfo());
    ui.labelTcpChecksum->setText(tcp.checksumInfo());
    ui.labelTcpUrgPtr->setText(tcp.urgentPointerInfo());
}

void THMainWindowPrivate::displayNullTcpHeader (void) const {
    QString emptyString;

    ui.labelTcpSourcePort->setText(emptyString);
    ui.labelTcpDestPort->setText(emptyString);
    ui.labelTcpSeq->setText(emptyString);
    ui.labelTcpAckSeq->setText(emptyString);
    ui.labelTcpSegOff->setText(emptyString);
    ui.labelTcpUrg->setText(emptyString);
    ui.labelTcpAck->setText(emptyString);
    ui.labelTcpPush->setText(emptyString);
    ui.labelTcpReset->setText(emptyString);
    ui.labelTcpSyn->setText(emptyString);
    ui.labelTcpFin->setText(emptyString);
    ui.labelTcpWindow->setText(emptyString);
    ui.labelTcpChecksum->setText(emptyString);
    ui.labelTcpUrgPtr->setText(emptyString);
}

/* ============================================================================
 *  PUBLIC Constructor/Destructor
 */
THMainWindow::THMainWindow (QWidget *parent)
    : QMainWindow(parent), d(new THMainWindowPrivate)
{
    d->sniffer = NULL;
    d->ui.setupUi(this);

    // Initialize Model and View
    d->model = new THPacketListModel;
    d->ui.packetView->setModel(d->model);
    d->ui.packetView->header()->hideSection(0);
    d->ui.packetView->header()->hideSection(2);
    d->ui.packetView->header()->hideSection(6);
    d->ui.packetView->header()->hideSection(7);
    d->ui.packetView->header()->hideSection(8);
    d->ui.packetView->header()->hideSection(9);
    connect(d->ui.packetView->selectionModel(), 
            SIGNAL(currentRowChanged(const QModelIndex&, const QModelIndex&)),
            this, SLOT(onPacketChanged(const QModelIndex&, const QModelIndex&)));

    // Run Sniffer
    runSniffer(IPPROTO_TCP);

    // Setup Menu Actions Events
    connect(d->ui.actionClearView, SIGNAL(triggered()), 
            this, SLOT(clearPacketView()));
    connect(d->ui.actionSave, SIGNAL(triggered()), this, SLOT(saveAll()));
    connect(d->ui.actionAboutQt, SIGNAL(triggered()), qApp, SLOT(aboutQt()));
}

THMainWindow::~THMainWindow() {
    delete d;
}

/* ============================================================================
 *  PUBLIC Slots
 */
void THMainWindow::saveAll (void) {
    QString dirName = QFileDialog::getExistingDirectory(this);
    if (dirName.isEmpty()) return;

    for (int i = 0; i < d->model->rowCount(); ++i) {
        QFile file(QString("%1/%2.packet").arg(dirName).arg(i));
        if (file.open(QIODevice::WriteOnly)) {
            QVariant data = d->model->data(d->model->index(i,
                                           THPacketListModel::PacketData));
            file.write(data.toByteArray());
            file.close();
        }
    }
}

void THMainWindow::clearPacketView (void) {
    d->model->removeRows(0, d->model->rowCount());
}

void THMainWindow::runSniffer (int protocol) {
    if (d->sniffer != NULL) {
        d->sniffer->exit(0);
        d->sniffer->deleteLater();
    }

    d->sniffer = new THSniffer(protocol);
    connect(d->sniffer, SIGNAL(newPacket(const QByteArray&)),
            d->model, SLOT(appendPacket(const QByteArray&)));
    d->sniffer->start();
}

/* ============================================================================
 *  PRIVATE Slots
 */
void THMainWindow::onPacketChanged (const QModelIndex& selected, 
                                    const QModelIndex& previous)
{
    Q_UNUSED(previous)

    if (!selected.isValid()) {
        QByteArray nullData;

        d->displayNullIpHeader();
        d->ui.ipRawView->setData(nullData);

        d->displayNullTcpHeader();
        d->ui.tcpDataView->setData(nullData);
        return;
    }

    // Get Packet Data
    QModelIndex dataIndex = d->model->index(selected.row(), 
                                            THPacketListModel::PacketData,
                                            selected.parent());
    QByteArray data = dataIndex.data().toByteArray();
    const char *p = data.constData();

    // Display IP Header
    struct iphdr *ip = (struct iphdr *)p;
    d->displayIpHeader(p);
    d->ui.ipRawView->setData(data);

    // Display TCP Header, if Packet is Tcp...
    if (ip->protocol == IPPROTO_TCP) {        
        d->displayTcpHeader(p + (ip->ihl * 4));

        struct tcphdr *tcp = (struct tcphdr *)(p + (ip->ihl * 4));

        int tcpDataLength = data.size() - (ip->ihl * 4) - (tcp->doff * 4);
        const char *tcpData = (p + (ip->ihl * 4) + (tcp->doff * 4));
        d->ui.tcpDataView->setData(QByteArray(tcpData, tcpDataLength));
    } else {
        d->ui.tcpDataView->setData(QByteArray());
        d->displayNullTcpHeader();
    }
}

