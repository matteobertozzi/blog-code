#!/usr/bin/env python

import string

def main():
    fd = open('iana-protonr.txt')
    while (True):
        line = fd.readline();
        if (line == ''):
            break

        try:
            while (line.index('  ') >= 0):
                line = line.replace('  ', ' ')
        except:
            pass

        parts = line.split(' ')
        if (len(parts) < 2):
            continue

        print 'case {0}: return(QString("{1}"));'.format(parts[0], string.join(parts[2:], ' ').strip());
    fd.close()

if (__name__ == '__main__'):
    main()

