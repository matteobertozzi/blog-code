using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OracleClient;

namespace OracleTests
{
    public class OracleDatabase
    {
        // ================================================================================
        //  PUBLIC Data Class (Typedefs)
        // ================================================================================
        public class DataRecord : Dictionary<string, object>
        {
            public DataRecord() : base() { }
        }

        // ================================================================================
        //  PRIVATE Members
        // ================================================================================
        private OracleConnection _oracle = null;

        // ================================================================================
        //  PUBLIC Constructors
        // ================================================================================
        public OracleDatabase()
        {
        }

        ~OracleDatabase()
        {
            Disconnect();
            _oracle = null;
        }

        // ================================================================================
        //  PUBLIC Methods
        // ================================================================================
        public bool Connect(string sid, string userId, string password)
        {
            string cs = String.Format("Data Source={0}; User Id={1}; Password={2};", sid, userId, password);
            _oracle = new OracleConnection(cs);
            _oracle.Open();
            return (_oracle.State == ConnectionState.Open);
        }

        public void Disconnect()
        {
            if (_oracle != null && _oracle.State != ConnectionState.Closed)
                _oracle.Close();
        }

        #region Methods: Execute Query
        public List<DataRecord> Execute(string query, params object[] args)
        {
            using (OracleCommand cmd = new OracleCommand(String.Format(query, args), _oracle))
            {
                cmd.CommandType = CommandType.Text;
                return (Execute(cmd));
            }
        }

        public int ExecuteNonQuery(string query, params object[] args)
        {
            using (OracleCommand cmd = new OracleCommand(String.Format(query, args), _oracle))
            {
                cmd.CommandType = CommandType.Text;
                return(cmd.ExecuteNonQuery());
            }
        }
        #endregion

        #region Methods: Execute Stored Procedure/Function
        public object ExecuteFunction(string query, params object[] args)
        {
            using (OracleCommand cmd = new OracleCommand(String.Format(query, args), _oracle))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                OracleParameter retParameter = new OracleParameter();
                retParameter.Direction = ParameterDirection.ReturnValue;
                retParameter.OracleType = OracleType.Number;
                cmd.Parameters.Add(retParameter);
                cmd.ExecuteNonQuery();
                return (retParameter.Value);
            }
        }

        public int ExecuteStoredProcedure(string query, params object[] args)
        {
            using (OracleCommand cmd = new OracleCommand(String.Format(query, args), _oracle))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                return (cmd.ExecuteNonQuery());
            }
        }
        #endregion

        // ================================================================================
        //  PRIVATE Methods
        // ================================================================================
        private List<DataRecord> Execute(OracleCommand cmd)
        {
            List<DataRecord> dataRecordList = new List<DataRecord>();
            using (OracleDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    DataRecord record = new DataRecord();
                    for (int i = 0; i < reader.FieldCount; ++i)
                        record.Add(reader.GetName(i), reader[i]);
                    dataRecordList.Add(record);
                }
                reader.Close();
            }
            return (dataRecordList);
        }

        // ================================================================================
        //  PUBLIC Properties
        // ================================================================================
        public string ServerVersion
        {
            get { return (_oracle != null ? _oracle.ServerVersion : null); }
        }
    }
}
