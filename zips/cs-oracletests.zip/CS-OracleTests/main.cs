using System;
using System.Collections.Generic;
using System.Text;

namespace OracleTests
{
    class Program
    {
        static void Main(string[] args)
        {
            OracleDatabase db = new OracleDatabase();
            db.Connect("192.168.0.3", "system", "password");
            Console.WriteLine(db.ServerVersion);

            // Create And Populate Tables
            db.ExecuteNonQuery("CREATE TABLE tb1 (a NUMBER NOT NULL, b CHAR(20))");
            db.ExecuteNonQuery("INSERT INTO tb1 (a, b) VALUES (10, 'Matteo')");
            db.ExecuteNonQuery("INSERT INTO tb1 (a, b) VALUES (20, 'Mauro')");

            db.ExecuteNonQuery("CREATE TABLE tb2 (a NUMBER NOT NULL, b CHAR(20))");
            db.ExecuteNonQuery("INSERT INTO tb2 (a, b) VALUES (10, 'San Francisco')");
            db.ExecuteNonQuery("INSERT INTO tb2 (a, b) VALUES (20, 'Cuppertino')");
            
            // A Store Procedure cannot Return Value
            StringBuilder sp1 = new StringBuilder();
            sp1.Append("CREATE OR REPLACE PROCEDURE tb2sp1 ");
            sp1.Append("IS ");
            sp1.Append("BEGIN ");
            sp1.Append("INSERT INTO tb1 (a, b) VALUES (30, 'SP1 TEST'); ");
            sp1.Append("END; ");
            db.ExecuteNonQuery(sp1.ToString());

            // A Function can Return a Value
            StringBuilder sp2 = new StringBuilder();
            sp2.Append("CREATE OR REPLACE function tb2sp2 (idx NUMBER) ");
            sp2.Append(" RETURN NUMBER ");
            sp2.Append("IS ");
            sp2.Append(" var_count NUMBER; ");
            sp2.Append("BEGIN ");
            sp2.Append(" SELECT COUNT(*) INTO var_count FROM tb1; ");
            sp2.Append(" return (var_count + idx); ");
            sp2.Append("END; ");
            db.ExecuteNonQuery(sp2.ToString());

            List<OracleDatabase.DataRecord> recordList1 = db.Execute("select * from tb1");
            List<OracleDatabase.DataRecord> recordList2 = db.Execute("select a, b, (a * 2 + 1) from tb1");
            List<OracleDatabase.DataRecord> recordList3 = db.Execute("select tb1.a as ID, tb1.b as NAME, tb2.b as PLACE from tb1 INNER JOIN tb2 ON tb1.a = tb2.a");
            db.ExecuteStoredProcedure("tb2sp1");
            List<OracleDatabase.DataRecord> recordList4 = db.Execute("select * from tb1");
            object sp2RetVal = db.ExecuteFunction("tb2sp2(10)");
            
            db.ExecuteNonQuery("DROP PROCEDURE tb2sp1");
            db.ExecuteNonQuery("DROP FUNCTION tb2sp2");
            db.ExecuteNonQuery("DROP TABLE tb2");
            db.ExecuteNonQuery("DROP TABLE tb1");
            db.Disconnect();
        }
    }
}
