//
//  AppController.m
//  TestQuickLook
//
//  Created by Matteo Bertozzi on 11/2/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "AppController.h"
#import "NSImage+QuickLook.h"

@implementation AppController

- (void)awakeFromNib {
	NSSize size;
	size.width = 160;
	size.height = 160;

	[imageView1 setImage:[NSImage imageWithPreviewOfFileAtPath:@"/Developer/About Xcode Tools.pdf" ofSize:size asIcon:YES]];	
	[imageView2 setImage:[NSImage imageWithPreviewOfFileAtPath:@"/Developer/About Xcode Tools.pdf" ofSize:size asIcon:NO]];
	
	[imageView3 setImage:[NSImage imageWithPreviewOfFileAtPath:@"/Users/oz/Movies/apple_new_macbook_video_20081014_848x480.mov" ofSize:size asIcon:YES]];
	[imageView4 setImage:[NSImage imageWithPreviewOfFileAtPath:@"/Users/oz/Movies/apple_new_macbook_video_20081014_848x480.mov" ofSize:size asIcon:NO]];
	
	[imageView5 setImage:[NSImage imageWithPreviewOfFileAtPath:@"/Users/oz/Pictures/Photo 8.jpg" ofSize:size asIcon:YES]];
	[imageView6 setImage:[NSImage imageWithPreviewOfFileAtPath:@"/Users/oz/Pictures/Photo 8.jpg" ofSize:size asIcon:NO]];
}

@end
