//
//  AppController.h
//  TestQuickLook
//
//  Created by Matteo Bertozzi on 11/2/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface AppController : NSObject {
	IBOutlet NSImageView *imageView1;
	IBOutlet NSImageView *imageView2;
	IBOutlet NSImageView *imageView3;	
	IBOutlet NSImageView *imageView4;	
	IBOutlet NSImageView *imageView5;	
	IBOutlet NSImageView *imageView6;			
}

@end
