#include <QDataStream>
#include <QTcpSocket>

#include "tcpechoserver.h"

#define DATA_TYPE_INT8			0
#define DATA_TYPE_INT16			1
#define DATA_TYPE_INT32			2
#define DATA_TYPE_INT64			3
#define DATA_TYPE_FLOAT			4
#define DATA_TYPE_DOUBLE		5
#define DATA_TYPE_STRING		6
#define DATA_TYPE_BYTEARRAY		7

TcpEchoServer::TcpEchoServer (QObject *parent)
	: QTcpServer(parent)
{
	m_socket = NULL;
	connect(this, SIGNAL(newConnection()), this, SLOT(onConnection()));
}

TcpEchoServer::~TcpEchoServer() {
}

void TcpEchoServer::onConnection (void) {
	QTcpSocket *tcpSocket = nextPendingConnection();

	if (m_socket != NULL) {
		// Server is Busy
		tcpSocket->close();
	} else {
		// Server is Free
		m_socket = tcpSocket;
		connect(m_socket, SIGNAL(disconnected()), this, SLOT(onDisconnection()));
		connect(m_socket, SIGNAL(readyRead()), this, SLOT(onDataReceived()));
	
		qDebug() << "Connection From" << m_socket->localAddress() 
				 << m_socket->peerAddress();
	}
}

void TcpEchoServer::onDataReceived (void) {
	quint8 dataType;
	
	QDataStream stream(m_socket);
	stream.setByteOrder(QDataStream::LittleEndian);
	stream >> dataType;

	m_socket->waitForReadyRead();
	switch (dataType) {
		case DATA_TYPE_INT8: {
			quint8 value0;
			stream >> value0;
			stream << dataType << value0;
			qDebug() << "Received UINT8" << value0;
			break;
		}
		case DATA_TYPE_INT16: {
			quint16 value1 = 0;
			stream >> value1;
			qDebug() << "Received UINT16" << value1;
			stream << dataType << value1;
			break;
		}
		case DATA_TYPE_INT32: {
			quint32 value2;
			stream >> value2;
			stream << dataType << value2;
			qDebug() << "Received UINT32" << value2;
			break;
		}
		case DATA_TYPE_INT64: {
			quint64 value3;
			stream >> value3;
			stream << dataType << value3;
			qDebug() << "Received UINT64" << value3;
			break;
		}
		case DATA_TYPE_FLOAT: {
			float value4;
			stream >> value4;
			stream << dataType << value4;
			qDebug() << "Received Float" << value4;
			break;
		}
		case DATA_TYPE_DOUBLE: {
			double value5;
			stream >> value5;
			stream << dataType << value5;
			qDebug() << "Received Double" << value5;
			break;
			break;
		}
		case DATA_TYPE_STRING: {
			QByteArray value6;
			stream >> value6;
			stream << dataType << value6;
			qDebug() << "Received QString" << value6;
			break;
		}
		case DATA_TYPE_BYTEARRAY: {
			QByteArray value7;
			stream >> value7;
			stream << dataType << value7;
			qDebug() << "Received QByteArray" << value7;
			break;
		}
		default: {
			qDebug() << "Received Invalid Data Type" << dataType;
			break;
		}
	}
}

void TcpEchoServer::onDisconnection (void) {
	qDebug() << "Socket Disconnected";
	m_socket = NULL;
}

