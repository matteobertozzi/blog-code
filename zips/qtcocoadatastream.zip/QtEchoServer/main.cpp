#include <QCoreApplication>
#include <QDebug>

#include "tcpechoserver.h"

#define SERVER_PORT				7543

int main (int argc, char **argv) {
	QCoreApplication app(argc, argv);

	TcpEchoServer tcpServer;
	if (!tcpServer.listen(QHostAddress::Any, SERVER_PORT))
		qFatal(tcpServer.errorString().toAscii().constData());

	return(app.exec());
}

