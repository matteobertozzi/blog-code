#ifndef _TCPECHOSERVER_H_
#define _TCPECHOSERVER_H_

#include <QTcpServer>

class TcpEchoServer : public QTcpServer {
	Q_OBJECT

	public:
		TcpEchoServer (QObject *parent = 0);
		~TcpEchoServer();

	private Q_SLOTS:
		void onConnection (void);
		void onDataReceived (void);
		void onDisconnection (void);

	private:
		QTcpSocket *m_socket;
};

#endif /* !_TCPECHOSERVER_H_ */

