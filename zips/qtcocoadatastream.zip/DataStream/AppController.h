#import <Cocoa/Cocoa.h>
@class THDataStream;

@interface AppController : NSObject {
	IBOutlet NSTextView *textView;
	THDataStream *dataStream;
	NSOutputStream *oStream;
	NSInputStream *iStream;
}

- (IBAction)connectToServer:(id)sender;
- (IBAction)disconnectFromServer:(id)sender;

- (IBAction)writeInt8:(id)sender;
- (IBAction)writeInt16:(id)sender;
- (IBAction)writeInt32:(id)sender;
- (IBAction)writeInt64:(id)sender;
- (IBAction)writeFloat:(id)sender;
- (IBAction)writeDouble:(id)sender;
- (IBAction)writeString:(id)sender;
- (IBAction)writeByteArray:(id)sender;

@end

