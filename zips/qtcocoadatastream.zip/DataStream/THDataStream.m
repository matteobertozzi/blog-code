#import "THDataStream.h"

@implementation THDataStream

@synthesize outputStream;
@synthesize inputStream;

- (id)init {
	if (self = [super init]) {
		outputStream = nil;
		inputStream = nil;
	}
	return self;
}

- (void)dealloc {
	[outputStream release];
	[inputStream release];
	[super dealloc];
}

- (void)skipRawData:(int)len {
	uint8_t buffer[1024];
	int size = 0;
	int readLen;

	do {
		readLen = (len - size) < 1024 ? (len - size) : 1024;
		size += [inputStream read:buffer maxLength:readLen];		
	} while (size < len);
}

- (void)writeRawData:(const uint8_t *)data length:(int)len {
	[outputStream write:data maxLength:len];
}

- (void)writeInt8:(uint8_t)value {
	[outputStream write:(const uint8_t *)&value maxLength:1];
}

- (void)writeInt16:(uint16_t)value {
	[outputStream write:(const uint8_t *)&value maxLength:2];
}

- (void)writeInt32:(uint32_t)value {
	[outputStream write:(const uint8_t *)&value maxLength:4];
}

- (void)writeInt64:(uint64_t)value {
	[outputStream write:(const uint8_t *)&value maxLength:8];
}

- (void)writeFloat:(float)value {
	[outputStream write:(const uint8_t *)&value maxLength:4];
}

- (void)writeDouble:(double)value {
	[outputStream write:(const uint8_t *)&value maxLength:8];
}

- (void)writeString:(NSString *)string {
	const char *data = [string UTF8String];
	size_t len = strlen(data);

	[self writeInt32:len];
	[self writeRawData:(const uint8_t *)data length:len];
}

- (void)writeByteArray:(NSData *)data {
	
	[self writeInt32:[[data length] intValue]];
	[self writeRawData:data length:[[data length] intValue]];
}

- (uint8_t)readInt8 {
	uint8_t value;
	[inputStream read:(uint8_t *)&value maxLength:1];
	return(value);
}

- (uint16_t)readInt16 {
	uint16_t value;
	[inputStream read:(uint8_t *)&value maxLength:2];
	return(value);
}

- (uint32_t)readInt32 {
	uint32_t value;
	[inputStream read:(uint8_t *)&value maxLength:4];
	return(value);
}

- (uint64_t)readInt64 {
	uint64_t value;
	[inputStream read:(uint8_t *)&value maxLength:8];
	return(value);
}

- (float)readFloat {
	float value;
	[inputStream read:(uint8_t *)&value maxLength:4];
	return(value);
}

- (double)readDouble {
	double value;
	[inputStream read:(uint8_t *)&value maxLength:8];
	return(value);
}

- (NSString *)readString {
	uint8_t buffer[1024];
	uint32_t size = 0;
	int readLen;

	uint32_t len = [self readInt32];
	NSMutableString *data = [NSMutableString stringWithCapacity:len];
	do {
		readLen = (len - size) < 1023 ? (len - size) : 1023;
		readLen = [inputStream read:buffer maxLength:readLen];
		buffer[readLen] = '\0';
		size += readLen;

		[data appendFormat:@"%s", buffer];
	} while (size < len);

	return(data);
}

- (NSData *)readByteArray {
	uint8_t buffer[1024];
	uint32_t size = 0;
	int readLen;

	uint32_t len = [self readInt32];
	NSMutableData *data = [NSMutableData dataWithLength:len];
	do {
		readLen = (len - size) < 1024 ? (len - size) : 1024;
		readLen = [inputStream read:buffer maxLength:readLen];
		size += readLen;

		[data appendBytes:buffer length:readLen];
	} while (size < len);

	return(data);
}

@end

