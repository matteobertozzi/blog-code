#import "THDataStream.h"
#import "AppController.h"

#define SERVER_HOSTNAME			@"192.168.3.1"
#define SERVER_PORT				7543

#define DATA_TYPE_INT8			0
#define DATA_TYPE_INT16			1
#define DATA_TYPE_INT32			2
#define DATA_TYPE_INT64			3
#define DATA_TYPE_FLOAT			4
#define DATA_TYPE_DOUBLE		5
#define DATA_TYPE_STRING		6
#define DATA_TYPE_BYTEARRAY		7

@implementation AppController

// ============================================================================
//  PRIVATE Methods
// ============================================================================
- (void)writeLog:(NSString *)logText {
	[textView insertText:logText];	
}

- (void)readData {
	uint8_t dataType = [dataStream readInt8];
	if (dataType == DATA_TYPE_INT8) {
		uint8_t value = [dataStream readInt8];
		[self writeLog:[NSString stringWithFormat:@" - Read Int8: %d\n", value]];
	} else if (dataType == DATA_TYPE_INT16) {
		uint16_t value = [dataStream readInt16];
		[self writeLog:[NSString stringWithFormat:@" - Read Int16: %d\n", value]];
	} else if (dataType == DATA_TYPE_INT32) {
		uint32_t value = [dataStream readInt32];
		[self writeLog:[NSString stringWithFormat:@" - Read Int32: %d\n", value]];
	} else if (dataType == DATA_TYPE_INT64) {
		uint64_t value = [dataStream readInt64];
		[self writeLog:[NSString stringWithFormat:@" - Read Int64: %d\n", value]];
	} else if (dataType == DATA_TYPE_FLOAT) {
		float value = [dataStream readFloat];
		[self writeLog:[NSString stringWithFormat:@" - Read Float: %f\n", value]];
	} else if (dataType == DATA_TYPE_DOUBLE) {
		double value = [dataStream readDouble];
		[self writeLog:[NSString stringWithFormat:@" - Read Double: %f\n", value]];
	} else if (dataType == DATA_TYPE_STRING) {
		NSString *value = [dataStream readString];
		[self writeLog:[NSString stringWithFormat:@" - Read String: %@\n", value]];
	} else if (dataType == DATA_TYPE_BYTEARRAY) {
		NSData *value = [dataStream readByteArray];
		[self writeLog:[NSString stringWithFormat:@" - Read Byte Array: %@\n", value]];
	} else {
		[self writeLog:[NSString stringWithFormat:@" - Read Invalid Type: %d\n", dataType]];
	}
}

// ============================================================================
//  Initializer/Destructor
// ============================================================================
- (void)awakeFromNib {
	dataStream = [[THDataStream alloc] init];
}

- (void)dealloc {
	[dataStream release];
	[super dealloc];
}

// ============================================================================
//  UI Methods
// ============================================================================
- (IBAction)connectToServer:(id)sender {
	// Setup Network Stream
	NSHost *host = [NSHost hostWithAddress:SERVER_HOSTNAME];
	[NSStream getStreamsToHost:host port:SERVER_PORT
					inputStream:&iStream outputStream:&oStream];
	[dataStream setOutputStream:oStream];
	[dataStream setInputStream:iStream];

	// Setup Delegate for Input Stream
	[iStream setDelegate:self];
	[iStream scheduleInRunLoop:[NSRunLoop currentRunLoop] 
					forMode:NSDefaultRunLoopMode];

	// Setup Delegate for Output Stream
	[oStream setDelegate:self];
	[oStream scheduleInRunLoop:[NSRunLoop currentRunLoop] 
					forMode:NSDefaultRunLoopMode];

	// Open Input/Output Stream
	[iStream open];
	[oStream open];
}

- (IBAction)disconnectFromServer:(id)sender {
	[[dataStream outputStream] close];
	[[dataStream inputStream] close];
	[dataStream setOutputStream:nil];
	[dataStream setInputStream:nil];
}

- (IBAction)writeInt8:(id)sender {
	[dataStream writeInt8:DATA_TYPE_INT8];
	[dataStream writeInt8:8];
}

- (IBAction)writeInt16:(id)sender {
	[dataStream writeInt8:DATA_TYPE_INT16];
	[dataStream writeInt16:16];
}

- (IBAction)writeInt32:(id)sender {
	[dataStream writeInt8:DATA_TYPE_INT32];
	[dataStream writeInt32:32];
}

- (IBAction)writeInt64:(id)sender {
	[dataStream writeInt8:DATA_TYPE_INT64];
	[dataStream writeInt64:64];
}

- (IBAction)writeFloat:(id)sender {
	[dataStream writeInt8:DATA_TYPE_FLOAT];
	[dataStream writeFloat:32.32];
}

- (IBAction)writeDouble:(id)sender {
	//[dataStream writeInt8:DATA_TYPE_DOUBLE];
	//[dataStream writeFloat:64.64];
}

- (IBAction)writeString:(id)sender {
	[dataStream writeInt8:DATA_TYPE_STRING];
	[dataStream writeString:@"Test Network String"];
}

- (IBAction)writeByteArray:(id)sender {
	//[dataStream writeByteArray:DATA_TYPE_BYTEARRAY];
}

// ============================================================================
//  Input/Output Streams Delegates
// ============================================================================
- (void)stream:(NSStream *)stream handleEvent:(NSStreamEvent)eventCode {
	if (stream == oStream)
		[self writeLog:[NSString stringWithFormat:@"Output Stream"]];
	else if (stream == iStream)
		[self writeLog:[NSString stringWithFormat:@"Input Stream"]];
	[self writeLog:[NSString stringWithFormat:@" - Stream Event %d\n", eventCode]];
	
	if (eventCode == NSStreamEventNone) {
		// No event has occurred.
		[self writeLog:[NSString stringWithFormat:@" - None\n"]];
	} else if (eventCode == NSStreamEventOpenCompleted) {
		// The open has completed successfully.
		[self writeLog:[NSString stringWithFormat:@" - Open Completed\n"]];
	} else if (eventCode == NSStreamEventHasBytesAvailable) {
		// The stream has bytes to be read.
		[self writeLog:[NSString stringWithFormat:@" - Has Bytes Available\n"]];
		[self readData];
	} else if (eventCode == NSStreamEventHasSpaceAvailable) {
		// The stream can accept bytes for writing.
		[self writeLog:[NSString stringWithFormat:@" - Has Space available\n"]];
	} else if (eventCode == NSStreamEventErrorOccurred) {
		// An error has occurred on the stream.
		[self writeLog:[NSString stringWithFormat:@" - Error Eccurred\n"]];
	} else if (eventCode == NSStreamEventEndEncountered) {
		// The end of the stream has been reached.
		[self writeLog:[NSString stringWithFormat:@" - End Encountered\n"]];
	}
}

@end

