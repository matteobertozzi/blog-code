#import <Foundation/Foundation.h>

@interface THDataStream : NSObject {
	NSOutputStream *outputStream;
	NSInputStream *inputStream;
}

@property (retain) NSOutputStream *outputStream;
@property (retain) NSInputStream *inputStream;

- (void)skipRawData:(int)len;
- (void)writeRawData:(const uint8_t *)data length:(int)len;

- (void)writeInt8:(uint8_t)value;
- (void)writeInt16:(uint16_t)value;
- (void)writeInt32:(uint32_t)value;
- (void)writeInt64:(uint64_t)value;

- (void)writeFloat:(float)value;
- (void)writeDouble:(double)value;

- (void)writeString:(NSString *)string;
- (void)writeByteArray:(NSData *)data;

- (uint8_t)readInt8;
- (uint16_t)readInt16;
- (uint32_t)readInt32;
- (uint64_t)readInt64;

- (float)readFloat;
- (double)readDouble;

- (NSString *)readString;
- (NSData *)readByteArray;

@end

