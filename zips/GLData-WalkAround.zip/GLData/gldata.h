#ifndef _GLDATA_H_
#define _GLDATA_H_

typedef unsigned int GLDataUInt;
typedef signed int GLDataInt;
typedef float GLDataFloat;

#define glDataBool(p)      ((GLDataBool *)(p))
#define GLDATA_FALSE       (0)
#define GLDATA_TRUE        (1)
typedef char GLDataBool;

typedef struct {
    GLDataUInt retainCount;
} GLDataType;

#define GLDATA_OBJECT                 GLDataType _base;
#define glDataGetBase(p)              (&(p->_base))
typedef void (*GLDataReleaseFunc) (void *data);

GLDataType *   _glDataInit            (GLDataType *data);
GLDataType *   _glDataRetain          (GLDataType *data);
GLDataBool     _glDataRelease         (GLDataType *data);
GLDataUInt     glDataGetRetainCount   (GLDataType *data);

typedef struct {
    GLDataFloat x;
    GLDataFloat y;
} GLDataUVPoint;

typedef struct {
    GLDataFloat x;
    GLDataFloat y;
    GLDataFloat z;
} GLDataPoint;

typedef struct {
    GLDataPoint a;
    GLDataPoint b;
    GLDataPoint c;
    GLDataPoint d;
} GLDataMatrix;

typedef struct {
    GLDATA_OBJECT

    GLDataUVPoint *points;
    GLDataUInt npoints;
} GLDataUVPolygon;

typedef struct {
    GLDATA_OBJECT

    GLDataPoint *points;
    GLDataUInt npoints;
} GLDataPolygon;

typedef struct {
    GLDATA_OBJECT

    GLDataUInt *points;
    GLDataUInt npoints;
} GLDataFace;

typedef GLDataPolygon GLDataTriangle;
typedef GLDataPolygon GLDataQuad;

typedef struct {
    GLDATA_OBJECT

    GLDataPolygon **polygons;
    GLDataUInt npolygons;
} GLDataSurface;

typedef struct {
    GLDATA_OBJECT

    GLDataUVPolygon **polygons;
    GLDataUInt npolygons;
} GLDataUVSurface;

typedef struct {
    GLDATA_OBJECT

    GLDataUInt height;
    GLDataUInt width;
    GLDataUInt id;
    char *name;
    char *data;
} GLDataImage;

typedef struct {
    GLDATA_OBJECT

    GLDataUVSurface *textureMap;
    GLDataImage *textureImage;
    GLDataSurface *surface;
    char *name;
} GLDataMesh;

/* UV Point */
#define        glDataUVPoint(p)       ((GLDataUVPoint *)(p))
GLDataUVPoint *glDataUVPointAlloc     (void);
void           glDataUVPointRelease   (GLDataUVPoint *point);

GLDataUVPoint *glDataUVPointInit      (GLDataUVPoint *uv,
                                       GLDataFloat x,
                                       GLDataFloat y);
GLDataUVPoint *glDataUVPointInitCopy  (GLDataUVPoint *uv,
                                       const GLDataUVPoint *other);

GLDataUVPoint *glDataUVPointCopy      (GLDataUVPoint *dest,
                                       const GLDataUVPoint *src);
GLDataBool     glDataUVPointEqual     (const GLDataUVPoint *point,
                                       const GLDataUVPoint *other);
GLDataBool     glDataUVPointNotEqual  (const GLDataUVPoint *point,
                                       const GLDataUVPoint *other);

/* Point */
#define        glDataPoint(p)         ((GLDataPoint *)(p))
GLDataPoint *  glDataPointAlloc       (void);
void           glDataPointRelease     (GLDataPoint *point);

GLDataPoint *  glDataPointInit        (GLDataPoint *point,
                                       GLDataFloat x,
                                       GLDataFloat y,
                                       GLDataFloat z);
GLDataPoint *  glDataPointInitCopy    (GLDataPoint *point,
                                       const GLDataPoint *other);

GLDataPoint *  glDataPointCopy        (GLDataPoint *dest,
                                       const GLDataPoint *src);
GLDataBool     glDataPointEqual       (const GLDataPoint *point,
                                       const GLDataPoint *other);
GLDataBool     glDataPointNotEqual    (const GLDataPoint *point,
                                       const GLDataPoint *other);

/* Face */
#define        glDataFace(p)          ((GLDataFace *)(p))
GLDataFace *   glDataFaceAlloc        (void);
GLDataFace *   glDataFaceInit         (GLDataFace *face,
                                       GLDataUInt npoints);
GLDataFace *   glDataFaceRetain       (GLDataFace *face);
void           glDataFaceRelease      (GLDataFace *face);
void           glDataFaceSetPoint     (GLDataFace *face,
                                       GLDataUInt index,
                                       GLDataUInt point);
void           glDataFaceSetPoints    (GLDataFace *face,
                                       GLDataUInt npoints,
                                       const GLDataUInt *points);

/* UV Polygon */
#define          glDataUVPolygon(p)        ((glDataUVPolygon *)(p))
GLDataUVPolygon *glDataUVPolygonAlloc      (void);
GLDataUVPolygon *glDataUVPolygonInit       (GLDataUVPolygon *polygon,
                                            GLDataUInt npoints);
GLDataUVPolygon *glDataUVPolygonRetain     (GLDataUVPolygon *polygon);
void             glDataUVPolygonRelease    (GLDataUVPolygon *polygon);
GLDataUVPoint *  glDataUVPolygonGetPoint   (GLDataUVPolygon *polygon,
                                            GLDataUInt index);
void             glDataUVPolygonSetPoint   (GLDataUVPolygon *polygon,
                                            GLDataUInt index,
                                            GLDataUVPoint *point);


/* Polygon */
#define         glDataPolygon(p)        ((GLDataPolygon *)(p))
GLDataPolygon * glDataPolygonAlloc      (void);
GLDataPolygon * glDataPolygonInit       (GLDataPolygon *polygon,
                                         GLDataUInt npoints);
GLDataPolygon * glDataPolygonRetain     (GLDataPolygon *polygon);
void            glDataPolygonRelease    (GLDataPolygon *polygon);
GLDataPoint *   glDataPolygonGetPoint   (GLDataPolygon *polygon,
                                         GLDataUInt index);
void            glDataPolygonSetPoint   (GLDataPolygon *polygon,
                                         GLDataUInt index,
                                         GLDataPoint *point);


/* Triangle */
#define         glDataTriangle(p)     ((GLDataTriangle *)(p))
GLDataTriangle *glDataTriangleAlloc   (void);
GLDataTriangle *glDataTriangleInit    (GLDataTriangle *triangle,
                                       GLDataPoint *a,
                                       GLDataPoint *b,
                                       GLDataPoint *c);
GLDataTriangle *glDataTriangleRetain  (GLDataTriangle *triangle);
void            glDataTriangleRelease (GLDataTriangle *triangle);


/* Quad */
#define         glDataQuad(p)         ((GLDataQuad *)(p))
GLDataQuad *    glDataQuadAlloc       (void);
GLDataQuad *    glDataQuadInit        (GLDataQuad *quad,
                                       GLDataPoint *a,
                                       GLDataPoint *b,
                                       GLDataPoint *c,
                                       GLDataPoint *d);
GLDataQuad *    glDataQuadRetain      (GLDataQuad *quad);
void            glDataQuadRelease     (GLDataQuad *quad);


/* UV Surface */
#define          glDataUVSurface(p)         ((GLDataUVSurface *)(p))
GLDataUVSurface *glDataUVSurfaceAlloc       (void);
GLDataUVSurface *glDataUVSurfaceInit        (GLDataUVSurface *surface,
                                             GLDataUInt npolygons);
GLDataUVSurface *glDataUVSurfaceRetain      (GLDataUVSurface *surface);
void             glDataUVSurfaceRelease     (GLDataUVSurface *surface);
GLDataUVPolygon *glDataUVSurfaceGetPolygon  (GLDataUVSurface *surface,
                                             GLDataUInt index);
void             glDataUVSurfaceSetPolygon  (GLDataUVSurface *surface,
                                             GLDataUInt index,
                                             GLDataUVPolygon *polygon);
void             glDataUVSurfaceSetPolygons (GLDataUVSurface *surface,
                                             GLDataUInt npolygons,
                                             GLDataUVPolygon **polygons);

/* Surface */
#define         glDataSurface(p)         ((GLDataSurface *)(p))
GLDataSurface * glDataSurfaceAlloc       (void);
GLDataSurface * glDataSurfaceInit        (GLDataSurface *surface,
                                          GLDataUInt npolygons);
GLDataSurface * glDataSurfaceRetain      (GLDataSurface *surface);
void            glDataSurfaceRelease     (GLDataSurface *surface);
GLDataPolygon * glDataSurfaceGetPolygon  (GLDataSurface *surface,
                                          GLDataUInt index);
void            glDataSurfaceSetPolygon  (GLDataSurface *surface,
                                          GLDataUInt index,
                                          GLDataPolygon *polygon);
void            glDataSurfaceSetPolygons (GLDataSurface *surface,
                                          GLDataUInt npolygons,
                                          GLDataPolygon **polygons);

/* Image */
#define        glDataImage(p)            ((GLDataImage *)(p))
GLDataImage *   glDataImageAlloc         (void);
GLDataImage *   glDataImageInit          (GLDataImage *image,
                                          const char *name);
GLDataImage *   glDataImageRetain        (GLDataImage *image);
void            glDataImageRelease       (GLDataImage *image);
void            glDataImageSetSize       (GLDataImage *image,
                                          GLDataUInt width,
                                          GLDataUInt height);
void            glDataImageSetData       (GLDataImage *image,
                                          void *data);
void            glDataImageSetId         (GLDataImage *image,
                                          GLDataUInt id);

/* Mesh */
#define         glDataMesh(p)             ((GLDataMesh *)(p))
GLDataMesh *    glDataMeshAlloc           (void);
GLDataMesh *    glDataMeshInit            (GLDataMesh *mesh);
GLDataMesh *    glDataMeshRetain          (GLDataMesh *mesh);
void            glDataMeshRelease         (GLDataMesh *mesh);
void            glDataMeshSetName         (GLDataMesh *mesh,
                                           const char *name);
void            glDataMeshSetSurface      (GLDataMesh *mesh,
                                           GLDataSurface *surface);
void            glDataMeshSetTextureMap   (GLDataMesh *mesh,
                                           GLDataUVSurface *textureMap);
void            glDataMeshSetTextureImage (GLDataMesh *mesh,
                                           GLDataImage *image);

/* Camera */
#define         glDataCamera(p)           ((GLDataCamera *)(p))

#endif /* !_GLDATA_H_ */

