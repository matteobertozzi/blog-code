/* 
 * How to Compile on Mac:
 *  gcc -o gldata -framework GLUT -framework OpenGL \
 *         `libpng12-config --cflags --libs` -L/usr/X11/lib \
 *         gldata.c gldatareader.c gldatamath.c gldatalist.c main.c
 *
 * How to Compile on GNU/Linux:
 *  gcc -o gldata -lglut -lGLU -lGL `libpng12-config --cflags --libs` \
 *         gldata.c gldatareader.c gldatamath.c gldatalist.c main.c
 * 
 * How to Use:
 *  ./gldata [gts file name]
 */

#if defined(__APPLE__)
    #include <OpenGL/gl.h>
	#include <OpenGL/glu.h>
    #include <GLUT/glut.h>
#else
    #include <GL/gl.h>
    #include <GL/glu.h>
    #include <GL/glut.h>
#endif

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "gldatareader.h"
#include "gldatamath.h"
#include "gldata.h"

GLfloat lightAmbient[] = { 0.5f, 0.5f, 50.5f, 1.0f };
GLfloat lightDiffuse[] = { 1.0f, 1.0f, 50.0f, 1.0f };
GLfloat lightPosition[] = { 0.0f, 0.0f, 50.0f, 1.0f };
static GLfloat tx = 0.0f, ty = 0.0f, tz = 0.0f;
static GLuint rx = 0, ry = 0, rz = 0;

#define VIEW_DISTANCE       (10.0)
#define TRANSLATE_DELTA     (1.0)
#define ROTATE_DELTA        (GLDATA_MATH_PI / 18.0)
typedef struct {
    GLDataPoint position;
    float yrotation;
    float floor;
    float theta;
} GLDataCamera;
GLDataCamera camera;

static GLuint object;

#define ANIMATION_TIMEOUT       (100)
static int animate = 0;

const char *mesh_name = NULL;

static void rotateCamera (GLuint dx, GLuint dy, GLuint dz) {
    rx = (rx + dx) % 360;
    ry = (ry + dy) % 360;
    rz = (rz + dz) % 360;
    glutPostRedisplay();
}

static void moveCamera (GLfloat dx, GLfloat dy, GLfloat dz) {
    tx += dx;
    ty += dy;
    tz += dz;
    glutPostRedisplay();
} 

static GLDataBool setupTexture (GLDataUInt index,
                                void *data,
                                void *userData)
{
    GLDataImage *image = glDataImage(data);
    GLuint textureId;

    glGenTextures(1, &textureId);
    glBindTexture(GL_TEXTURE_2D, textureId);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, 
                    GL_LINEAR_MIPMAP_NEAREST);
    glTexImage2D(GL_TEXTURE_2D, 0, 3, 
                 image->width, image->height, 
                 0, GL_RGB, GL_UNSIGNED_BYTE, image->data);
    gluBuild2DMipmaps(GL_TEXTURE_2D, 3, 
                      image->width, image->height, 
                      GL_RGB, GL_UNSIGNED_BYTE, image->data);

    glDataImageSetId(image, textureId);

    return(GLDATA_FALSE);
 }

static GLDataBool drawObject (GLDataUInt index,
                              void *data,
                              void *useTexture)
{
    GLDataPolygon *polygon;
    GLDataUVPolygon *uvMap;
    GLDataPoint *point;
    GLDataMesh *mesh;
    GLDataUInt i, j;

    glPushMatrix();

    mesh = glDataMesh(data);
    if (mesh->textureImage != NULL && *glDataBool(useTexture)) {
        glBindTexture(GL_TEXTURE_2D, mesh->textureImage->id);
        for (i = 0; i < mesh->surface->npolygons; ++i) {
            polygon = mesh->surface->polygons[i];
            uvMap = mesh->textureMap->polygons[i];

            glTexCoordPointer(2, GL_FLOAT, sizeof(GLDataUVPoint), uvMap->points);
            glVertexPointer(3, GL_FLOAT, sizeof(GLDataPoint), polygon->points);
            glDrawArrays(GL_POLYGON, 0, polygon->npoints);
        }
    } else {
        for (i = 0; i < mesh->surface->npolygons; ++i) {
            polygon = mesh->surface->polygons[i];

            glBegin(GL_LINE_LOOP);

            if (!strcmp(mesh->name, "hair2"))
                glColor4f(1.0, 1.0, 0.0, 0.0);
            else
                glColor4f(0.0, 0.0, 0.0, 0.5);
            for (j = 0; j < polygon->npoints; ++j) {
                point = &(polygon->points[j]);
                glVertex3f(point->x, point->y, point->z);
            }
            glEnd();
        }
    }    

    glPopMatrix();

    return(GLDATA_FALSE);
}

static void drawMesh (const char *fileName, GLDataBool useTexture) {
    GLDataReader *reader;

    if ((reader = glDataReaderAlloc()) == NULL)
        return;

    if (!glDataReaderRead(reader, fileName, GLDATA_FORMAT_GLD)) {
        perror("glDataReaderRead()");
        return;
    }

    if (useTexture)
        glDataListForeach(reader->textures, setupTexture, NULL);
    glDataListForeach(reader->meshes, drawObject, &useTexture);

    glDataReaderRelease(reader);
}

static void drawObjects (void) {
    drawMesh(mesh_name, GLDATA_TRUE);
}

void init (void) {
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);

#if 1
    glShadeModel(GL_SMOOTH);
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_BLEND);

    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glEnableClientState(GL_VERTEX_ARRAY);

    glLightfv(GL_LIGHT1, GL_AMBIENT,  lightAmbient);
    glLightfv(GL_LIGHT1, GL_DIFFUSE,  lightDiffuse);
    glLightfv(GL_LIGHT1, GL_POSITION, lightPosition);
    glEnable(GL_LIGHT1);
#else
    glShadeModel(GL_FLAT);
#endif

    camera.theta = 0.0f;
    camera.floor = 0.0f;
    camera.yrotation = 0.0f;
    glDataPointInit(&(camera.position), 0.0f, 0.0f, 0.0f);

    object = glGenLists(1);
    glNewList(object, GL_COMPILE);
    drawObjects();
    glEndList();
}

void displayHandler (void) {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();

    /* Camera */
    glRotatef(camera.floor, 1.0f, 0.0f, 0.0f);
    glRotatef(360.0f - camera.yrotation, 0.0f, 1.0f, 0.0f);
    glTranslatef(-camera.position.x, 
                 -camera.position.y - 0.25f, 
                 -camera.position.z - 6.0);
    
    glTranslatef(tx, ty, tz);
    glRotatef((GLfloat)rx, 0.0, 1.0, 0.0);
    glRotatef((GLfloat)ry, 1.0, 0.0, 0.0);
    glRotatef((GLfloat)rz, 0.0, 0.0, 1.0);

    glPushMatrix();
        glRotatef(-90.0, 1.0f, 0.0f, 0.0f);
        glCallList(object);
    glPopMatrix();

    glPopMatrix();

    glutSwapBuffers();
}

void reshapeHandler (int w, int h) {
    glViewport(0, 0, (GLsizei) w, (GLsizei)h); 

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0f, (GLfloat)w/(GLfloat)h, 0.1f, 500.0f);
}

void animationHandler (int value) {
    if (animate) {
        rx = (rx + 6) % 360;

        glutPostRedisplay();
        glutTimerFunc(ANIMATION_TIMEOUT, animationHandler, value);
    }
}

void specialHandler (int key, int x, int y) {
    if (key == GLUT_KEY_PAGE_UP) {
        camera.floor -= 0.5f;
    } else if (key == GLUT_KEY_PAGE_DOWN) {
        camera.floor += 1.5f;
    } else if (key == GLUT_KEY_UP) {
        float yrad = glDataDegToRad(camera.yrotation);
        camera.position.x -= sin(yrad);
        camera.position.z -= cos(yrad);
        if (camera.theta >= 359.0f)
            camera.theta = 0.0f;
        else
            camera.theta += 10.0f;
        camera.position.y = sin(glDataDegToRad(camera.theta)) / 20.0;
    } else if (key == GLUT_KEY_DOWN) {
        float yrad = glDataDegToRad(camera.yrotation);
        camera.position.x += sin(yrad);
        camera.position.z += cos(yrad);
        if (camera.theta <= 1.0f)
            camera.theta = 0.0f;
        else
            camera.theta -= 10.0f;
        camera.position.y = sin(glDataDegToRad(camera.theta)) / 20.0;
    } else if (key == GLUT_KEY_LEFT) {
        camera.yrotation += 6.5f;
    } else if (key == GLUT_KEY_RIGHT) {
        camera.yrotation -= 6.5f;
    }
    glutPostRedisplay();
}

void keyboardHandler (unsigned char key, int x, int y) {
    /* Rotate Camera */
    if (key == 'x' || key == 'X')
        rotateCamera((key == 'x') ? 5 : -5, 0, 0);
    else if (key == 'y' || key == 'Y')
        rotateCamera(0, (key == 'y') ? 5 : -5, 0);
    else if (key == 'z' || key == 'Z')
        rotateCamera(0, 0, (key == 'z') ? 5 : -5);

    /* Move Camera */
    else if (key == 'l')
        moveCamera(-0.2, 0.0, 0.0);
    else if (key == 'r')
        moveCamera(0.2, 0.0, 0.0);
    else if (key == 'u')
        moveCamera(0.0, 0.2, 0.0);
    else if (key == 'd')
        moveCamera(0.0, -0.2, 0.0);
    else if (key == 'i')
        moveCamera(0.0, 0.0, -1.0);
    else if (key == 'o')
        moveCamera(0.0, 0.0, 1.0);

    /* Start/Stop Animation */
    else if (key == 'p') {
        if ((animate = !animate))
            glutTimerFunc(ANIMATION_TIMEOUT, animationHandler, 1);
    }
}

int main (int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: gldata <mesh file>\n");
        return(1);
    }

    mesh_name = argv[1];

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_ALPHA | GLUT_DEPTH);

    glutInitWindowSize(800, 560); 
    glutInitWindowPosition(100, 100);
    
    glutCreateWindow("OpenGL Walk Around");

    init();
    glutDisplayFunc(displayHandler);
    /* glutFullScreen(); */

    glutReshapeFunc(reshapeHandler);
    glutSpecialFunc(specialHandler);
    glutKeyboardFunc(keyboardHandler);
    glutTimerFunc(ANIMATION_TIMEOUT, animationHandler, 1);

    glutMainLoop();
    return(0);
}


