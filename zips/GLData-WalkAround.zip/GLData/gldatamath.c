#include <math.h>

#include "gldatamath.h"

#define __mathSquare(x)         ((x) * (x))

void glDataPointSum (GLDataPoint *result,
                     const GLDataPoint *p1, 
                     const GLDataPoint *p2)
{
    result->x = p1->x + p2->x;
    result->y = p1->y + p2->y;
    result->z = p1->z + p2->z;
}

void glDataPointSub (GLDataPoint *result,
                     const GLDataPoint *p1, 
                     const GLDataPoint *p2)
{
    result->x = p1->x - p2->x;
    result->y = p1->y - p2->y;
    result->z = p1->z - p2->z;
}

void glDataPointMul (GLDataPoint *result,
                     const GLDataPoint *p, 
                     float k)
{
    result->x = p->x * k;
    result->y = p->y * k;
    result->z = p->z * k;
}

void glDataPointDiv (GLDataPoint *result,
                     const GLDataPoint *p1, 
                     float k)
{
    k = 1.0f / k;
    result->x = p1->x * k;
    result->y = p1->y * k;
    result->z = p1->z * k;
}

void glDataCrossProduct (GLDataPoint *result,
                         const GLDataPoint *p1, 
                         const GLDataPoint *p2)
{
    result->x = (p1->y * p2->z) - (p1->z * p2->y);
    result->y = (p1->z * p2->x) - (p1->x * p2->z);
    result->z = (p1->x * p2->y) - (p1->y * p2->x);
}

float glDataDotProduct (const GLDataPoint *p1, 
                        const GLDataPoint *p2)
{
    return((p1->x * p2->x) + (p1->y * p2->y) + (p1->z * p2->z));
}

void glDataPointInverted (GLDataPoint *result,
                          const GLDataPoint *p)
{
    result->x = -p->x;
    result->y = -p->y;
    result->z = -p->z;
}

void glDataPointNormalized (GLDataPoint *result,
                            const GLDataPoint *p)
{
    float k = 1.0f / glDataPointLength(p);
    result->x = p->x * k;
    result->y = p->y * k;
    result->z = p->z * k;
}

float glDataPointLength (const GLDataPoint *p) {
    return(sqrt(__mathSquare(glDataDotProduct(p, p))));
}

float glDataPointDistance (const GLDataPoint *p1, 
                           const GLDataPoint *p2)
{
    return(sqrt(__mathSquare(p2->x - p1->x) + 
                __mathSquare(p2->y - p1->y) +
                __mathSquare(p2->z - p1->z)));
}

GLDataBool glDataRayIntersectPlane (GlDataPlane *plane,
                                    GLDataPoint *position,
                                    GLDataPoint *direction)
{
    GLDataPoint p;
    float d, l;

    d = glDataDotProduct(direction, &(plane->normal));
    if (glDataIsZero(d))
        return(GLDATA_FALSE);

    glDataPointSub(&p, &(plane->position), position);
    l = glDataDotProduct(&(plane->normal), &p) / d;
    if (l < -GLDATA_EPSILON)
        return(GLDATA_FALSE);

    return(GLDATA_TRUE);
}

void glDataMatrixMultiply (GLDataMatrix *result, 
                           const GLDataMatrix *m1, 
                           const GLDataMatrix *m2)
{
}

