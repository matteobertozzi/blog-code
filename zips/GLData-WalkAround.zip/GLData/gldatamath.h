#ifndef _GLDATA_MATH_H_
#define _GLDATA_MATH_H_

#include "gldata.h"

#define GLDATA_MATH_PI          (3.1415926535897931f)
#define GLDATA_EPSILON          (1.0E-20)

#define glDataIsZero(x)         ((x) > -GLDATA_EPSILON && (x) < GLDATA_EPSILON)

#define glDataRadToDeg(rad)     ((rad * 180.0f) / GLDATA_MATH_PI)
#define glDataDegToRad(deg)     ((deg * GLDATA_MATH_PI) / 180.0f)

typedef struct {
    GLDataPoint position;
    GLDataPoint normal;
} GlDataPlane;

typedef struct {
    GLDataPoint position;
    GLDataPoint axis;
    float radius;
} GLDataCylinder;

void    glDataPointSum         (GLDataPoint *result,
                                const GLDataPoint *p1, 
                                const GLDataPoint *p2);
void    glDataPointSub         (GLDataPoint *result,
                                const GLDataPoint *p1, 
                                const GLDataPoint *p2);
void    glDataPointMul         (GLDataPoint *result,
                                const GLDataPoint *p1, 
                                float k);
void    glDataPointDiv         (GLDataPoint *result,
                                const GLDataPoint *p1, 
                                float k);

void    glDataCrossProduct     (GLDataPoint *result,
                                const GLDataPoint *p1, 
                                const GLDataPoint *p2);
float   glDataDotProduct       (const GLDataPoint *p1, 
                                const GLDataPoint *p2);

void    glDataPointInverted    (GLDataPoint *result,
                                const GLDataPoint *p);
void    glDataPointNormalized  (GLDataPoint *result,
                                const GLDataPoint *p);

float   glDataPointLength      (const GLDataPoint *p);
float   glDataPointDistance    (const GLDataPoint *p1, 
                                const GLDataPoint *p2);

GLDataBool glDataRayIntersectPlane (GlDataPlane *plane,
                                    GLDataPoint *position,
                                    GLDataPoint *direction);

#endif /* !_GLDATA_MATH_H_ */


