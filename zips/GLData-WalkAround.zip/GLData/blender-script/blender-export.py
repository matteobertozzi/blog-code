#!BPY
""" Registration info for Blender menus:
Name: 'GLData 1.0 (.gld)...'
Blender: 242
Group: 'Export'
Submenu: 'All Objects...' all
Tooltip: 'Export to GLData (.gld) file.'
"""

import Blender
from Blender import Object, Mesh, NMesh, Lamp, Draw, BGL, Image, Text
import bpy

import sys
import os

class GLDataExporter:
    def __init__(self, filename):
        self.filename = filename
        self.tp = 2

    def export(self, scene):
        self.file = open(self.filename, 'w')

        self.file.write('# GLData 0.1 Format');
        for obj in scene.objects:
            self.exportObj(obj)

        self.file.close()

    def exportObj(self, obj):
        objType = obj.getType()

        if objType == 'Mesh':
            self.exportMesh(obj)

        #elif objType == 'Camera':
        #elif objType == 'Lamp':

    def exportMesh(self, obj):
        import meshmap

        mesh = obj.getData()

        self.file.write('\n# %s' % ('-'*60))
        self.file.write('\nMESH %s\n' % (obj.name))

        #self.file.write('\nTEXTURE-IMAGES\n')
        #self.file.write(meshmap.map[obj.name] + '\n')
        #self.file.write('meshes/%s_diffuse.png\n' % (obj.name))

        self.exportMeshFaces(mesh)
        self.exportMeshTextureImage(mesh)
        self.exportMeshTextures(mesh)
        self.file.write('\nEND-MESH\n')


    def exportMeshFaces(self, mesh):
        self.file.write('\nVERTEXES\n')
        for v in mesh.verts:
            self.file.write('%f %f %f\n' % (v.co.x, v.co.y, v.co.z))

        self.file.write('\nFACES\n')
        for face in mesh.faces:
            for v in face.v:
                self.file.write('%i ' % (v.index))
            self.file.write('\n')

    def exportMeshTextures(self, mesh):
        if not mesh.hasFaceUV():
            return

        coord_list = []
        index_list = []

        # Store Texture UV/Indexes
        j = 0
        for face in mesh.faces:
            face_indexes = []
            for i in xrange(len(face)):
                face_indexes.append(j)
                coord_list.append(face.uv[i])
                j += 1
            index_list.append(face_indexes)

        self.file.write('\nTEXTURE-UVS\n')
        for uv in coord_list:
            x, y = uv[0], uv[1]
            self.file.write('%s %s\n' % (round(x, self.tp), round(y, self.tp)))

        self.file.write('\nTEXTURE-FACES\n')
        for face_indexes in index_list:
            for idx in face_indexes:
                self.file.write('%i ' % (idx))
            self.file.write('\n')

    def exportMeshTextureImage(self, mesh):
        texture_images = set()
        for face in mesh.faces:
            if face.image:
                texture_images.add(face.image.name)

        if len(texture_images) > 0:
            self.file.write('\nTEXTURE-IMAGES\n')
            for image_name in texture_images:
                self.file.write('%s\n' % (image_name))


def file_callback(filename):
    if os.path.exists(filename):
        result = Draw.PupMenu("File Already Exists, Overwrite?%t|Yes%x1|No%x0")
        if result != 1:
            return
        
    extension = '.gld'
    if not filename.endswith(extension):
        filename += extension

    glExporter = GLDataExporter(filename)
    scene = Blender.Scene.GetCurrent()
    glExporter.export(scene)

Blender.Window.FileSelector(file_callback, "Export GLData")

