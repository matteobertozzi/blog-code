#ifndef _GLDATA_READER_H_
#define _GLDATA_READER_H_

#include "gldatalist.h"
#include "gldata.h"

typedef enum {
    GLDATA_FORMAT_GLD,      /* GLData Own Format */
    GLDATA_FORMAT_GTS       /* GNU Triangulated Surface */
} GLDataFormat;

typedef struct {
    GLDataList *textures;
    GLDataList *meshes;
} GLDataReader;

GLDataReader *  glDataReaderAlloc   (void);
void            glDataReaderRelease (GLDataReader *reader);

GLDataBool      glDataReaderRead    (GLDataReader *reader,
                                     const char *filename,
                                     GLDataFormat format);

#endif /* !_GLDATA_READER_H_ */

