#include <stdlib.h>

#include "gldatalist.h"

struct _GLDataNode {
    void *data;
    struct _GLDataNode *prev;
    struct _GLDataNode *next;
};

struct _GLDataList {
    struct _GLDataNode *cachePointer;
    GLDataUInt cacheIndex;

    struct _GLDataNode *last;
    struct _GLDataNode *first;
    GLDataUInt size;
};

static struct _GLDataNode *__list_find_node (GLDataList *list, 
                                             void *data)
{
    struct _GLDataNode *p;

    for (p = list->first; p != NULL; p = p->next) {
        if (p->data == data)
            return(p);
    }

    return(NULL);
}

static struct _GLDataNode *__list_node_at (GLDataList *list, GLDataUInt index) {
    struct _GLDataNode *p;
    GLDataUInt i;

    if (index == 0)
        return(list->first);

    if (index == (list->size - 1))
        return(list->last);

    /* Try to use Cache to speed-up movements */
    if (list->cachePointer != NULL) {
        GLDataUInt deltaAbs;
        GLDataInt delta;

        if ((delta = (list->cacheIndex - index)) == 0)
            return(list->cachePointer);

        deltaAbs = ((delta < 0) ? -delta : delta);
        if (deltaAbs < index && deltaAbs < (list->size - index)) {
            if (delta < 0) {
                while (deltaAbs-- > 0)
                    list->cachePointer = list->cachePointer->next;
            } else {
                while (deltaAbs-- > 0)
                    list->cachePointer = list->cachePointer->prev;
            }

            list->cacheIndex = index;
            return(list->cachePointer);
        }
    }

    /* Scan All List From the most convenient part */
    if (index < (list->size >> 1)) {
        for (i = 0, p = list->first; p != NULL; p = p->next, ++i) {
            if (i == index) {
                list->cachePointer = p;
                list->cacheIndex = index;
                return(p);
            }
        }
    } else {
        for (i = (list->size-1), p = list->last; p != NULL; p = p->prev, --i) {
            if (i == index) {
                list->cachePointer = p;
                list->cacheIndex = index;
                return(p);
            }
        }
    }

    return(NULL);
}

GLDataList *glDataListAlloc (void) {
    GLDataList *list;

    if ((list = (GLDataList *) malloc(sizeof(GLDataList))) == NULL)
        return(NULL);

    list->cachePointer = NULL;
    list->cacheIndex = 0;
    list->first = NULL;
    list->last = NULL;
    list->size = 0;

    return(list);
}

void glDataListRelease (GLDataList *list) {
    if (list != NULL) {
        glDataListClear(list, NULL);
        free(list);
    }
}

void glDataListClear (GLDataList *list, GLDataReleaseFunc releaseFunc) {
    if (list != NULL) {
        struct _GLDataNode *node;

        list->cachePointer = NULL;
        while (list->first != NULL) {
            if ((node = list->first->next) != NULL)
                node->prev = NULL;

            /* Update Last Item If Necessary */
            if (list->first == list->last)
                list->last = node;

            /* Release First Item */
            if (releaseFunc != NULL)
                releaseFunc(list->first->data);
            free(list->first);

            /* Set New First Node */
            list->first = node;
            list->size--;
        }
    }
}

GLDataUInt glDataListSize (GLDataList *list) {
    if (list == NULL) return(0);
    return(list->size);
}

GLDataBool glDataListAppend (GLDataList *list, void *data) {
    struct _GLDataNode *node;

    if (!(node = (struct _GLDataNode *) malloc(sizeof(struct _GLDataNode))))
        return(GLDATA_FALSE);

    node->next = NULL;
    node->data = data;

    if (list->last != NULL)
        list->last->next = node;
    node->prev = list->last;
    list->last = node;

    if (list->first == NULL)
        list->first = node;

    list->size++;

    return(GLDATA_TRUE);
}

void *glDataListAt (GLDataList *list, GLDataUInt index) {
    struct _GLDataNode *node;

    if ((node = __list_node_at(list, index)) != NULL)
        return(node->data);

    return(NULL);
}

GLDataBool glDataListContains (GLDataList *list, void *data) {
    return(__list_find_node(list, data) != NULL);
}

void glDataListForeach (GLDataList *list,
                        GLDataForeachFunc func,
                        void *userData)
{
    struct _GLDataNode *p;
    GLDataUInt i;

    for (i = 0, p = list->first; p != NULL; p = p->next, ++i) {
        if (func(i, p->data, userData))
            break;
    }
}

void *glDataListSearch (GLDataList *list,
                        GLDataSearchCmpFunc cmpFunc,
                        void *userData)
{
    struct _GLDataNode *p;

    for (p = list->first; p != NULL; p = p->next) {
        if (cmpFunc(p->data, userData))
            return(p->data);
    }

    return(NULL);
}


