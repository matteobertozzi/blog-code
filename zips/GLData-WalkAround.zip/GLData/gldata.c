#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "gldata.h"

#define glDataNullSkip(p)           if (p == NULL) return;
#define glDataNullReturn(p, v)      if (p == NULL) return(v);

#if defined(GLDATA_DEBUG)
    #define glDataDebug(x)          fprintf(stderr, x)
#else
    #define glDataDebug(x)          if (1) {} else fprintf(stderr, x)
#endif

/**
 * ===========================================================================
 * GLDataType:
 * Base class for all GLData Objects. 
 * It contains helper for Retain/Release Allocation Model.
 */
GLDataType *_glDataInit (GLDataType *data) {
    data->retainCount = 1;
    return(data);
}

GLDataType *_glDataRetain (GLDataType *data) {
    data->retainCount++;
    return(data);
}

GLDataBool _glDataRelease (GLDataType *data) {
    return((--(data->retainCount)) == 0);
}

GLDataUInt glDataGetRetainCount (GLDataType *data) {
    return(data->retainCount);
}

/**
 * GLDataUVPoint:
 * Represents a 2d Point (UV).
 */
GLDataUVPoint *glDataUVPointAlloc (void) {
    GLDataUVPoint *uv;

    uv = (GLDataUVPoint *) malloc(sizeof(GLDataUVPoint));
    glDataNullReturn(uv, NULL);

    uv->x = 0;
    uv->y = 0;

    return(uv);
}

void glDataUVPointRelease (GLDataUVPoint *uv) {
    if (uv != NULL)
        free(uv);
}

GLDataUVPoint *glDataUVPointInit (GLDataUVPoint *uv,
                                  GLDataFloat x,
                                  GLDataFloat y)
{
    glDataNullReturn(uv, NULL);

    uv->x = x;
    uv->y = y;

    return(uv);
}

GLDataUVPoint *glDataUVPointInitCopy (GLDataUVPoint *uv,
                                      const GLDataUVPoint *other)
{
    glDataNullReturn(uv, NULL);
    glDataNullReturn(other, NULL);

    uv->x = other->x;
    uv->y = other->y;

    return(uv);
}

GLDataUVPoint *glDataUVPointCopy (GLDataUVPoint *dest,
                                  const GLDataUVPoint *src)
{
    glDataNullReturn(dest, NULL);
    glDataNullReturn(src, dest);

    dest->x = src->x;
    dest->y = src->y;
    return(dest);
}

GLDataBool glDataUVPointEqual (const GLDataUVPoint *point,
                               const GLDataUVPoint *other)
{
    glDataNullReturn(point, GLDATA_FALSE);
    glDataNullReturn(other, GLDATA_FALSE);
    return((point->x != other->x) && (point->y != other->y));
}

GLDataBool glDataUVPointNotEqual (const GLDataUVPoint *point,
                                  const GLDataUVPoint *other)
{
    return(!glDataUVPointNotEqual(point, other));
}

/**
 * ===========================================================================
 * GLDataPoint: 
 * Represents a 3d point.
 */
GLDataPoint *glDataPointAlloc (void) {
    GLDataPoint *point;

    point = (GLDataPoint *) malloc(sizeof(GLDataPoint));
    glDataNullReturn(point, NULL);

    point->x = 0;
    point->y = 0;

    return(point);
}

void glDataPointRelease (GLDataPoint *point) {
    if (point != NULL)
        free(point);
}

GLDataPoint *glDataPointInit (GLDataPoint *point,
                              GLDataFloat x,
                              GLDataFloat y,
                              GLDataFloat z)
{
    glDataNullReturn(point, NULL);

    point->x = x;
    point->y = y;
    point->z = z;

    return(point);
}

GLDataPoint *glDataPointInitCopy (GLDataPoint *point,
                                  const GLDataPoint *other)
{
    glDataNullReturn(point, NULL);
    glDataNullReturn(other, NULL);

    point->x = other->x;
    point->y = other->y;
    point->z = other->z;

    return(point);
}

GLDataPoint *glDataPointCopy (GLDataPoint *dest,
                              const GLDataPoint *src)
{
    glDataNullReturn(dest, NULL);
    glDataNullReturn(src, dest);

    dest->x = src->x;
    dest->y = src->y;
    dest->z = src->z;
    return(dest);
}

GLDataBool glDataPointEqual (const GLDataPoint *point,
                             const GLDataPoint *other)
{
    glDataNullReturn(point, GLDATA_FALSE);
    glDataNullReturn(other, GLDATA_FALSE);

    return((point->x != other->x) && 
           (point->y != other->y) && 
           (point->z != other->z));
}

GLDataBool glDataPointNotEqual (const GLDataPoint *point,
                                const GLDataPoint *other)
{
    return(!glDataPointEqual(point, other));
}

/**
 * ===========================================================================
 * GLDataFace: 
 * Represents a 3d Face.
 */
GLDataFace *glDataFaceAlloc (void) {
    GLDataFace *face;

    /* Alloc GLData Face */
    face = (GLDataFace *) malloc(sizeof(GLDataFace));
    glDataNullReturn(face, NULL);    

    return(face);
}

GLDataFace *glDataFaceInit (GLDataFace *face,
                            GLDataUInt npoints)
{
    glDataNullReturn(face, NULL);

    _glDataInit(glDataGetBase(face));
    face->points = (GLDataUInt *) malloc(npoints * sizeof(GLDataUInt));
    face->npoints = npoints;

    return(face);
}

GLDataFace *glDataFaceRetain (GLDataFace *face) {
    glDataNullReturn(face, NULL);

    _glDataRetain(glDataGetBase(face));
    return(face);
}

void glDataFaceRelease (GLDataFace *face) {
    glDataNullSkip(face);

    if (_glDataRelease(glDataGetBase(face))) {
        glDataDebug("[D] glDataFace Release\n");
        free(face->points);
        free(face);
    }
}

void glDataFaceSetPoint (GLDataFace *face,
                         GLDataUInt index,
                         GLDataUInt point)
{
    glDataNullSkip(face);
    face->points[index] = point;
}

void glDataFaceSetPoints (GLDataFace *face,
                          GLDataUInt npoints,
                          const GLDataUInt *points)
{
    GLDataUInt i;

    glDataNullSkip(face);

    for (i = 0; i < npoints; ++i)
        face->points[i] = points[i];
}


/**
 * ===========================================================================
 * GLDataPolygon: 
 * Represents a 3d Polygon.
 */
GLDataUVPolygon *glDataUVPolygonAlloc (void) {
    GLDataUVPolygon *polygon;

    /* Alloc GLData Polygon */
    polygon = (GLDataUVPolygon *) malloc(sizeof(GLDataUVPolygon));
    glDataNullReturn(polygon, NULL);    

    return(polygon);
}

GLDataUVPolygon *glDataUVPolygonInit (GLDataUVPolygon *polygon,
                                      GLDataUInt npoints)
{
    glDataNullReturn(polygon, NULL);

    _glDataInit(glDataGetBase(polygon));
    polygon->points = (GLDataUVPoint *) malloc(npoints * sizeof(GLDataUVPoint));
    memset(polygon->points, 0, npoints * sizeof(GLDataUVPoint));
    polygon->npoints = npoints;

    return(polygon);
}

GLDataUVPolygon *glDataUVPolygonRetain (GLDataUVPolygon *polygon) {
    glDataNullReturn(polygon, NULL);

    _glDataRetain(glDataGetBase(polygon));
    return(polygon);
}

void glDataUVPolygonRelease (GLDataUVPolygon *polygon) {
    glDataNullSkip(polygon);

    if (_glDataRelease(glDataGetBase(polygon))) {
        glDataDebug("[D] glDataUVPolygon Release\n");

        free(polygon->points);
        free(polygon);
    }
}

GLDataUVPoint *glDataUVPolygonGetPoint (GLDataUVPolygon *polygon,
                                        GLDataUInt index)
{
    glDataNullReturn(polygon, NULL);
    return(&(polygon->points[index]));
}

void glDataUVPolygonSetPoint (GLDataUVPolygon *polygon,
                              GLDataUInt index,
                              GLDataUVPoint *point)
{
    glDataNullSkip(polygon);

    glDataUVPointInitCopy(&(polygon->points[index]), point);
}

/**
 * ===========================================================================
 * GLDataPolygon: 
 * Represents a 3d Polygon.
 */
GLDataPolygon *glDataPolygonAlloc (void) {
    GLDataPolygon *polygon;

    /* Alloc GLData Polygon */
    polygon = (GLDataPolygon *) malloc(sizeof(GLDataPolygon));
    glDataNullReturn(polygon, NULL);    

    return(polygon);
}

GLDataPolygon *glDataPolygonInit (GLDataPolygon *polygon,
                                   GLDataUInt npoints)
{
    glDataNullReturn(polygon, NULL);

    _glDataInit(glDataGetBase(polygon));
    polygon->points = (GLDataPoint *) malloc(npoints * sizeof(GLDataPoint));
    memset(polygon->points, 0, npoints * sizeof(GLDataPoint));
    polygon->npoints = npoints;

    return(polygon);
}

GLDataPolygon *glDataPolygonRetain (GLDataPolygon *polygon) {
    glDataNullReturn(polygon, NULL);

    _glDataRetain(glDataGetBase(polygon));
    return(polygon);
}

void glDataPolygonRelease (GLDataPolygon *polygon) {
    glDataNullSkip(polygon);

    if (_glDataRelease(glDataGetBase(polygon))) {
        glDataDebug("[D] glDataPolygon Release\n");

        free(polygon->points);
        free(polygon);
    }
}

GLDataPoint *glDataPolygonGetPoint (GLDataPolygon *polygon,
                                    GLDataUInt index)
{
    glDataNullReturn(polygon, NULL);
    return(&(polygon->points[index]));
}

void glDataPolygonSetPoint (GLDataPolygon *polygon,
                            GLDataUInt index,
                            GLDataPoint *point)
{
    glDataNullSkip(polygon);

    glDataPointInitCopy(&(polygon->points[index]), point);
}

/**
 * ===========================================================================
 * GLDataTriangle: 
 * Represents a 3d Triangle, It's a specialization of Polygon.
 */
GLDataTriangle *glDataTriangleAlloc (void) {
    return((GLDataTriangle *)glDataPolygonAlloc());
}

GLDataTriangle *glDataTriangleInit (GLDataTriangle *triangle,
                                    GLDataPoint *a,
                                    GLDataPoint *b,
                                    GLDataPoint *c)
{
    if (glDataPolygonInit((GLDataPolygon *)triangle, 3)) {
        glDataPolygonSetPoint((GLDataPolygon *)triangle, 0, a);
        glDataPolygonSetPoint((GLDataPolygon *)triangle, 1, b);
        glDataPolygonSetPoint((GLDataPolygon *)triangle, 2, c);
    }

    return(triangle);
}

GLDataTriangle *glDataTriangleRetain (GLDataTriangle *triangle) {
    return(glDataPolygonRetain((GLDataPolygon *)triangle));
}

void glDataTriangleRelease (GLDataTriangle *triangle) {
    glDataPolygonRelease((GLDataPolygon *)triangle);
}

/**
 * ===========================================================================
 * GLDataQuad: 
 * Represents a 3d Quad, It's a specialization of Polygon.
 */
GLDataQuad *glDataQuadAlloc (void) {
    return((GLDataQuad *)glDataPolygonAlloc());
}

GLDataQuad *glDataQuadInit (GLDataQuad *quad,
                            GLDataPoint *a,
                            GLDataPoint *b,
                            GLDataPoint *c,
                            GLDataPoint *d)
{
    if (glDataPolygonInit((GLDataPolygon *)quad, 4)) {
        glDataPolygonSetPoint((GLDataPolygon *)quad, 0, a);
        glDataPolygonSetPoint((GLDataPolygon *)quad, 1, b);
        glDataPolygonSetPoint((GLDataPolygon *)quad, 2, c);
        glDataPolygonSetPoint((GLDataPolygon *)quad, 3, d);
    }

    return(quad);
}

GLDataQuad *glDataQuadRetain (GLDataQuad *quad) {
    return(glDataPolygonRetain((GLDataPolygon *)quad));
}

void glDataQuadRelease (GLDataQuad *quad) {
    glDataPolygonRelease((GLDataPolygon *)quad);
}

/**
 * ===========================================================================
 * GLDataSurface: 
 * Represents a 3d Surface, It's a collection of Polygons.
 */
GLDataUVSurface *glDataUVSurfaceAlloc (void) {
    GLDataUVSurface *surface;

    /* Alloc GLData Surface */
    surface = (GLDataUVSurface *) malloc(sizeof(GLDataUVSurface));
    glDataNullReturn(surface, NULL);    

    return(surface);
}

GLDataUVSurface *glDataUVSurfaceInit (GLDataUVSurface *surface,
                                      GLDataUInt npolygons)
{
    size_t array_size;

    glDataNullReturn(surface, NULL);

    _glDataInit(glDataGetBase(surface));

    array_size = npolygons * sizeof(GLDataUVPolygon *);
    surface->polygons = (GLDataUVPolygon **) malloc(array_size);
    memset(surface->polygons, 0, array_size);

    surface->npolygons = npolygons;

    return(surface);
}

GLDataUVSurface *glDataUVSurfaceRetain (GLDataUVSurface *surface) {
    glDataNullReturn(surface, NULL);

    _glDataRetain(glDataGetBase(surface));
    return(surface);
}

void glDataUVSurfaceRelease (GLDataUVSurface *surface) {
    glDataNullSkip(surface);

    if (_glDataRelease(glDataGetBase(surface))) {
        GLDataUInt i;

        glDataDebug("[D] glDataUVSurface Release\n");

        for (i = 0; i < surface->npolygons; ++i)
            glDataUVPolygonRelease(surface->polygons[i]);

        free(surface->polygons);
        free(surface);
    }
}

GLDataUVPolygon *glDataUVSurfaceGetPolygon (GLDataUVSurface *surface,
                                            GLDataUInt index)
{
    glDataNullReturn(surface, NULL);
    return(surface->polygons[index]);
}

void glDataUVSurfaceSetPolygon (GLDataUVSurface *surface,
                                GLDataUInt index,
                                GLDataUVPolygon *polygon)
{
    glDataNullSkip(surface);

    surface->polygons[index] = glDataUVPolygonRetain(polygon);
}

void glDataUVSurfaceSetPolygons (GLDataUVSurface *surface,
                                 GLDataUInt npolygons,
                                 GLDataUVPolygon **polygons)
{
    GLDataUInt i;

    glDataNullSkip(surface);

    for (i = 0; i < npolygons; ++i)
        surface->polygons[i] = glDataUVPolygonRetain(polygons[i]);
}

/**
 * ===========================================================================
 * GLDataSurface: 
 * Represents a 3d Surface, It's a collection of Polygons.
 */
GLDataSurface *glDataSurfaceAlloc (void) {
    GLDataSurface *surface;

    /* Alloc GLData Surface */
    surface = (GLDataSurface *) malloc(sizeof(GLDataSurface));
    glDataNullReturn(surface, NULL);    

    return(surface);
}

GLDataSurface *glDataSurfaceInit (GLDataSurface *surface,
                                  GLDataUInt npolygons)
{
    size_t array_size;

    glDataNullReturn(surface, NULL);

    _glDataInit(glDataGetBase(surface));

    array_size = npolygons * sizeof(GLDataPolygon *);
    surface->polygons = (GLDataPolygon **) malloc(array_size);
    memset(surface->polygons, 0, array_size);

    surface->npolygons = npolygons;

    return(surface);
}

GLDataSurface *glDataSurfaceRetain (GLDataSurface *surface) {
    glDataNullReturn(surface, NULL);

    _glDataRetain(glDataGetBase(surface));
    return(surface);
}

void glDataSurfaceRelease (GLDataSurface *surface) {
    glDataNullSkip(surface);

    if (_glDataRelease(glDataGetBase(surface))) {
        GLDataUInt i;

        glDataDebug("[D] glDataSurface Release\n");

        for (i = 0; i < surface->npolygons; ++i)
            glDataPolygonRelease(surface->polygons[i]);

        free(surface->polygons);
        free(surface);
    }
}

GLDataPolygon *glDataSurfaceGetPolygon (GLDataSurface *surface,
                                        GLDataUInt index)
{
    glDataNullReturn(surface, NULL);
    return(surface->polygons[index]);
}

void glDataSurfaceSetPolygon (GLDataSurface *surface,
                              GLDataUInt index,
                              GLDataPolygon *polygon)
{
    glDataNullSkip(surface);

    surface->polygons[index] = glDataPolygonRetain(polygon);
}

void glDataSurfaceSetPolygons (GLDataSurface *surface,
                               GLDataUInt npolygons,
                               GLDataPolygon **polygons)
{
    GLDataUInt i;

    glDataNullSkip(surface);

    for (i = 0; i < npolygons; ++i)
        surface->polygons[i] = glDataPolygonRetain(polygons[i]);
}

/**
 * GLDataImage:
 * Represents an Image 
 */
GLDataImage *glDataImageAlloc (void) {
    GLDataImage *image;

    /* Alloc GLData Image */
    image = (GLDataImage *) malloc(sizeof(GLDataImage));
    glDataNullReturn(image, NULL);    

    return(image);
}

GLDataImage *glDataImageInit (GLDataImage *image,
                              const char *name)
{
    glDataNullReturn(image, NULL);

    _glDataInit(glDataGetBase(image));
    image->name = strdup(name);
    image->data = NULL;
    image->height = 0;
    image->width = 0;

    return(image);
}

GLDataImage *glDataImageRetain (GLDataImage *image) {
    glDataNullReturn(image, NULL);

    _glDataRetain(glDataGetBase(image));
    return(image);
}

void glDataImageRelease (GLDataImage *image) {
    glDataNullSkip(image);

    if (_glDataRelease(glDataGetBase(image))) {
        if (image->data != NULL)
            free(image->data);

        free(image->name);
        free(image);
    }
}

void glDataImageSetSize (GLDataImage *image,
                         GLDataUInt width,
                         GLDataUInt height)
{
    glDataNullSkip(image);
    image->height = height;
    image->width = width;
}

void glDataImageSetData (GLDataImage *image, void *data) {
    glDataNullSkip(image);
    image->data = data;
}

void glDataImageSetId (GLDataImage *image, GLDataUInt id) {
    glDataNullSkip(image);
    image->id = id;
}

/**
 * ===========================================================================
 * GLDataMesh: 
 * Represents a 3d Mesh, With a 3d Surface and an UV Texture Map.
 */
GLDataMesh *glDataMeshAlloc (void) {
    GLDataMesh *mesh;

    /* Alloc GLData Mesh */
    mesh = (GLDataMesh *) malloc(sizeof(GLDataMesh));
    glDataNullReturn(mesh, NULL);    

    return(mesh);
}

GLDataMesh *glDataMeshInit (GLDataMesh *mesh)
{
    glDataNullReturn(mesh, NULL);

    _glDataInit(glDataGetBase(mesh));
    mesh->textureImage = NULL;
    mesh->textureMap = NULL;
    mesh->surface = NULL;
    mesh->name = NULL;

    return(mesh);
}

GLDataMesh *glDataMeshRetain (GLDataMesh *mesh) {
    glDataNullReturn(mesh, NULL);

    _glDataRetain(glDataGetBase(mesh));
    return(mesh);
}

void glDataMeshRelease (GLDataMesh *mesh) {
    glDataNullSkip(mesh);

    if (_glDataRelease(glDataGetBase(mesh))) {
        glDataDebug("[D] glDataMesh Release\n");

        if (mesh->name != NULL)
            free(mesh->name);

        glDataUVSurfaceRelease(mesh->textureMap);
        glDataImageRelease(mesh->textureImage);
        glDataSurfaceRelease(mesh->surface);
        free(mesh);
    }
}

void glDataMeshSetName (GLDataMesh *mesh, const char *name) {
    glDataNullSkip(mesh);

    if (mesh->name != NULL)
        free(mesh->name);
    mesh->name = strdup(name);
}

void glDataMeshSetSurface (GLDataMesh *mesh,
                           GLDataSurface *surface)
{
    glDataNullSkip(mesh);
    mesh->surface = glDataSurfaceRetain(surface);
}

void glDataMeshSetTextureMap (GLDataMesh *mesh,
                              GLDataUVSurface *textureMap)
{
    glDataNullSkip(mesh);
    mesh->textureMap = glDataUVSurfaceRetain(textureMap);
}
void glDataMeshSetTextureImage (GLDataMesh *mesh,
                                GLDataImage *image)
{
    glDataNullSkip(mesh);

    mesh->textureImage = glDataImageRetain(image);
}

