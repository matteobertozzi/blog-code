//
//  Gravatar.m
//  iPhoneGravatar
//
//  Created by Matteo Bertozzi on 3/28/09.
//  Copyright 2009 Matteo Bertozzi. All rights reserved.
//

#import <CommonCrypto/CommonDigest.h>
#import "Gravatar.h"


NSString *md5 (NSString *str) {
	const char *cStr = [str UTF8String];
	unsigned char result[CC_MD5_DIGEST_LENGTH];
	CC_MD5( cStr, strlen(cStr), result );
	return [NSString stringWithFormat:@"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x", 
			result[0], result[1], result[2], result[3], result[4], result[5], result[6], result[7],
			result[8], result[9], result[10], result[11], result[12], result[13], result[14], result[15]];
} 

@implementation Gravatar

- (id)initWithHandler:(SEL)requestHandler target:(id)target {
	if ((self = [super init])) {
		_requestHandler = requestHandler;
		_target = target;
	}
	return self;
}

- (void)dealloc {
	[responseData release];
	[super dealloc];
}

- (void)request:(NSString *)email {
	NSMutableString *url = [[NSMutableString alloc] init];
	[url appendString:@"http://www.gravatar.com/avatar/"];
	[url appendFormat:@"%@?s=80", md5(email)];
	
	responseData = [[NSMutableData alloc] init];

	NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
	[[NSURLConnection alloc] initWithRequest:request delegate:self];

	[url release];
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
	[responseData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	[responseData appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
	[_target performSelectorOnMainThread:_requestHandler withObject:error waitUntilDone:YES];
	[connection release];
	[responseData release];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
	[_target performSelectorOnMainThread:_requestHandler withObject:responseData waitUntilDone:YES];
	[responseData release];
}

@end
