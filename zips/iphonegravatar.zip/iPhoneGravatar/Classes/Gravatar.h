//
//  Gravatar.h
//  iPhoneGravatar
//
//  Created by Matteo Bertozzi on 3/28/09.
//  Copyright 2009 Matteo Bertozzi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Gravatar : NSObject {
	NSMutableData *responseData;
	
	SEL _requestHandler;
	id _target;
}

- (id)initWithHandler:(SEL)requestHandler target:(id)target;

- (void)request:(NSString *)email;

@end
