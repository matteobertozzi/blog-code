//
//  iPhoneGravatarAppDelegate.h
//  iPhoneGravatar
//
//  Created by Matteo Bertozzi on 3/28/09.
//  Copyright Matteo Bertozzi 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class iPhoneGravatarViewController;

@interface iPhoneGravatarAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    iPhoneGravatarViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet iPhoneGravatarViewController *viewController;

@end

