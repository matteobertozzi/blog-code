//
//  iPhoneGravatarViewController.h
//  iPhoneGravatar
//
//  Created by Matteo Bertozzi on 3/28/09.
//  Copyright Matteo Bertozzi 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Gravatar.h"

@interface iPhoneGravatarViewController : UIViewController {
	IBOutlet UIImageView *avatar;
	IBOutlet UILabel *email;
	Gravatar *gravatar;
}

@end

