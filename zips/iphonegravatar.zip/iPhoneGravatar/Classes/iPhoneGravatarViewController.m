//
//  iPhoneGravatarViewController.m
//  iPhoneGravatar
//
//  Created by Matteo Bertozzi on 3/28/09.
//  Copyright Matteo Bertozzi 2009. All rights reserved.
//

#import "iPhoneGravatarViewController.h"

@implementation iPhoneGravatarViewController



// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	gravatar = [[Gravatar alloc] initWithHandler:@selector(requestHandler:) target:self];
}


// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return (YES);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}


- (void)dealloc {
	[gravatar dealloc];
    [super dealloc];
}

- (void)requestHandler:(id)sender {
	if ([sender isKindOfClass:[NSError class]]) {
		UIAlertView *errorView = [[UIAlertView alloc] initWithTitle: @"Network error" message: @"Error sending your info to the server" delegate: self cancelButtonTitle: @"Ok" otherButtonTitles: nil];
		[errorView show];
		[errorView release];
	} else {
		[avatar setImage:[UIImage imageWithData:sender]];
	}
}


- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
	[searchBar resignFirstResponder];
	
	[gravatar request:[searchBar text]];
	[email setText:[searchBar text]];
}

@end
