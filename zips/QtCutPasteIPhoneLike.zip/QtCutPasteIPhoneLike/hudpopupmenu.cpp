#include <QMouseEvent>
#include <QPainter>
#include <QAction>
#include <QVector>
#include <QList>

#include "hudpopupmenu.h"

#define MENU_ROUND        10
#define ARROW_HEIGHT      18
#define TEXT_HPADDING     26
#define TEXT_VPADDING     18

class THHudPopupMenuPrivate {
    public:
        QVector<QPair<int, int> > xCache;
        QList<QAction *> actions;
        QSize size;

    public:
        int isHoverItem (int x, int y) const;
        QSize calculateSizeHint (const QFontMetrics& fm);
};

int THHudPopupMenuPrivate::isHoverItem (int x, int y) const {
    if (y >= 0 && y <= (size.height() -  ARROW_HEIGHT)) {
        for (int i = 0; i < xCache.size(); ++i) {
            const QPair<int, int>& pair = xCache[i];
    
            if (x >= pair.first && x <= (pair.first + pair.second))
                return(i);
        }
    }

    return(-1);
}

QSize THHudPopupMenuPrivate::calculateSizeHint (const QFontMetrics& fm) {
    int i = 0;
    int fullWidth = 0;
    xCache.resize(actions.size());
    foreach (QAction *action, actions) {
        int width = fm.width(action->text()) + TEXT_HPADDING;
        xCache[i++] = qMakePair(fullWidth, width);
        fullWidth += width;
    }
    int height = fm.xHeight() + TEXT_VPADDING;
    return(QSize(fullWidth, height + ARROW_HEIGHT));
}

THHudPopupMenu::THHudPopupMenu (QWidget *parent)
    : QWidget(parent), d(new THHudPopupMenuPrivate)
{
    setMouseTracking(true);
    setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
}

THHudPopupMenu::~THHudPopupMenu() {
    delete d;
}

void THHudPopupMenu::addAction (QAction *action) {
    d->actions.append(action);
    d->size = d->calculateSizeHint(fontMetrics());
    resize(d->size);
    update();
}

QAction *THHudPopupMenu::addAction (const QString& text) {
    QAction *action = new QAction(text, this);    
    addAction(action);
    return(action);
}

QSize THHudPopupMenu::sizeHint (void) const {
    if (d->size.isEmpty())
        d->size = d->calculateSizeHint(fontMetrics());
    return(d->size);
}

void THHudPopupMenu::mouseReleaseEvent (QMouseEvent *event) {
    int index = d->isHoverItem(event->x(), event->y());
    if (index >= 0) {
        QAction *action = d->actions.at(index);
        action->trigger();
        emit triggered(action);
    }
}

void THHudPopupMenu::mouseMoveEvent (QMouseEvent *event) {
    bool isArrowCursor = (cursor().shape() == Qt::ArrowCursor);
    int index = d->isHoverItem(event->x(), event->y());
    if (index >= 0) {
        if (isArrowCursor) {        
            setCursor(Qt::PointingHandCursor);
            d->actions.at(index)->hover();
        }
    } else if (!isArrowCursor) {
        unsetCursor();
    }
}

void THHudPopupMenu::paintEvent (QPaintEvent *event) {
    QWidget::paintEvent(event);

    const QPair<int, int>& midPair = d->xCache[d->xCache.size() / 2];
    int midWidth = midPair.first + (midPair.second / 2) - 5;
    int height = d->size.height() - ARROW_HEIGHT;

    QPainterPath path;
    path.addRoundedRect(0, 0, d->size.width(), height, MENU_ROUND, MENU_ROUND);
    path.moveTo(midWidth, height);
    path.lineTo(midWidth + (ARROW_HEIGHT / 2), height + (ARROW_HEIGHT / 2));
    path.lineTo(midWidth + ARROW_HEIGHT, height);

    QLinearGradient brush(0, 0, 0, height);
    brush.setColorAt(0.5f, QColor(0x50, 0x51, 0x55));
    brush.setColorAt(0.0f, QColor(0x7d, 0x7e, 0x73));
    brush.setColorAt(1.0f, QColor(0x00, 0x00, 0x00));

    QPainter p(this);
    p.setRenderHint(QPainter::TextAntialiasing);
    p.setRenderHint(QPainter::Antialiasing);

    // Draw Path
    p.setPen(QPen(Qt::transparent, 0, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
    p.setBrush(brush);
    p.drawPath(path);

    int i = 0;
    foreach (QAction *action, d->actions) {
        const QPair<int, int>& pair = d->xCache[i++];
        int width = pair.second;
        int x = pair.first;

        p.setPen(Qt::white);
        p.drawText(x, 0, width, height, Qt::AlignCenter, action->text());

        if (x > 0) {
            p.setPen(QPen(QColor(0xd0, 0xd0, 0xd0), 0.1f));
            p.drawLine(x, 0, x, height);
        }
    }

    p.end();
}

