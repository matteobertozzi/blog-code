#ifndef _HUDPOPUPMENU_H_
#define _HUDPOPUPMENU_H_

#include <QWidget>
class QAction;
class THHudPopupMenuPrivate;

class THHudPopupMenu : public QWidget {
    Q_OBJECT

    public:
        THHudPopupMenu (QWidget *parent = 0);
        ~THHudPopupMenu();

        void addAction (QAction *action);
        QAction *addAction (const QString& text);

        QSize sizeHint (void) const;

    Q_SIGNALS:
        void triggered (QAction *action);

    protected:
        void mouseReleaseEvent (QMouseEvent *event);
        void mouseMoveEvent (QMouseEvent *event);
        void paintEvent (QPaintEvent *event);

    private:
        THHudPopupMenuPrivate *d;
};

#endif /* !_HUDPOPUPMENU_H_ */

