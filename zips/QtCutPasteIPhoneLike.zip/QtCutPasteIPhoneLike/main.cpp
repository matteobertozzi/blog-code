#include <QApplication>
#include <QMessageBox>
#include <QAction>

#include "hudpopupmenu.h"

int main (int argc, char **argv) {
    QApplication app(argc, argv);

    QWidget w;
    w.resize(325, 100);
    w.setWindowTitle("iPhone Cut/Copy/Paste Like Widget");

    // Setup Info Messages
    QMessageBox cutMsgBox(&w);
    cutMsgBox.setText("Cut Clicked");
    
    QMessageBox copyMsgBox(&w);
    copyMsgBox.setText("Copy Clicked");

    QMessageBox pasteMsgBox(&w);
    pasteMsgBox.setText("Paste Clicked");

    // Setup Popup and Actions
    THHudPopupMenu *popup = new THHudPopupMenu(&w);
    QAction *cutAction = popup->addAction("Cut");
    QObject::connect(cutAction, SIGNAL(triggered()), 
                     &cutMsgBox, SLOT(exec()));

    QAction *copyAction = popup->addAction("Copy");
    QObject::connect(copyAction, SIGNAL(triggered()),
                     &copyMsgBox, SLOT(exec()));

    QAction *pasteAction = popup->addAction("Paste");
    QObject::connect(pasteAction, SIGNAL(triggered()), 
                     &pasteMsgBox, SLOT(exec()));

    // Place the Popup Menu at the Right Position
    popup->move(90, 25);

    w.show();

    return(app.exec());
}

