//
//  AppController.m
//  TestWebKit
//
//  Created by Matteo Bertozzi on 11/30/08.
//  Copyright 2008 Matteo Bertozzi. All rights reserved.
//

#import "AppController.h"

#define LONG_TEXT		@"I'm a long long text of <b>%@</b>... WebKit is an open source web browser engine. WebKit is also the name of the Mac OS X system framework version of the engine that's used by Safari, Dashboard, Mail, and many other OS X applications. WebKit's HTML and JavaScript code began as a branch of the KHTML and KJS libraries from KDE. This website is also the home of S60's S60 WebKit development."

@implementation AppController

- (void)awakeFromNib {
	NSFileManager *fileManager = [NSFileManager defaultManager];
	NSString *path = [[NSBundle mainBundle] pathForResource:@"xmlRequest" ofType:@"html"];
	NSData *data = [fileManager contentsAtPath:path];
	NSString *htmlString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
	[[webView mainFrame] loadHTMLString:htmlString baseURL:nil];
}

- (void)webView:(WebView *)sender decidePolicyForNavigationAction:(NSDictionary *)actionInformation
        request:(NSURLRequest *)request frame:(WebFrame *)frame decisionListener:(id)listener
{
    NSString *host = [[request URL] path];
	NSLog(@"Receive Response: %@ Path %@", [request URL], host);
    if ([host isEqualToString:@"/openItem1"]) {
        [listener ignore];
		
		NSArray *args = [NSArray arrayWithObjects:@"Item1Title", @"Hi, I'm Test 1", nil];
		[[sender windowScriptObject] callWebScriptMethod:@"fillElement" withArguments:args];
		
		args = [NSArray arrayWithObjects:@"Item1Content", [NSString stringWithFormat:LONG_TEXT, @"Item1"], nil];
		[[sender windowScriptObject] callWebScriptMethod:@"fillElement" withArguments:args];
	} else if ([host isEqualToString:@"/openItem2"]) {
        [listener ignore];

		NSArray *args = [NSArray arrayWithObjects:@"Item2Title", @"Hi, I'm Test 2", nil];
		[[sender windowScriptObject] callWebScriptMethod:@"fillElement" withArguments:args];
		
		args = [NSArray arrayWithObjects:@"Item2Content", [NSString stringWithFormat:LONG_TEXT, @"Item2"], nil];
		[[sender windowScriptObject] callWebScriptMethod:@"fillElement" withArguments:args];
    } else if ([host isEqualToString:@"/openItem3"]) {
        [listener ignore];

		NSArray *args = [NSArray arrayWithObjects:@"Item3Title", @"<a href='closeItem3'>Close Test 3</a>", nil];
		[[sender windowScriptObject] callWebScriptMethod:@"fillElement" withArguments:args];
		
		args = [NSArray arrayWithObjects:@"Item3Content", [NSString stringWithFormat:LONG_TEXT, @"Item3"], nil];
		[[sender windowScriptObject] callWebScriptMethod:@"fillElement" withArguments:args];
	} else if ([host isEqualToString:@"/closeItem3"]) {
		NSArray *args = [NSArray arrayWithObjects:@"Item3Title", @"<a href='openItem3'>Open Test 3</a>", nil];
		[[sender windowScriptObject] callWebScriptMethod:@"fillElement" withArguments:args];
		
		args = [NSArray arrayWithObjects:@"Item3Content", @"", nil];
		[[sender windowScriptObject] callWebScriptMethod:@"fillElement" withArguments:args];
    } else
        [listener use];
}

@end
