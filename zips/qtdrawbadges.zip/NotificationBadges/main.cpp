#include <QRadialGradient>
#include <QApplication>
#include <QPaintEvent>
#include <QPainter>
#include <QWidget>

class DrawBadgesExample : public QWidget {
	public:
		DrawBadgesExample (QWidget *parent = 0);

	protected:
		void paintEvent (QPaintEvent *event);

	private:
		void fillEllipse (	QPainter& p, 
							int x, int y, 
							int size,
							const QBrush& brush);

		void drawBadge (QPainter& p, 
						int x, int y, 
						int size,
						const QString& text,
						const QBrush& brush);
};

DrawBadgesExample::DrawBadgesExample (QWidget *parent)
	: QWidget(parent)
{
}

void DrawBadgesExample::paintEvent (QPaintEvent *event) {
	QPainter p(this);			
	p.setRenderHint(QPainter::TextAntialiasing);
	p.setRenderHint(QPainter::Antialiasing);

	//p.fillRect(event->rect(), Qt::black);

	qreal size = 30;		// Badge Size

	QRadialGradient redGradient(0.0, 0.0, 17.0, size - 3, size - 3);
	redGradient.setColorAt(0.0, QColor(0xe0, 0x84, 0x9b));
	redGradient.setColorAt(0.5, QColor(0xe9, 0x34, 0x43));
	redGradient.setColorAt(1.0, QColor(0xdc, 0x0c, 0x00));

	QRadialGradient blueGradient(0.0, 0.0, 17.0, size - 3, size - 3);	
	blueGradient.setColorAt(0.0, QColor(0x6f, 0x9d, 0xe8));
	blueGradient.setColorAt(0.5, QColor(0x4a, 0x72, 0xbf));
	blueGradient.setColorAt(1.0, QColor(0x27, 0x47, 0x94));

	p.save();
	p.translate(10, 10);
	p.drawImage(5, 5, QImage("Icons/1.png"));
	drawBadge(p, 0, 0, 30, "7", QBrush(redGradient));
	p.restore();

	p.save();
	p.translate(90, 10);
	p.drawImage(5, 5, QImage("Icons/2.png"));
	drawBadge(p, 0, 0, 30, "25", QBrush(redGradient));
	p.restore();

	p.save();
	p.translate(10, 90);
	p.drawImage(5, 5, QImage("Icons/3.png"));
	drawBadge(p, 0, 0, 30, "512", QBrush(blueGradient));
	p.restore();

	p.save();
	p.translate(90, 90);
	p.drawImage(5, 5, QImage("Icons/4.png"));
	drawBadge(p, 0, 0, 30, "713", QBrush(blueGradient));
	p.restore();

	p.end();	
}

void DrawBadgesExample::fillEllipse (	QPainter& p, 
										int x, int y, 
										int size,
										const QBrush& brush)
{
	QPainterPath path;
	path.addEllipse(x, y, size, size);
	p.fillPath(path, brush);
}

void DrawBadgesExample::drawBadge (	QPainter& p, 
									int x, int y, 
									int size,
									const QString& text,
									const QBrush& brush)
{
	p.setFont(QFont(font().family(), 11, QFont::Bold));	
	while ((size - p.fontMetrics().width(text)) < 6) {
		int pointSize = p.font().pointSize() - 1;
		int weight = (pointSize < 6) ? QFont::Normal : QFont::Bold;
		p.setFont(QFont(p.font().family(), p.font().pointSize() - 1, weight));
	}		

	QColor shadowColor(0x00, 0x00, 0x00, size);
	fillEllipse(p, x + 1, y, size, shadowColor);
	fillEllipse(p, x - 1, y, size, shadowColor);
	fillEllipse(p, x, y + 1, size, shadowColor);
	fillEllipse(p, x, y - 1, size, shadowColor);

	p.setPen(QPen(Qt::white, 2));
	fillEllipse(p, x, y, size - 3, brush);
	p.drawEllipse(x, y, size - 3, size - 3);
			
	p.setPen(QPen(Qt::white, 1));			
	p.drawText(x, y, size - 3, size - 3, Qt::AlignCenter, text);
}

int main (int argc, char **argv) {
	QApplication app(argc, argv);

	DrawBadgesExample w;
	w.show();

	return(app.exec());
}

