#include "thflickrthumbitem.h"

/* ============================================================================
 *  PRIVATE Class
 */
class THFlickrThumbItemPrivate {
	public:
		QImage originalImage;
		int oldZValue;
};

/* ============================================================================
 *  PUBLIC Constructors/Destructors
 */
THFlickrThumbItem::THFlickrThumbItem (QGraphicsItem *parent)
	: QObject(), QGraphicsPixmapItem(parent), d(new THFlickrThumbItemPrivate)
{
	setAcceptHoverEvents(true);
}

THFlickrThumbItem::~THFlickrThumbItem() {
	delete d;
}

/* ============================================================================
 *  PUBLIC Properties
 */
QImage THFlickrThumbItem::originalImage (void) const {
	return(d->originalImage);
}

void THFlickrThumbItem::setOriginalImage (const QImage& original) {
	d->originalImage = original;
}

/* ============================================================================
 *  PROTECTED Methods
 */
void THFlickrThumbItem::hoverEnterEvent (QGraphicsSceneHoverEvent *event) {
	Q_UNUSED(event)

	d->oldZValue = zValue();
	setZValue(d->oldZValue * 1000);

	emit activated(this);
}

void THFlickrThumbItem::hoverLeaveEvent (QGraphicsSceneHoverEvent *event) {
	Q_UNUSED(event)

	setZValue(d->oldZValue);
}

