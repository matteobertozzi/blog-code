#ifndef _THFLICKRTHUMBITEM_H_
#define _THFLICKRTHUMBITEM_H_

#include <QGraphicsPixmapItem>
#include <QObject>

class THFlickrThumbItemPrivate;

class THFlickrThumbItem : public QObject, public QGraphicsPixmapItem {
	Q_OBJECT

	public:
		THFlickrThumbItem (QGraphicsItem *parent = 0);
		~THFlickrThumbItem();

		QImage originalImage (void) const;
		void setOriginalImage (const QImage& original);

	signals:
		void activated (THFlickrThumbItem *item);

	protected:
		void hoverEnterEvent (QGraphicsSceneHoverEvent *event);
		void hoverLeaveEvent (QGraphicsSceneHoverEvent *event);

	private:
		THFlickrThumbItemPrivate *d;
};

#endif /* !_THFLICKRTHUMBITEM_H_ */

