#include <cmath>

#include <QGraphicsPixmapItem>
#include <QtConcurrentMap>
#include <QFutureWatcher>
#include <QGraphicsView>
#include <QMessageBox>
#include <QCloseEvent>
#include <QTimer>

#include "ui_thflickrwindow.h"

#include "thflickrthumbitem.h"
#include "thflickrservice.h"
#include "thflickrwindow.h"

#define PREVIEW_SIZE	352.0
#define THUMB_SIZE		141.0

/* ========================================================== Flickr Key ======
 *  FLICKR KEY: You Must Set Your Flickr Key, 
 *              Uncomment and Replace The Key Below.
 */
//#define FLICKR_KEY		"10fd5198a5d5ec25262fa31e47b59408"
#ifndef FLICKR_KEY
	#error "You Must Set Your Flickr Key"
#endif

/* ============================================================================
 *  PRIVATE Class
 */
class THFlickrWindowPrivate {
	public:
		QVector<THFlickrThumbItem *> photos;
		QGraphicsPixmapItem *previewItem;
		QFutureWatcher<QImage> *watcher;
		THFlickrService flickrService;
		Ui::THFlickrWindow ui;
};

/* ============================================================================
 *  STATIC Methods
 */
static QImage downloadImage (const QString& url) {
	QNetworkAccessManager manager;
	QEventLoop loop;
	QTimer timer;
    
	timer.setSingleShot(true);
	timer.connect(&timer, SIGNAL(timeout()), &loop, SLOT(quit()));
	manager.connect(&manager, SIGNAL(finished(QNetworkReply*)),
					&loop, SLOT(quit()));
	QNetworkReply *reply = manager.get(QNetworkRequest(QUrl(url)));
    
	timer.start(8000);
	loop.exec();
    
	QImage image;
	if(timer.isActive()){
		timer.stop();
		image.loadFromData(reply->readAll());
		image = image.convertToFormat(QImage::Format_ARGB32_Premultiplied);
	}

	return(image);
}

static QImage mirrorImage(const QImage &img) {
	QImage tmpImage = QImage(img.width(), img.height() * 2, 
							 QImage::Format_ARGB32_Premultiplied);
	QImage mirrorImage = img.mirrored(true, true);

	QLinearGradient gradient(0, img.height(), 0, tmpImage.height());
	gradient.setColorAt(0, QColor(0xff, 0xff, 0xff, 90));
	gradient.setColorAt(0.25, QColor(0, 0, 0, 20));
	gradient.setColorAt(1, Qt::transparent);

	QPainter p(&tmpImage);
	p.drawImage(0, 0, img);
	p.drawImage(0, img.height(), mirrorImage);
	p.setCompositionMode(QPainter::CompositionMode_DestinationIn);
	p.fillRect(0, img.height(), tmpImage.width(), img.height(), gradient);
	p.end();

    return tmpImage;
}

/* ============================================================================
 *  PUBLIC Constructors/Destructors
 */
THFlickrWindow::THFlickrWindow (QWidget *parent)
	: QMainWindow(parent), d(new THFlickrWindowPrivate)
{
	d->ui.setupUi(this);

	// Setup GraphicsView
	QGraphicsScene *scene = new QGraphicsScene;
	scene->setSceneRect(QRect(0, 0, 800, 500));
	d->ui.graphicsView->setScene(scene);
	d->ui.graphicsView->setBackgroundBrush(Qt::lightGray);
	d->ui.graphicsView->setRenderHint(QPainter::Antialiasing);
	d->ui.graphicsView->setRenderHint(QPainter::SmoothPixmapTransform);
	d->ui.graphicsView->setMouseTracking(true);

	// Setup Preview Item
	d->previewItem = new QGraphicsPixmapItem;
	d->previewItem->setPos(5, 15);
	scene->addItem(d->previewItem);

	// Setup Future Watcher
	d->watcher = new QFutureWatcher<QImage>();
	connect(d->watcher, SIGNAL(resultReadyAt(int)),
			this, SLOT(showPhoto(int)));
	connect(d->watcher, SIGNAL(progressValueChanged(int)),
			d->ui.progressBar, SLOT(setValue(int)));
	connect(d->watcher, SIGNAL(progressRangeChanged(int, int)),
			d->ui.progressBar, SLOT(setRange(int, int)));

	// Setup Search Actions
	connect(d->ui.searchEdit, SIGNAL(returnPressed()), 
			this, SLOT(flickrSearch()));
	connect(d->ui.searchButton, SIGNAL(clicked()), 
			this, SLOT(flickrSearch()));

	// Setup Menu Actions
	connect(d->ui.actionRecentPhotos, SIGNAL(triggered()), 
			this, SLOT(flickrRecentPhotos()));
	connect(d->ui.actionInterestingPhotos, SIGNAL(triggered()), 
			this, SLOT(flickrInterestingPhotos()));
	connect(d->ui.actionClearAll, SIGNAL(triggered()), 
			this, SLOT(flickrClear()));
	connect(d->ui.actionAboutQt, SIGNAL(triggered()), 
			qApp, SLOT(aboutQt()));

	// Run Initalize Objects
	QTimer::singleShot(0, this, SLOT(initObjects()));
}

THFlickrWindow::~THFlickrWindow() {
	if (d->watcher->isRunning())
		d->watcher->cancel();
	delete d;
}

/* ============================================================================
 *  PROTECTED Methods
 */
void THFlickrWindow::closeEvent (QCloseEvent *event) {
	if (d->watcher->isRunning())
		event->ignore();
	else
		QMainWindow::closeEvent(event);
}

/* ============================================================================
 *  PRIVATE Slots (Flickr Service)
 */
void THFlickrWindow::flickrError (	QNetworkReply::NetworkError code,
									const QString& message)
{
	if (code != QNetworkReply::NoError)
		QMessageBox::critical(this, tr("Network Error"), message);
	else
		QMessageBox::critical(this, tr("Flickr Error"), message);
}

void THFlickrWindow::flickrFinished (const QStringList& photosUrls)
{
	if (photosUrls.size() == 0) {
		QMessageBox::information(this, tr("We couldn't find any results"),
							tr("No Image Found matching selected criteria"));
	} else {
		d->photos.resize(photosUrls.size());
		d->watcher->setFuture(QtConcurrent::mapped(photosUrls, downloadImage));
	}
}

void THFlickrWindow::flickrDownloadProgress (	qint64 bytesReceived,
												qint64 bytesTotal)
{
	d->ui.progressBar->setMaximum(bytesTotal);
	d->ui.progressBar->setValue(bytesReceived);
}

/* ============================================================================
 *  PRIVATE Slots (Actions)
 */
void THFlickrWindow::flickrInterestingPhotos (void) {
	flickrClear();
	d->flickrService.interestingPhotos();
}

void THFlickrWindow::flickrRecentPhotos (void) {
	flickrClear();
	d->flickrService.latestPhotos();
}

void THFlickrWindow::flickrSearch (void) {
	flickrClear();
	d->flickrService.searchPhotos(d->ui.searchEdit->text());
}

void THFlickrWindow::flickrClear (void) {
	if (d->watcher->isRunning())
		d->watcher->cancel();

	d->previewItem->setPixmap(QPixmap());
	d->ui.progressBar->setValue(0);

	QGraphicsScene *scene = d->ui.graphicsView->scene();
	for (int i = 0; i < d->photos.size(); ++i) {
		THFlickrThumbItem *item = d->photos[i];
		if (item != NULL) {
			d->photos[i] = NULL;
			scene->removeItem(item);
			delete item;
		}
	}

	update();
}

/* ============================================================================
 *  PRIVATE Slots
 */
void THFlickrWindow::initObjects (void) {
	connect(&(d->flickrService), SIGNAL(downloadProgress(qint64, qint64)),
			this, SLOT(flickrDownloadProgress(qint64, qint64)));
	connect(&(d->flickrService), 
			SIGNAL(error(QNetworkReply::NetworkError, const QString&)),
			this, 
			SLOT(flickrError(QNetworkReply::NetworkError, const QString&)));
	connect(&(d->flickrService), SIGNAL(finished(const QStringList&)),
			this, SLOT(flickrFinished(const QStringList&)));

	d->flickrService.setKey(FLICKR_KEY);
	d->flickrService.latestPhotos();

	// Initialize Preview Item Transformation
	qreal angle = -30;
	qreal rightScale = 1 - 1 / PREVIEW_SIZE;
	QTransform transform = QTransform().scale(rightScale, rightScale);
	transform.translate(0, - PREVIEW_SIZE / 4);
	transform.rotate(angle, Qt::YAxis);
	transform.translate(0, PREVIEW_SIZE / 4);

	d->previewItem->setTransform(transform);
}

void THFlickrWindow::photoPreview (THFlickrThumbItem *item) {
	doPhotoPreview(item->originalImage());
}

void THFlickrWindow::showPhoto (int photoIndex) {
	QImage image = d->watcher->resultAt(photoIndex);
	QPixmap pixmap = QPixmap::fromImage(image);
	if (pixmap.isNull()) return;

	THFlickrThumbItem *item = new THFlickrThumbItem();
	connect(item, SIGNAL(activated(THFlickrThumbItem *)), 
			this, SLOT(photoPreview(THFlickrThumbItem *)));
	item->setPixmap(pixmap.scaled(THUMB_SIZE, THUMB_SIZE, 
					Qt::IgnoreAspectRatio, Qt::SmoothTransformation));
	item->setOriginalImage(image);

	d->ui.graphicsView->scene()->addItem(item);
	d->photos[photoIndex] = item;

	doPhotoPreview(image);
	doPhotoLayout(photoIndex);
}

/* ============================================================================
 *  PRIVATE Methods
 */
void THFlickrWindow::doPhotoLayout (int photoIndex) {
	QRectF box = QRect(500 + PREVIEW_SIZE, 0, 500, 500);
	QSize size(THUMB_SIZE, THUMB_SIZE);

	qreal halfMaxWidth = 0.5 * size.width();
	qreal halfMaxHeight = 0.5 * size.height();
	qreal radiusInset = ::sqrt(	halfMaxWidth * halfMaxWidth + 
								halfMaxHeight * halfMaxHeight);
	
	QPointF circleCenter(box.width() / 2, box.height() / 2);
	qreal circleRadius = qMin(	box.size().width(), 
								box.size().height()) * 0.5 - radiusInset;

	qreal angle = photoIndex * ((2.0 * 3.14) / d->photos.size());
	qreal x = 500 + circleRadius * ::cos(angle);
	qreal y = circleCenter.y() + circleRadius * ::sin(angle);

	THFlickrThumbItem *graphicsItem = d->photos[photoIndex];
	QRectF frame = graphicsItem->boundingRect();
	QSizeF fsize = frame.size();
	graphicsItem->setPos(x - 0.5 * fsize.width(), y - 0.5 * fsize.height());			
	qreal degAngle = ::fmod((angle * (180.0 / 3.14)) + 270.0, 260.0);		
				
	graphicsItem->translate(frame.center().x(), frame.center().y());
	graphicsItem->rotate(degAngle);
	graphicsItem->translate(- frame.center().x(), - frame.center().y());
		
	graphicsItem->setZValue(graphicsItem->pos().x() + graphicsItem->pos().y());
}

void THFlickrWindow::doPhotoPreview (const QImage& image) {
	QPixmap pixmap = QPixmap::fromImage(mirrorImage(image));
	pixmap = pixmap.scaled(	PREVIEW_SIZE, PREVIEW_SIZE, 
							Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
	d->previewItem->setPixmap(pixmap);
}

