#ifndef _THFLICKRWINDOW_H_
#define _THFLICKRWINDOW_H_

#include <QNetworkReply>
#include <QMainWindow>

class THFlickrWindowPrivate;
class THFlickrThumbItem;

class THFlickrWindow : public QMainWindow {
	Q_OBJECT

	public:
		THFlickrWindow (QWidget *parent = 0);
		~THFlickrWindow();

	protected:
		void closeEvent (QCloseEvent *event);

	private Q_SLOTS:
		void flickrDownloadProgress (qint64 bytesReceived, qint64 bytesTotal);
		void flickrError (QNetworkReply::NetworkError code, const QString& message);
		void flickrFinished (const QStringList& photosUrls);

		void flickrInterestingPhotos (void);
		void flickrRecentPhotos (void);
		void flickrSearch (void);
		void flickrClear (void);

		void initObjects (void);

		void photoPreview (THFlickrThumbItem *item);
		void showPhoto (int photoIndex);

	private:
		void doPhotoPreview (const QImage& image);
		void doPhotoLayout (int photoIndex);

	private:		
		THFlickrWindowPrivate *d;
};

#endif /* !_THFLICKRWINDOW_H_ */

