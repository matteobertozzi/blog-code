#ifndef _THFLICKRSERVICE_H_
#define _THFLICKRSERVICE_H_

#include <QNetworkReply>
#include <QStringList>
#include <QObject>

class THFlickrServicePrivate;

class THFlickrService : public QObject {
	Q_OBJECT

	Q_PROPERTY(QString key READ key WRITE setKey)

	public:
		THFlickrService (QObject *parent = 0);
		THFlickrService (const QString& key, QObject *parent = 0);
		~THFlickrService();

		QString key (void) const;
		void setKey (const QString& key);

	signals:
		void downloadProgress (qint64 bytesReceived, qint64 bytesTotal);
		void error (QNetworkReply::NetworkError code, const QString& message);
		void finished (const QStringList& photosUrls);

	public Q_SLOTS:
		void latestPhotos (void);
		void interestingPhotos (void);
		void searchPhotos (const QString& query);

	protected:
		void request (	const QString& method,
						const QStringList& args = QStringList());

	private Q_SLOTS:
		void replyFinished (QNetworkReply *reply);

	private:
		THFlickrServicePrivate *d;
};

#endif /* !_THFLICKRSERVICE_H_ */

