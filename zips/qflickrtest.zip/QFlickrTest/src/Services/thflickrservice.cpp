#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QDomDocument>

#include "thflickrservice.h"

/* ============================================================================
 *  PRIVATE Class
 */
class THFlickrServicePrivate {
	public:
		QNetworkAccessManager *networkManager;
		QString key;
};

/* ============================================================================
 *  PUBLIC Constructors/Destructors
 */
THFlickrService::THFlickrService (QObject *parent) 
	: QObject(parent), d(new THFlickrServicePrivate)
{
	d->networkManager = new QNetworkAccessManager(this);
	connect(d->networkManager, SIGNAL(finished(QNetworkReply *)),
			this, SLOT(replyFinished(QNetworkReply *)));
}

THFlickrService::THFlickrService (const QString& key, QObject *parent)
	: QObject(parent), d(new THFlickrServicePrivate)
{
	d->key = key;
	d->networkManager = new QNetworkAccessManager(this);
}

THFlickrService::~THFlickrService() {
	delete d;
}

/* ============================================================================
 *  PUBLIC Methods
 */

/* ============================================================================
 *  PUBLIC Properties
 */
QString THFlickrService::key (void) const {
	return(d->key);
}

void THFlickrService::setKey (const QString& key) {
	d->key = key;
}

/* ============================================================================
 *  PUBLIC Slots
 */
void THFlickrService::latestPhotos (void) {
	request("flickr.photos.getRecent");
}

void THFlickrService::interestingPhotos (void) {
	request("flickr.interestingness.getList");
}

void THFlickrService::searchPhotos (const QString& query) {
	request("flickr.photos.search", QStringList() << "text" << query);
}

/* ============================================================================
 *  PROTECTED Methods
 */
void THFlickrService::request (const QString& method, const QStringList& args) {
	Q_ASSERT((args.size() % 2) == 0);
	int nargs = args.size() / 2;

	// Build URL
	QString url = "http://www.flickr.com/services/rest/?api_key=" + d->key;
	url += "&method=" + method;
	for (int i = 0; i < nargs; i += 2)
		url += "&" + args[i] + "=" + args[i + 1];

	QNetworkRequest request;
	request.setUrl(QUrl(url));

	QNetworkReply *reply = d->networkManager->get(request);
	connect(reply, SIGNAL(downloadProgress(qint64, qint64)),
			this, SIGNAL(downloadProgress(qint64, qint64)));	
}

/* ============================================================================
 *  PRIVATE Slots
 */
void THFlickrService::replyFinished (QNetworkReply *reply) {
	if (reply->error() != QNetworkReply::NoError) {
		emit error(reply->error(), reply->errorString());
	} else {
		QDomDocument xmlDocument;
		xmlDocument.setContent(reply->readAll());

		QDomElement xmlElement = xmlDocument.documentElement();
		if (xmlElement.tagName() != "rsp") {
			emit error(QNetworkReply::NoError, tr("Invalid Flickr Response"));
		} else if (xmlElement.attribute("stat") != "ok") {
			QDomNodeList nodeList = xmlElement.elementsByTagName("err");
			xmlElement = nodeList.item(0).toElement();
			emit error(QNetworkReply::NoError, xmlElement.attribute("msg"));
		} else {
			QStringList urls;

			QString baseUrl = "http://farm%1.static.flickr.com/%2/%3_%4_m.jpg";
			QDomNodeList nodeList = xmlElement.elementsByTagName("photo");
			for (uint i = 0; i < nodeList.length(); ++i) {
				xmlElement = nodeList.item(i).toElement();
				QString secret = xmlElement.attribute("secret");
				QString server = xmlElement.attribute("server");
				QString farm = xmlElement.attribute("farm");
				QString id = xmlElement.attribute("id");
				
				urls << baseUrl.arg(farm).arg(server).arg(id).arg(secret);
			}

			emit finished(urls);
		}
	}

	reply->deleteLater();
}

