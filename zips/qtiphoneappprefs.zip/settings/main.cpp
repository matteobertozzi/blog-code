#include <QStandardItemModel>
#include <QApplication>

#include "settingsview.h"
#include "settingsitem.h"

int main (int argc, char **argv) {
	QApplication app(argc, argv);


	QStandardItemModel *model = new QStandardItemModel;
	QStandardItem *rootItem = model->invisibleRootItem();

	QVariant variantString("Kernel 2.6.28");
	QVariant variantMulti("Black");
	QVariant variantFalse(false);
	QVariant variantTrue(true);
	QVariant variant;

	THSettingsItem *generalGroup = new THSettingsItem("General", THSettingsItem::Group);
	rootItem->appendRow(generalGroup);
	generalGroup->appendRow(new THSettingsItem( "Language", 
												THSettingsItem::MultiValue,
												QVariant("English")));
	generalGroup->appendRow(new THSettingsItem( "Kernel", 
												THSettingsItem::Value,
												QVariant("2.6.29")));

	THSettingsItem *networkGroup = new THSettingsItem("Network", THSettingsItem::Group);
	rootItem->appendRow(networkGroup);
	networkGroup->appendRow(new THSettingsItem( "Settings", 
												THSettingsItem::Link,
												QVariant(false)));
	networkGroup->appendRow(new THSettingsItem( "Bluetooth", 
												THSettingsItem::Value,
												QVariant(false)));
	networkGroup->appendRow(new THSettingsItem( "Wireless", 
												THSettingsItem::Value,
												QVariant(true)));

	THSettingsItem *actionsGroup = new THSettingsItem("", THSettingsItem::Group);
	rootItem->appendRow(actionsGroup);
	actionsGroup->appendRow(new THSettingsItem("Suspend", THSettingsItem::Button));
	actionsGroup->appendRow(new THSettingsItem("Reboot", THSettingsItem::Button));
	actionsGroup->appendRow(new THSettingsItem("Halt", THSettingsItem::Button));

	rootItem->appendRow(new THSettingsItem("Be careful to press Halt.\nThe system will be shutdown.", THSettingsItem::Info));

	THSettingsView view;
	view.setModel(model);
	view.resize(400, 400);
	view.expandAll();
	view.show();

	return(app.exec());
}

