#ifndef _THSETTINGSITEMDELEGATE_H_
#define _THSETTINGSITEMDELEGATE_H_

#include <QItemDelegate>

class THSettingsItemDelegate : public QItemDelegate {
	Q_OBJECT

	public:
		THSettingsItemDelegate (QObject *parent = 0);
		~THSettingsItemDelegate();

		void paint (QPainter *painter,
					const QStyleOptionViewItem& option, 
					const QModelIndex& index) const;

		QSize sizeHint (const QStyleOptionViewItem& option,
						const QModelIndex& index) const;

	private:
		void drawValue (QPainter *painter, 
						int x, int y, int w, int h, int itemType,
						QVariant& value) const;

		void drawBoolValue (	QPainter *painter,
								int y, int w, int h,
								bool value) const;
		void drawStringValue (	QPainter *painter,
								int y, int w, int h,
								const QString& value) const;

		void drawLinkValue (	QPainter *painter,
								int y, int w, int h) const;
};

#endif /* !_THSETTINGSITEMDELEGATE_H_ */

