#include "settingsitem.h"

THSettingsItem::THSettingsItem (const QString& text, 
								THSettingsItem::ItemType itemType,
								const QVariant& data)
	: QStandardItem(text)
{
	setEditable(false);
	setData(itemType, Qt::UserRole + 2);
	setData(data, Qt::UserRole + 1);
}

THSettingsItem::THSettingsItem (const QIcon& icon,
								const QString& text,
								THSettingsItem::ItemType itemType,
								const QVariant& data)
	: QStandardItem(icon, text)
{
	setEditable(false);
	setData(itemType, Qt::UserRole + 2);
	setData(data, Qt::UserRole + 1);
}

THSettingsItem::~THSettingsItem() {
}

THSettingsItem::ItemType THSettingsItem::itemType (void) const {
	return((THSettingsItem::ItemType) data(Qt::UserRole + 2).toInt());
}

void THSettingsItem::setItemType (THSettingsItem::ItemType itemType) {
	setData(itemType, Qt::UserRole + 2);
}

