#ifndef _THSETTINGSVIEW_H_
#define _THSETTINGSVIEW_H_

#include <QTreeView>

class THSettingsView : public QTreeView {
	Q_OBJECT

	public:
		THSettingsView (QWidget *parent = 0);
		~THSettingsView();

	Q_SIGNALS:
		void linkClicked (const QString& key, const QVariant& value);
		void valueClicked (const QString& key, const QVariant& value);
		void buttonClicked (const QString& key, const QVariant& value);
		void multiValueClicked (const QString& key, const QVariant& value);

	private Q_SLOTS:
		void booleanDoubleClicked (const QModelIndex& index);
};

#endif /* !_THSETTINGSVIEW_H_ */

