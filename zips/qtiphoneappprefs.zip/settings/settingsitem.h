#ifndef _THSETTINGSITEM_H_
#define _THSETTINGSITEM_H_

#include <QStandardItem>

class THSettingsItem : public QStandardItem {
	public:
		enum ItemType { Button, Link, Group, Value, MultiValue, Info };

	public:
		THSettingsItem (const QString& text,
						ItemType itemType,
						const QVariant& data = QVariant());
		THSettingsItem (const QIcon& icon,
						const QString& text,
						ItemType itemType,
						const QVariant& data = QVariant());
		~THSettingsItem();

		ItemType itemType (void) const;
		void setItemType (ItemType itemType);
};

#endif /* !_THSETTINGSITEM_H_ */

