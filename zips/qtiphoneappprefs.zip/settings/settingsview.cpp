#include "settingsitemdelegate.h"
#include "settingsitem.h"
#include "settingsview.h"

THSettingsView::THSettingsView (QWidget *parent)
	: QTreeView(parent)
{
	// Setup Background Color
	QPalette qPalette = palette();
	qPalette.setColor(QPalette::Base, QColor(0xd1, 0xd6, 0xdc));
	setPalette(qPalette);

	setItemDelegate(new THSettingsItemDelegate);
	setItemsExpandable(false);
	setRootIsDecorated(false);
	setAutoExpandDelay(0);
	setHeaderHidden(true);
	setIndentation(0);

	connect(this, SIGNAL(doubleClicked(const QModelIndex&)),
			this, SLOT(booleanDoubleClicked(const QModelIndex&)));
}

THSettingsView::~THSettingsView() {
}

void THSettingsView::booleanDoubleClicked (const QModelIndex& index) {
	if (!index.isValid())
		return;

	QString keyName = index.data(Qt::DisplayRole).toString();
	int itemType = index.data(Qt::UserRole + 2).toInt();
	QVariant keyValue = index.data(Qt::UserRole + 1);

	if (itemType == THSettingsItem::Link) {
		emit linkClicked(keyName, keyValue);
	} else if (itemType == THSettingsItem::MultiValue) {
		emit multiValueClicked(keyName, keyValue);
	} else if (itemType == THSettingsItem::Button) {
		emit buttonClicked(keyName, keyValue);
	} else if (itemType == THSettingsItem::Value) {
		if (keyValue.type() == QVariant::Bool)
			model()->setData(index, !keyValue.toBool(), Qt::UserRole + 1);
		else
			emit valueClicked(keyName, keyValue);
	}
}

