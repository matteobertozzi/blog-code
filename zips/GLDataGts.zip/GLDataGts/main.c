/* 
 * How to Compile:
 *  gcc -framework GLUT -framework OpenGL main.c gldata.c gldatagts.c -o gldata
 * 
 * How to Use:
 *  ./gldata [gts file name]
 */

#if defined(__APPLE__)
    #include <OpenGL/gl.h>
	#include <OpenGL/glu.h>
    #include <GLUT/glut.h>
#else
    #include <GL/gl.h>
    #include <GL/glu.h>
    #include <GL/glut.h>
#endif

#include <stdlib.h>
#include <stdio.h>

#include "gldatagts.h"
#include "gldata.h"

static GLfloat light[] = { 0.0, 1.0, 1.0, 1.0 };
static GLfloat tx = 0, ty = 0, tz = 0;
static GLuint rx = 0, ry = 0, rz = 0;
static GLuint object;

static int animate = 1;

#define GTS_SHAPE_FILENAME      "gts-samples/tie.gts"
const char *gts_shape_filename = NULL;

static void rotateCamera (GLuint dx, GLuint dy, GLuint dz) {
    rx = (rx + dx) % 360;
    ry = (ry + dy) % 360;
    rz = (rz + dz) % 360;
    glutPostRedisplay();
}

static void moveCamera (GLfloat dx, GLfloat dy, GLfloat dz) {
    tx += dx;
    ty += dy;
    tz += dz;
    glutPostRedisplay();
} 

static void moveLight (GLfloat dx, GLfloat dy, GLfloat dz) {
    light[0] += dx;
    light[1] += dy;
    light[2] += dz;
    glutPostRedisplay();
}

static void drawObject (void) {
    GLDataGts *gts;

    gts = glDataGtsAlloc();
    if (glDataGtsRead(gts, gts_shape_filename)) {
        GLDataSurface *surface;
        GLDataUInt i, count;
        GLDataTriangle *t;

        surface = glDataGtsSurface(gts, NULL);
        count = glDataSurfaceCount(surface);
        for (i = 0; i < count; ++i) {
            t = glDataSurfaceGet(surface, i);

            glBegin(GL_LINE_LOOP);
            glVertex3f(t->p1->x, t->p1->y, t->p1->z);
            glVertex3f(t->p2->x, t->p2->y, t->p2->z);
            glVertex3f(t->p3->x, t->p3->y, t->p3->z);
            glEnd();
        }
    }
    
    glDataGtsRelease(gts);
}

void init (void) {
    glClearColor(0.0, 0.0, 0.0, 0.0);
   
    glShadeModel(GL_SMOOTH);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_DEPTH_TEST);

    object = glGenLists(1);
    glNewList(object, GL_COMPILE);
    drawObject();
    glEndList();
}

void displayHandler (void) {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    glTranslatef(-1.0, 0.0, -40.0);
    glLightfv(GL_LIGHT0, GL_POSITION, light);

    glTranslatef(tx, ty, tz);
    glRotatef((GLfloat)rx, 0.0, 1.0, 0.0);
    glRotatef((GLfloat)ry, 1.0, 0.0, 0.0);
    glRotatef((GLfloat)rz, 0.0, 0.0, 1.0);  

#if defined(DEBUG_CAMERA_VALUES)
    printf("R(%.2d, %.2d %2d)\n", rx, ry, rz);
    printf("T(%.2f, %.2f %2f)\n", tx, ty, tz);
    printf("L(%.2f, %.2f %2f)\n", light[0], light[1], light[2]);
    printf("\n");
#endif

    glCallList(object);

    glutSwapBuffers();
}

void reshapeHandler (int w, int h) {
    glViewport(0, 0, (GLsizei) w, (GLsizei)h); 

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0f,(GLfloat)w/(GLfloat)h,0.1f, 200.0f);
    
    glMatrixMode(GL_MODELVIEW);
}

void keyboardHandler (unsigned char key, int x, int y) {
    // Rotate Camera
    if (key == 'x' || key == 'X')
        rotateCamera((key == 'x') ? 5 : -5, 0, 0);
    else if (key == 'y' || key == 'Y')
        rotateCamera(0, (key == 'y') ? 5 : -5, 0);
    else if (key == 'z' || key == 'Z')
        rotateCamera(0, 0, (key == 'z') ? 5 : -5);

    // Move Camera
    else if (key == 'l')
        moveCamera(-0.2, 0.0, 0.0);
    else if (key == 'r')
        moveCamera(0.2, 0.0, 0.0);
    else if (key == 'u')
        moveCamera(0.0, 0.2, 0.0);
    else if (key == 'd')
        moveCamera(0.0, -0.2, 0.0);
    else if (key == 'i')
        moveCamera(0.0, 0.0, -1.0);
    else if (key == 'o')
        moveCamera(0.0, 0.0, 1.0);

    // Move Light
    else if (key == 'b' || key == 'B')
        moveLight((key == 'b') ? 1.0 : -1.0, 0, 0);
    else if (key == 'n' || key == 'N')
        moveLight(0, (key == 'n') ? 1.0 : -1.0, 0);
    else if (key == 'm' || key == 'M')
        moveLight(0, 0, (key == 'm') ? 1.0 : -1.0);

    // Start/Stop Animation
    else if (key == 'p')
        animate = !animate;
    else if (key == 'q')
        exit(0);
}

void animationHandler (int value) {
    if (animate) {
        rx = (rx + 6) % 360;
        ry = (ry + 3) % 360;
        rz = (rz + 1) % 360;

        light[2] += value;
        value = (light[2] < 2.0) ? 1 : (light[2] > 40.0) ? -1 : value;

        glutPostRedisplay();
        glutTimerFunc(80, animationHandler, value);
    }
}

int main (int argc, char **argv) {
    glutInit(&argc, argv);
    //glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_ALPHA | GLUT_DEPTH);

    glutInitWindowSize(720, 460); 
    glutInitWindowPosition(100, 100);
    
    glutCreateWindow("OpenGL Gts Shape");

    // Peek Name from Command line, or use default.
    gts_shape_filename = (argc < 2) ? GTS_SHAPE_FILENAME : argv[1];

    init();
    glutDisplayFunc(displayHandler); 
    glutReshapeFunc(reshapeHandler);
    glutKeyboardFunc(keyboardHandler);
    glutTimerFunc(80, animationHandler, 1);

    glutMainLoop();
    return(0);
}

