#ifndef _GLDATA_GTS_H_
#define _GLDATA_GTS_H_

#include "gldata.h"

typedef struct _GLDataGts GLDataGts;

GLDataGts *     glDataGtsAlloc      (void);
GLDataGts *     glDataGtsRetain     (GLDataGts *gts);
void            glDataGtsRelease    (GLDataGts *gts);
GLDataBool      glDataGtsRead       (GLDataGts *gts, const char *filename);
GLDataSurface * glDataGtsSurface    (GLDataGts *gts, GLDataSurface *surface);

#endif /* !_GLDATA_GTS_H_ */

