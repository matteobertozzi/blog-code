#ifndef _GLDATA_H_
#define _GLDATA_H_

#define GLDATA_FALSE        (0)
#define GLDATA_TRUE         (1)
typedef char GLDataBool;

#if defined(USE_GLDATA_LONG)
    typedef unsigned long int GLDataUInt;
#else
    typedef unsigned int GLDataUInt;
#endif

#if defined(USE_GLDATA_DOUBLE)
    typedef double GLDataFloat;
#else
    typedef float GLDataFloat;
#endif

typedef struct {
    GLDataFloat x;
    GLDataFloat y;
    GLDataFloat z;

    GLDataUInt _retain;
} GLDataPoint;

GLDataPoint *   glDataPointAlloc       (void);
GLDataPoint *   glDataPointInit        (GLDataPoint *point,
                                        GLDataFloat x, 
                                        GLDataFloat y,
                                        GLDataFloat z);
void            glDataPointSet         (GLDataPoint *point,
                                        GLDataFloat x, 
                                        GLDataFloat y,
                                        GLDataFloat z);
GLDataPoint *   glDataPointRetain      (GLDataPoint *point);
void            glDataPointRelease     (GLDataPoint *point);

typedef struct {
    GLDataUInt a;
    GLDataUInt b;

    GLDataUInt _retain;
} GLDataEdge;

GLDataEdge *    glDataEdgeAlloc         (void);
GLDataEdge *    glDataEdgeInit         (GLDataEdge *edge,
                                        GLDataUInt a, 
                                        GLDataUInt b);
void            glDataEdgeSet          (GLDataEdge *edge,
                                        GLDataUInt a, 
                                        GLDataUInt b);
GLDataEdge *    glDataEdgeRetain       (GLDataEdge *edge);
void            glDataEdgeRelease      (GLDataEdge *edge);

typedef struct {
    GLDataUInt a;
    GLDataUInt b;
    GLDataUInt c;

    GLDataUInt _retain;
} GLDataFace;

GLDataFace *    glDataFaceAlloc        (void);
GLDataFace *    glDataFaceInit         (GLDataFace *face,
                                        GLDataUInt a, 
                                        GLDataUInt b, 
                                        GLDataUInt c);
void            glDataFaceSet          (GLDataFace *face,
                                        GLDataUInt a, 
                                        GLDataUInt b, 
                                        GLDataUInt c);
GLDataFace *    glDataFaceRetain       (GLDataFace *face);
void            glDataFaceRelease      (GLDataFace *face);

typedef struct {
    GLDataPoint *p1;
    GLDataPoint *p2;
    GLDataPoint *p3;

    GLDataUInt _retain;
} GLDataTriangle;

GLDataTriangle *glDataTriangleAlloc    (void);
GLDataTriangle *glDataTriangleInit     (GLDataTriangle *triangle,
                                        GLDataPoint *p1, 
                                        GLDataPoint *p2, 
                                        GLDataPoint *p3);
void            glDataTriangleSet      (GLDataTriangle *triangle,
                                        GLDataPoint *p1, 
                                        GLDataPoint *p2, 
                                        GLDataPoint *p3);
GLDataTriangle *glDataTriangleRetain   (GLDataTriangle *triangle);
void            glDataTriangleRelease  (GLDataTriangle *triangle);

typedef struct {
    GLDataTriangle **triangles;

    GLDataUInt _count;
    GLDataUInt _nitems;
    GLDataUInt _retain;
} GLDataSurface;

GLDataSurface * glDataSurfaceAlloc     (void);
GLDataSurface * glDataSurfaceInit      (GLDataSurface *surface, 
                                        GLDataUInt nitems);
GLDataSurface * glDataSurfaceRetain    (GLDataSurface *surface);
void            glDataSurfaceRelease   (GLDataSurface *surface);

GLDataUInt      glDataSurfaceCount     (GLDataSurface *surface);
void            glDataSurfaceClear     (GLDataSurface *surface);
void            glDataSurfaceAdd       (GLDataSurface *surface,
                                        GLDataTriangle *triangle);
GLDataTriangle *glDataSurfaceGet       (GLDataSurface *surface,
                                        GLDataUInt index);

#endif /* !_GLDATA_H_ */

