#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdio.h>

#include "gldatagts.h"

enum GtsState {
    GTS_STATE_READY,
    GTS_STATE_VERTEX,
    GTS_STATE_EDGES,
    GTS_STATE_FACES,
    GTS_STATE_FINISHED
};

struct _GLDataGts {
    GLDataPoint **vertexes;
    GLDataUInt nvertexes;

    GLDataEdge **edges;
    GLDataUInt nedges;

    GLDataFace **faces;
    GLDataUInt nfaces;

    GLDataUInt _retain;
};


static char *_strtrim (char *s) {
    size_t len = strlen(s);
    size_t lws;

    while (len && isspace(s[len - 1]))
        --len;

    if (len) {
        lws = strspn(s, " \t\n\r\v");
        len -= lws;
        memmove(s, s + lws, len);
    }

    s[len] = '\0';
    return(len == 0 ? NULL : s);
}

static GLDataGts *_glDataGtsInternalAlloc (GLDataGts *gts) {  
    if (!(gts->vertexes = malloc(gts->nvertexes * sizeof(GLDataPoint *))))
        return(NULL);

    if (!(gts->edges = malloc(gts->nedges * sizeof(GLDataEdge *)))) {
        free(gts->vertexes);
        return(NULL);
    }

    if (!(gts->faces = malloc(gts->nfaces * sizeof(GLDataFace *)))) {
        free(gts->vertexes);
        free(gts->edges);
        return(NULL);
    }

    return(gts);
}

GLDataGts *glDataGtsAlloc (void) {
    GLDataGts *gts;

    if ((gts = (GLDataGts *) malloc(sizeof(GLDataGts)))) {
        gts->_retain = 1;

        gts->vertexes = NULL;
        gts->nvertexes = 0;

        gts->edges = NULL;
        gts->nedges = 0;

        gts->faces = NULL;
        gts->nfaces = 0;
    }

    return(gts);
}

GLDataGts *glDataGtsRetain (GLDataGts *gts) {
    gts->_retain++;
    return(gts);
}

void glDataGtsRelease (GLDataGts *gts) {
    if (gts == NULL) return;

    gts->_retain--;
    if (!(gts->_retain)) {
        GLDataUInt i;

        /* Free Vertexes */
        if (gts->vertexes != NULL) {
            for (i = 0; i < gts->nvertexes; ++i)
                glDataPointRelease(gts->vertexes[i]);
            free(gts->vertexes);
        }

        /* Free Edges */
        if (gts->edges != NULL) {
            for (i = 0; i < gts->nedges; ++i)
                glDataEdgeRelease(gts->edges[i]);
            free(gts->edges);
        }

        /* Free Faces */
        if (gts->faces != NULL) {
            for (i = 0; i < gts->nfaces; ++i)
                glDataFaceRelease(gts->faces[i]);
            free(gts->faces);
        }

        free(gts);
    }
}

GLDataBool glDataGtsRead (GLDataGts *gts, const char *filename) {
    enum GtsState state = GTS_STATE_READY;
    char buffer[256];
    GLDataUInt index;
    FILE *fh;

    if ((fh = fopen(filename, "r")) == NULL)
        return(GLDATA_FALSE);

    while (fgets(buffer, sizeof(buffer), fh) != NULL) {
        if (_strtrim(buffer) == NULL)
            continue;

        switch (state) {
            case GTS_STATE_READY: {
                /* Read Number of Vertexes, Edges, Faces */                
                sscanf(buffer, "%u %u %u", &(gts->nvertexes), 
                                           &(gts->nedges), 
                                           &(gts->nfaces));

                /* Allocate Vertexes, Edges, Faces */ 
                if (!_glDataGtsInternalAlloc(gts))
                    goto _read_failed;

                state = GTS_STATE_VERTEX;
                index = 0;
                break;
            } case GTS_STATE_VERTEX: {
                GLDataFloat x, y, z;
                GLDataPoint *point;

                /* Read Vertex */
                sscanf(buffer, "%f %f %f", &x, &y, &z);
                if (!(point = glDataPointInit(glDataPointAlloc(), x, y, z)))
                    goto _read_failed;

                gts->vertexes[index++] = point;
                if (index == gts->nvertexes) {
                    state = GTS_STATE_EDGES;
                    index = 0;
                }
                break;
            } case GTS_STATE_EDGES: {
                GLDataEdge *edge;
                GLDataUInt a, b;

                /* Read Edge */
                sscanf(buffer, "%d %d", &a, &b);
                if (!(edge = glDataEdgeInit(glDataEdgeAlloc(), a-1, b-1)))
                    goto _read_failed;

                gts->edges[index++] = edge;
                if (index == gts->nedges) {
                    state = GTS_STATE_FACES;
                    index = 0;
                }
                break;
            } case GTS_STATE_FACES: {
                GLDataUInt a, b, c;
                GLDataFace *face;

                /* Read Edge */
                sscanf(buffer, "%d %d %d", &a, &b, &c);
                if (!(face = glDataFaceInit(glDataFaceAlloc(), a-1, b-1, c-1)))
                    goto _read_failed;

                gts->faces[index++] = face;
                if (index == gts->nfaces) {
                    state = GTS_STATE_FINISHED;
                    index = 0;
                }
                break;
            } case GTS_STATE_FINISHED: {
                goto _read_ok;
            }
        }
    }    

_read_ok:
    fclose(fh);
    return(GLDATA_TRUE);

_read_failed:
    fclose(fh);
    return(GLDATA_FALSE);
}

struct GtsEdgeSet {
    GLDataUInt edge[3];
    GLDataUInt count;
};

void _gtsEdgeSetInit (struct GtsEdgeSet *set) {
    set->count = 0;
}

GLDataBool _gtsEdgeSetContains (struct GtsEdgeSet *set, GLDataUInt edge) {
    GLDataUInt i;

    for (i = 0; i < set->count; ++i) {
        if (set->edge[i] == edge)
            return(GLDATA_TRUE);
    }

    return(GLDATA_FALSE);
}

void _gtsEdgeSetAdd (struct GtsEdgeSet *set, GLDataEdge *edge) {
    if (set->count < 3) {
        if (!_gtsEdgeSetContains(set, edge->a))
            set->edge[set->count++] = edge->a;

        if (!_gtsEdgeSetContains(set, edge->b))
            set->edge[set->count++] = edge->b;
    }
}

GLDataSurface *glDataGtsSurface (GLDataGts *gts, GLDataSurface *surface) {
    struct GtsEdgeSet edge_set;
    GLDataPoint *p1, *p2, *p3;
    GLDataTriangle *triangle;
    GLDataFace *face;
    GLDataUInt i;

    if (surface == NULL) surface = glDataSurfaceAlloc();
    glDataSurfaceInit(surface, gts->nfaces);

    for (i = 0; i < gts->nfaces; ++i) {
        face = gts->faces[i];

        _gtsEdgeSetInit(&edge_set);
        _gtsEdgeSetAdd(&edge_set, gts->edges[face->a]);
        _gtsEdgeSetAdd(&edge_set, gts->edges[face->b]);
        _gtsEdgeSetAdd(&edge_set, gts->edges[face->c]);

         p1 = gts->vertexes[edge_set.edge[0]];
         p2 = gts->vertexes[edge_set.edge[1]];
         p3 = gts->vertexes[edge_set.edge[2]];

        triangle = glDataTriangleInit(glDataTriangleAlloc(), p1, p2, p3);
        glDataSurfaceAdd(surface, triangle);
    }

    return(surface);
}

