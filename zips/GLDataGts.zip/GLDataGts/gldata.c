#include <stdlib.h>
#include <string.h>

#include "gldata.h"

/* ===========================================================================
 *  Point
 */
GLDataPoint *glDataPointAlloc (void) {
    GLDataPoint *point;

    if ((point = (GLDataPoint *) malloc(sizeof(GLDataPoint)))) {
        point->_retain = 1;
        point->x = 0;
        point->y = 0;
        point->z = 0;
    }

    return(point);
}

GLDataPoint *glDataPointInit (GLDataPoint *point,
                              GLDataFloat x, 
                              GLDataFloat y,
                              GLDataFloat z)
{
    point->_retain = 1;
    point->x = x;
    point->y = y;
    point->z = z;

    return(point);
}

void glDataPointSet (GLDataPoint *point,
                     GLDataFloat x, 
                     GLDataFloat y,
                     GLDataFloat z)
{
    point->x = x;
    point->y = y;
    point->z = z;
}

GLDataPoint *glDataPointRetain (GLDataPoint *point) {
    point->_retain++;
    return(point);
}

void glDataPointRelease (GLDataPoint *point) {
    if (point == NULL) return;

    point->_retain--;
    if (!(point->_retain))
        free(point);
}

/* ===========================================================================
 *  Edge
 */
GLDataEdge *glDataEdgeAlloc (void) {
    GLDataEdge *edge;

    if ((edge = (GLDataEdge *) malloc(sizeof(GLDataEdge)))) {
        edge->_retain = 1;
        edge->a = 0;
        edge->b = 0;
    }

    return(edge);
}

GLDataEdge *glDataEdgeInit (GLDataEdge *edge,
                            GLDataUInt a, 
                            GLDataUInt b)
{
    edge->_retain = 1;
    glDataEdgeSet(edge, a, b);
    return(edge);
}

void glDataEdgeSet (GLDataEdge *edge,
                    GLDataUInt a, 
                    GLDataUInt b)
{
    edge->a = a;
    edge->b = b;
}

GLDataEdge *glDataEdgeRetain (GLDataEdge *edge) {
    edge->_retain++;
    return(edge);
}

void glDataEdgeRelease (GLDataEdge *edge) {
    if (edge == NULL) return;

    edge->_retain--;
    if (!(edge->_retain))
        free(edge);
}

/* ===========================================================================
 *  Face
 */
GLDataFace *glDataFaceAlloc (void) {
    GLDataFace *face;

    if ((face = (GLDataFace *) malloc(sizeof(GLDataFace)))) {
        face->_retain = 1;
        face->a = 0;
        face->b = 0;
        face->c = 0;
    }

    return(face);
}

GLDataFace *glDataFaceInit (GLDataFace *face,
                            GLDataUInt a, 
                            GLDataUInt b, 
                            GLDataUInt c)
{
    face->_retain = 1;
    glDataFaceSet(face, a, b, c);
    return(face);
}

void glDataFaceSet (GLDataFace *face,
                    GLDataUInt a, 
                    GLDataUInt b, 
                    GLDataUInt c)
{
    face->a = a;
    face->b = b;
    face->c = c;
}

GLDataFace *glDataFaceRetain (GLDataFace *face) {
    face->_retain++;
    return(face);
}

void glDataFaceRelease (GLDataFace *face) {
    if (face == NULL) return;

    face->_retain--;
    if (!(face->_retain))
        free(face);
}

/* ===========================================================================
 *  Triangle (Depends on Point)
 */
GLDataTriangle *glDataTriangleAlloc (void) {
    GLDataTriangle *triangle;

    if ((triangle = (GLDataTriangle *) malloc(sizeof(GLDataTriangle)))) {
        triangle->_retain = 1;
        triangle->p1 = NULL;
        triangle->p2 = NULL;
        triangle->p3 = NULL;
    }

    return(triangle);
}

GLDataTriangle *glDataTriangleInit (GLDataTriangle *triangle,
                                    GLDataPoint *p1, 
                                    GLDataPoint *p2, 
                                    GLDataPoint *p3)
{
    triangle->_retain = 1;
    glDataTriangleSet(triangle, p1, p2, p3);
    return(triangle);
}

void glDataTriangleSet (GLDataTriangle *triangle,
                        GLDataPoint *p1, 
                        GLDataPoint *p2, 
                        GLDataPoint *p3)
{
    triangle->p1 = glDataPointRetain(p1);
    triangle->p2 = glDataPointRetain(p2);
    triangle->p3 = glDataPointRetain(p3);
}

GLDataTriangle *glDataTriangleRetain (GLDataTriangle *triangle) {
    triangle->_retain++;
    return(triangle);
}

void glDataTriangleRelease (GLDataTriangle *triangle) {
    if (triangle == NULL) return;

    triangle->_retain--;
    if (!(triangle->_retain)) {
        glDataPointRelease(triangle->p1);
        glDataPointRelease(triangle->p2);
        glDataPointRelease(triangle->p3);
        free(triangle);
    }
}

/* ===========================================================================
 *  Surface
 */
GLDataSurface *glDataSurfaceAlloc (void) {
    GLDataSurface *surface;

    if ((surface = (GLDataSurface *) malloc(sizeof(GLDataSurface)))) {
        surface->_retain = 1;
        surface->_nitems = 0;
        surface->_count = 0;
        surface->triangles = NULL;
    }

    return(surface);
}

GLDataSurface *glDataSurfaceInit (GLDataSurface *surface, GLDataUInt nitems) {
    GLDataTriangle **ts;
    size_t ts_size;

    ts_size = (nitems * sizeof(GLDataTriangle *));
    if (!(ts = (GLDataTriangle **) malloc(ts_size)))
        return(NULL);

    surface->_retain = 1;
    surface->_nitems = nitems;
    surface->_count = 0;
    surface->triangles = (GLDataTriangle **) memset(ts, 0, ts_size);

    return(surface);
}

GLDataSurface *glDataSurfaceRetain (GLDataSurface *surface) {
    surface->_retain++;
    return(surface);
}

void glDataSurfaceRelease (GLDataSurface *surface) {
    if (surface == NULL) return;

    surface->_retain--;
    if (!(surface->_retain)) {
        if (surface->triangles != NULL) {
            GLDataUInt i;

            for (i = 0; i < surface->_count; ++i)
                glDataTriangleRelease(surface->triangles[i]);

            free(surface->triangles);
        }

        free(surface);
    }
}

GLDataUInt glDataSurfaceCount (GLDataSurface *surface) {
    return(surface->_count);
}

void glDataSurfaceClear (GLDataSurface *surface) {
    GLDataUInt i;

    for (i = 0; i < surface->_count; ++i) {
        glDataTriangleRelease(surface->triangles[i]);
        surface->triangles[i] = NULL;
    }

    surface->_count = 0;
}

void glDataSurfaceAdd (GLDataSurface *surface, GLDataTriangle *triangle) {
    surface->triangles[surface->_count++] = glDataTriangleRetain(triangle);
}

GLDataTriangle *glDataSurfaceGet (GLDataSurface *surface,
                                  GLDataUInt index)
{
    return(surface->triangles[index]);
}

