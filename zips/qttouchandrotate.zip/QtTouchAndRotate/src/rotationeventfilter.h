/* 
 * Copyright (C) 2009 Matteo Bertozzi.
 *
 * This file is part of MokoTouch.
 * 
 * MokoTouch is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * MokoTouch is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with MokoTouch.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _THROTATIONEVENTFILTER_H_
#define _THROTATIONEVENTFILTER_H_

#include <QObject>
class THRotationEventFilterPrivate;
class THRotableWidget;

class THRotationEventFilter : public QObject {
	Q_OBJECT

	public:
		THRotationEventFilter (THRotableWidget *w, QObject *parent = 0);
		~THRotationEventFilter();

		// Methods
		bool eventFilter (QObject *object, QEvent *event);

		// Properties
		bool enabled (void) const;
		void setEnabled (bool enabled);

	private:
		THRotationEventFilterPrivate *d;
};

#endif /* !_THROTATIONEVENTFILTER_H_ */

