/* 
 * Copyright (C) 2009 Matteo Bertozzi.
 *
 * This file is part of MokoTouch.
 * 
 * MokoTouch is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * MokoTouch is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with MokoTouch.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <QPaintEvent>
#include <QPainter>
#include <QDebug>

#include "rotation.h"

#define IMAGE_WIDTH		200

class RotationPrivate {
	public:
		QPixmap pixmap;
		qreal angle;
};

Rotation::Rotation (const QPixmap& pixmap, QWidget *parent)
	: QWidget(parent), d(new RotationPrivate)
{
	d->angle = 0.0;	
	d->pixmap = pixmap.scaledToWidth(IMAGE_WIDTH, Qt::SmoothTransformation);
}

Rotation::~Rotation() {
	delete d;
}

void Rotation::rotate (int angle) {
	d->angle = angle;																			
	update();
}

void Rotation::paintEvent (QPaintEvent *event) {
	QPainter p(this);
	p.setRenderHint(QPainter::SmoothPixmapTransform);
	p.setRenderHint(QPainter::TextAntialiasing);

	// Draw Angle Info
	p.drawText(	10, event->rect().height() - 20, 
				tr("Angle: %1").arg(d->angle));

	// Draw Image
	QPointF center(qreal(d->pixmap.width()) / 2, qreal(d->pixmap.height()) / 2);
	p.translate(width() / 2 - center.x(), height() / 2 - center.y());
	p.translate(center);
	p.rotate(d->angle);
	p.translate(-center);

	p.drawPixmap(0, 0, d->pixmap);

	p.end();
}

