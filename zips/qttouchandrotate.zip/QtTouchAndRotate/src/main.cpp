#include <QApplication>

#include "rotationeventfilter.h"
#include "rotation.h"

int main (int argc, char **argv) {
	QApplication app(argc, argv);
	
	Rotation window(QPixmap("pics/image.jpg"));
	new THRotationEventFilter(&window);
	window.resize(290, 280);
	window.show();

	return app.exec();
}

