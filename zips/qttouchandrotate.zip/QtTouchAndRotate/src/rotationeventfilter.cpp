/* 
 * Copyright (C) 2009 Matteo Bertozzi.
 *
 * This file is part of MokoTouch.
 * 
 * MokoTouch is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * MokoTouch is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with MokoTouch.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <cmath>

#include <QApplication>
#include <QMouseEvent>
#include <QWidget>

#include "rotationeventfilter.h"
#include "rotablewidget.h"

#define PI		(3.14159265358979323846)

/* ============================================================================
 *  PRIVATE Class
 */
class THRotationEventFilterPrivate {
	public:
		THRotableWidget *widget;
		bool enabled;
		int angle;
		int start;

	public:
		int angleFromPos (const QPoint& pos);
};

int THRotationEventFilterPrivate::angleFromPos (const QPoint& pos) {
	QWidget *w = dynamic_cast<QWidget *>(widget);
	qreal yy = (qreal)w->height() / 2.0 - pos.y();
	qreal xx = (qreal)pos.x() - w->width() / 2.0;
	qreal a = atan2(yy, xx);

	if (a < PI / -2)
		a = a + PI * 2;

	return (int)(0.5 + 360 * (PI * 3 / 2 - a) / (2 * PI));
}

/* ============================================================================
 *  PUBLIC Constructor/Destructor
 */
THRotationEventFilter::THRotationEventFilter (THRotableWidget *w, QObject *parent)
	: QObject(parent), d(new THRotationEventFilterPrivate)
{
	d->widget = w;
	d->enabled = true;
	dynamic_cast<QWidget *>(d->widget)->installEventFilter(this);
}

THRotationEventFilter::~THRotationEventFilter() {
	delete d;
}

/* ============================================================================
 *  PUBLIC Methods
 */
bool THRotationEventFilter::eventFilter(QObject *object, QEvent *event) {
	Q_UNUSED(object)

	if (!d->enabled)
		return(false);

	QMouseEvent *mouseEvent = dynamic_cast<QMouseEvent*>(event);
	if (mouseEvent == NULL)
		return(false);

	QEvent::Type type = event->type();
	if (type == QEvent::MouseButtonPress) {
		d->start = d->angleFromPos(mouseEvent->pos());
	} else if (type == QEvent::MouseButtonRelease) {
		d->angle += d->angleFromPos(mouseEvent->pos()) - d->start;
	} else if (type == QEvent::MouseMove) {
		int angle = d->angleFromPos(mouseEvent->pos()) - d->start;
		d->widget->rotate(d->angle + angle);
	}

	return(false);
}

/* ============================================================================
 *  PUBLIC Properties
 */
bool THRotationEventFilter::enabled (void) const {
	return(d->enabled);
}

void THRotationEventFilter::setEnabled (bool enabled) {
	d->enabled = enabled;
}

