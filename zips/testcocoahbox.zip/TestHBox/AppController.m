//
//  AppController.m
//  TestHBox
//
//  Created by Matteo Bertozzi on 11/8/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "AppController.h"


@implementation AppController

- (NSTextField *)createTextField:(NSString *)text {
	NSTextField *field = [[NSTextField alloc] init];
	[field setStringValue:text];
	return [field retain];
}

- (NSButton *)createButton:(NSString *)caption {
	NSButton *button = [[NSButton alloc] init];
	[button setBezelStyle:NSRecessedBezelStyle];
	[button setButtonType:NSPushOnPushOffButton];
	[[button cell] setHighlightsBy:(NSCellIsBordered | NSCellIsInsetButton)];
	[button setShowsBorderOnlyWhileMouseInside:YES];
	[button setButtonType:NSOnOffButton];
	[button setTitle:caption];
	
	return [button retain];
}

- (void)awakeFromNib {
	[box addItem:[self createTextField:@"Label 1"]];
	[box addItem:[self createButton:@"Button 1"]];
	[box removeItemAtIndex:0];
	[box addItem:[self createTextField:@"Label 2"]];
	[box addItem:[self createButton:@"Say"]];
}

- (IBAction) clearButton:(id)sender {
	[box clearItems];
}

- (IBAction) addButton:(id)sender {
	[box addItem:[self createButton:@"Button"]];
}

@end
