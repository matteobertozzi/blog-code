//
//  HBox.m
//  TestHBox
//
//  Created by Matteo Bertozzi on 11/8/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "HBox.h"


@implementation HBox

@synthesize space = hspace;

- (id)initWithFrame:(NSRect)frameRect {
	if ((self = [super initWithFrame:frameRect])) {
		hspace = 4;
	}
	return self;
}

- (void)dealloc {
	[super dealloc];
}

- (void)clearItems {	
	NSArray *subviewArray = [self subviews];
	NSUInteger subviewCount = [subviewArray count];
	
	while (subviewCount-- > 0) {
		NSView *view = [subviewArray objectAtIndex:0];
		[view removeFromSuperview];
		[view release];
	}

	[self setNeedsDisplay:YES];
}

- (void)removeItemAtIndex:(NSUInteger)index {
	NSView *view = [[self subviews] objectAtIndex:index];
	int viewWidth = -1 * [view frame].size.width - hspace;
	[view removeFromSuperview];
	[view release];
	
	[self moveItems:viewWidth fromIndex:index];
	[self setNeedsDisplay:YES];
}

- (void)moveItem:(NSView *)view space:(NSInteger)space {
	NSRect rect = [view frame];
	rect.origin.x += space;
	[view setFrame:rect];
}

- (void)moveItems:(NSInteger) space fromIndex:(NSUInteger)index {
	NSArray *subviewArray = [self subviews];
	NSUInteger subviewCount = [subviewArray count];
	
	for (; index < subviewCount; ++index)
		[self moveItem:[subviewArray objectAtIndex:index] space:space];
}

- (void)addItem:(NSControl *)itemView {
	[itemView sizeToFit];
	
	NSRect itemFrame = [itemView frame];
	NSView *lastView = [[self subviews] lastObject];
	if (lastView != nil) {
		itemFrame.origin.x = [lastView frame].origin.x + 
							 [lastView frame].size.width +
							 hspace;
	} else {
		itemFrame.origin.x = [self bounds].origin.x + hspace;
	}
	itemFrame.origin.y = [self bounds].origin.y;
	[itemView setFrame:itemFrame];
	
	[self addSubview:itemView];
	[self setNeedsDisplay:YES];
}

@end
