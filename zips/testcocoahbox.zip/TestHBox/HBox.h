//
//  HBox.h
//  TestHBox
//
//  Created by Matteo Bertozzi on 11/8/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface HBox : NSView {
	NSUInteger hspace;
}

@property (readwrite, assign) NSUInteger space;

- (id)initWithFrame:(NSRect)frameRect;

- (void)clearItems;

- (void)addItem:(NSControl *)itemView;
- (void)removeItemAtIndex:(NSUInteger)index;

- (void)moveItem:(NSView *)view space:(NSInteger)space;
- (void)moveItems:(NSInteger) space fromIndex:(NSUInteger)index;
@end
