//
//  AppController.h
//  TestHBox
//
//  Created by Matteo Bertozzi on 11/8/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "HBox.h"


@interface AppController : NSObject {
	IBOutlet HBox *box;
}

- (IBAction) clearButton:(id)sender;
- (IBAction) addButton:(id)sender;

@end
