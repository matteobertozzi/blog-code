//
//  AppController.h
//  TestSqlite
//
//  Created by Matteo Bertozzi on 11/22/08.
//  Copyright 2008 Matteo Bertozzi. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface AppController : NSObject {

}

- (IBAction)clickMe:(id)sender;

@end
