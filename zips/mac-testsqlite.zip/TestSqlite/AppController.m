//
//  AppController.m
//  TestSqlite
//
//  Created by Matteo Bertozzi on 11/22/08.
//  Copyright 2008 Matteo Bertozzi. All rights reserved.
//

#import "AppController.h"
#import "Sqlite.h"

@implementation AppController
- (IBAction)clickMe:(id)sender {
	Sqlite *sqlite = [[Sqlite alloc] init];

    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *writableDBPath = [documentsDirectory stringByAppendingPathComponent:@"SQLiteTest.db"];
	if (![sqlite open:writableDBPath])
		return;
	
	[sqlite executeNonQuery:@"DROP TABLE test"];
	[sqlite executeNonQuery:@"CREATE TABLE test (key TEXT NOT NULL, num INTEGER, value TEXT);"];
	[sqlite executeNonQuery:@"DELETE FROM test;"];
	[sqlite executeNonQuery:@"INSERT INTO test VALUES (?, ?, ?);", [Sqlite createUuid], [NSNumber numberWithInt:2], @"PROVA"];
	[sqlite executeNonQuery:@"INSERT INTO test VALUES (?, ?, ?);", [Sqlite createUuid], [NSNumber numberWithInt:3], @"PROVA 2"];
	[sqlite executeNonQuery:@"INSERT INTO test VALUES (?, ?, ?);", [Sqlite createUuid], [NSNull null], [NSNull null]];
	
	NSArray *results = [sqlite executeQuery:@"SELECT * FROM test;"];
	for (NSDictionary *dictionary in results) {
		NSLog(@"Row");
		for (NSString *key in [dictionary keyEnumerator])
			NSLog(@" - %@ %@", key, [dictionary objectForKey:key]);
	}
	
	[results release];
	[sqlite release];
}
@end
