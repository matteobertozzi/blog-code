#include <QMessageBox>
#include <QFormLayout>
#include <QVBoxLayout>
#include <QLineEdit>
#include <QWebFrame>
#include <QWebView>
#include <QFile>

#include "hostiplookup.h"
#include "geoipviewer.h"

class THGeoIpViewerPrivate {
    public:
        THHostIpLookup *hostIpLookup;
        QLineEdit *ipAddressEdit;
        QWebView *webView;
};

THGeoIpViewer::THGeoIpViewer (QWidget *parent)
    : QWidget(parent), d(new THGeoIpViewerPrivate)
{
    d->hostIpLookup = new THHostIpLookup(this);
    d->ipAddressEdit = new QLineEdit;
    d->webView = new QWebView;
    d->webView->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    QFile file(":/html/gmap.html");
    file.open(QIODevice::ReadOnly);
    d->webView->setHtml(file.readAll());
    file.close();

    connect(d->ipAddressEdit, SIGNAL(returnPressed()), 
            this, SLOT(lookupIpAddress()));
    connect(d->hostIpLookup, SIGNAL(finished(bool)),
            this, SLOT(ipLookupFinished(bool)));

    QFormLayout *formLayout = new QFormLayout;
    formLayout->addRow(tr("Ip Address:"), d->ipAddressEdit);

    QVBoxLayout *layout = new QVBoxLayout;    
    layout->addLayout(formLayout);
    layout->addWidget(d->webView);

    setLayout(layout);
}

THGeoIpViewer::~THGeoIpViewer() {
    delete d;
}

void THGeoIpViewer::loadMap (const QString& ipAddress,
                             const QString& queryAddress)
{
    QWebFrame *frame = d->webView->page()->mainFrame();
    QString js = QString("showAddress(\"%1\", \"%2\");").arg(ipAddress).arg(queryAddress);
    frame->evaluateJavaScript(js);
}

void THGeoIpViewer::lookupIpAddress (void) {
    d->hostIpLookup->lookupAddress(d->ipAddressEdit->text().trimmed());
}

void THGeoIpViewer::ipLookupFinished (bool error) {
    if (error) {
        QMessageBox::warning(this, tr("Geo IP Location"),
                             d->hostIpLookup->errorString());
    } else {
        QString location = d->hostIpLookup->location();
        QString country = d->hostIpLookup->countryName();

        if (location.startsWith('(') && country.startsWith('(')) {
            QMessageBox::warning(this, tr("Geo IP Location"),
                                 tr("Ip Location Not Found"));
        } else if (location.startsWith('(')) {
            loadMap(d->hostIpLookup->ipAddress(), country);
        } else if (country.startsWith('(')) {
            loadMap(d->hostIpLookup->ipAddress(), location);
        } else {
            QString query = QString("%1 %2").arg(location).arg(country);
            loadMap(d->hostIpLookup->ipAddress(), query);
        }
    }
}

