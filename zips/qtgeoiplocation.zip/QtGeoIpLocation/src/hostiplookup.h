#ifndef _HOSTIPLOOKUP_H_
#define _HOSTIPLOOKUP_H_

#include <QObject>
#include <QPointF>
class QNetworkReply;
class THHostIpLookupPrivate;

class THHostIpLookup : public QObject {
    Q_OBJECT

    public:
        THHostIpLookup (QObject *parent = 0);
        ~THHostIpLookup();

        QString location (void) const;
        QString ipAddress (void) const;
        QString countryName (void) const;
        QPointF coordinates (void) const;

        QString errorString (void) const;

    Q_SIGNALS:
        void finished (bool error);

    public Q_SLOTS:
        void lookupAddress (const QString& ipAddress);

    private Q_SLOTS:
        void responseReceived (QNetworkReply *reply);

    private:
        THHostIpLookupPrivate *d;
};

#endif /* !_HOSTIPLOOKUP_H_ */

