#include <QNetworkAccessManager>
#include <QXmlStreamReader>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QStringList>
#include <QUrl>

#include "hostiplookup.h"

class THHostIpLookupPrivate {
    public:
        QNetworkAccessManager networkManager;
        QString errorString;

        QPointF coordinates;
        QString countryName;
        QString ipAddress;
        QString location;

    public:
        void reset (void);
};

void THHostIpLookupPrivate::reset (void) {
    coordinates = QPointF();
    errorString.clear();
    countryName.clear();
    location.clear();
}

THHostIpLookup::THHostIpLookup (QObject *parent)
    : QObject(parent), d(new THHostIpLookupPrivate)
{
    connect(&(d->networkManager), SIGNAL(finished(QNetworkReply *)),
            SLOT(responseReceived(QNetworkReply *)));
}

THHostIpLookup::~THHostIpLookup() {
    delete d;
}

QString THHostIpLookup::location (void) const {
    return(d->location);
}

QString THHostIpLookup::ipAddress (void) const {
    return(d->ipAddress);
}

QString THHostIpLookup::countryName (void) const {
    return(d->countryName);
}

QPointF THHostIpLookup::coordinates (void) const {
    return(d->coordinates);
}

QString THHostIpLookup::errorString (void) const {
    return(d->errorString);
}

void THHostIpLookup::lookupAddress (const QString& ipAddress) {
    QUrl url("http://api.hostip.info/");
    url.addQueryItem("ip", ipAddress.toLatin1());

    d->ipAddress = ipAddress;
    d->networkManager.get(QNetworkRequest(url));
}

void THHostIpLookup::responseReceived (QNetworkReply *reply) {
    d->reset();
    if (reply->error()) {
        d->errorString = reply->errorString();
        emit finished(true);
    } else {        
        QXmlStreamReader xmlReader(reply->readAll());
        while (!xmlReader.atEnd()) {
            xmlReader.readNext();

            QStringRef name = xmlReader.qualifiedName();
            if (name == "gml:name") {
                d->location = xmlReader.readElementText();
            } else if (name == "countryName") {
                d->countryName = xmlReader.readElementText();
            } else if (name == "coordinates") {
                QStringList coord = xmlReader.readElementText().split(',',
                                                    QString::SkipEmptyParts);
                if (coord.size() >= 2) {
                    d->coordinates.setX(coord[0].toDouble());
                    d->coordinates.setY(coord[1].toDouble());
                }
            }
        }
        emit finished(false);
    }
}

