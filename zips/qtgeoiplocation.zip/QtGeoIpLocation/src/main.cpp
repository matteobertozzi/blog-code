#include <QApplication>

#include "geoipviewer.h"

int main (int argc, char **argv) {
    QApplication app(argc, argv);

    THGeoIpViewer w;
    w.resize(350, 420);
    w.show();

    return(app.exec());
}

