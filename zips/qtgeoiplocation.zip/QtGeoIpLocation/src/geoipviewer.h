#ifndef _GEOIPVIEWER_H_
#define _GEOIPVIEWER_H_

#include <QWidget>
class THGeoIpViewerPrivate;

class THGeoIpViewer : public QWidget {
    Q_OBJECT

    public:
        THGeoIpViewer (QWidget *parent = 0);
        ~THGeoIpViewer();

        void loadMap (const QString& ipAddress, const QString& queryAddress);

    private Q_SLOTS:
        void lookupIpAddress (void);
        void ipLookupFinished (bool error);

    private:
        THGeoIpViewerPrivate *d;
};

#endif /* !_GEOIPVIEWER_H_ */

