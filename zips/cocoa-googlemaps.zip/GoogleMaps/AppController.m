//
//  AppController.m
//  GoogleMaps
//
//  Created by Matteo Bertozzi on 1/25/09.
//  Copyright 2009 Matteo Bertozzi. All rights reserved.
//

#import "AppController.h"


@implementation AppController

- (void)awakeFromNib {
	NSFileManager *fileManager = [NSFileManager defaultManager];
	NSString *path = [[NSBundle mainBundle] pathForResource:@"GoogleMap" ofType:@"html"];
	NSData *data = [fileManager contentsAtPath:path];
	NSString *htmlString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
	[[webView mainFrame] loadHTMLString:htmlString baseURL:nil];
}

- (void)webView:(WebView *)sender runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WebFrame *)frame 
{
}


- (IBAction)zoomIn:(id)sender {
	[[webView windowScriptObject] callWebScriptMethod:@"zoomIn" withArguments:nil];
}

- (IBAction)zoomOut:(id)sender {
	[[webView windowScriptObject] callWebScriptMethod:@"zoomOut" withArguments:nil];
}

- (IBAction)switchView:(id)sender {
	switch ([sender selectedSegment]) {
		case 0:
			[[webView windowScriptObject] callWebScriptMethod:@"switchToTerrainMap" withArguments:nil];
			break;
		case 1:
			[[webView windowScriptObject] callWebScriptMethod:@"switchToSatelliteMap" withArguments:nil];
			break;
		case 2:
			[[webView windowScriptObject] callWebScriptMethod:@"switchToHybridMap" withArguments:nil];
			break;
	}
}

- (IBAction)loadAddress:(id)sender {
	NSArray *args = [NSArray arrayWithObjects:[addressField stringValue], nil];
	[[webView windowScriptObject] callWebScriptMethod:@"showAddress" withArguments:args];	
}

@end
