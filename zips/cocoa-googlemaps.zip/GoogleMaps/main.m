//
//  main.m
//  GoogleMaps
//
//  Created by Matteo Bertozzi on 1/25/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
