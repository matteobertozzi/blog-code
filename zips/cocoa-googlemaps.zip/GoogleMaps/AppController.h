//
//  AppController.h
//  GoogleMaps
//
//  Created by Matteo Bertozzi on 1/25/09.
//  Copyright 2009 Matteo Bertozzi. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <WebKit/WebKit.h>

@interface AppController : NSObject {
	IBOutlet NSTextField *addressField;
	IBOutlet WebView *webView;
}

- (IBAction)zoomIn:(id)sender;
- (IBAction)zoomOut:(id)sender;
- (IBAction)switchView:(id)sender;
- (IBAction)loadAddress:(id)sender;

@end
