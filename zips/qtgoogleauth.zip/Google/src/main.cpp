#include <QCoreApplication>
#include <QDebug>

#include "googleauth.h"

int main (int argc, char **argv) {
	QCoreApplication app(argc, argv);

	QEventLoop q;
	THGoogleAuth gAuth("MYNAME@gmail.com");
	QObject::connect(&gAuth, SIGNAL(authenticated()), &q, SLOT(quit()));
	gAuth.login(THGoogleAuth::Contacts, "MYPASSWORD");
	q.exec();

	if (gAuth.error() == THGoogleAuth::NoError) {
		qDebug() << "SID" << gAuth.sid();
		qDebug() << "LSID" << gAuth.lsid();
		qDebug() << "AUTH" << gAuth.auth();
	} else {
		qDebug() << gAuth.errorString();
	}

	return(0);
}

