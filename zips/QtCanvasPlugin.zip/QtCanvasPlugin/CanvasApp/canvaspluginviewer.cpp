/* 
 * Copyright (C) 2009 Matteo Bertozzi.
 *
 * This file is part of THLibrary.
 * 
 * THLibrary is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * THLibrary is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with THLibrary.  If not, see <http://www.gnu.org/licenses/>.
 */
 
#include <QResizeEvent>
#include <QPaintEvent>
#include <QMouseEvent>
#include <QPainter>

#include "canvaspluginviewer.h"
#include "canvasplugin.h"

class THCanvasPluginViewerPrivate {
    public:
        THCanvasPlugin *plugin;
        QImage canvasArea;
};

THCanvasPluginViewer::THCanvasPluginViewer (QWidget *parent) 
    : QWidget(parent), d(new THCanvasPluginViewerPrivate)
{
    d->plugin = NULL;
}

THCanvasPluginViewer::~THCanvasPluginViewer() {
    delete d;
}

THCanvasPlugin *THCanvasPluginViewer::plugin (void) const {
    return(d->plugin);
}

void THCanvasPluginViewer::setPlugin (THCanvasPlugin *plugin) {
    if (d->plugin != NULL) {
        disconnect(d->plugin, SIGNAL(paintEvent(const QImage&)), 
                   this, SLOT(repaintCanvas(const QImage&)));
    }

    d->plugin = plugin;
    if (d->plugin != NULL) {  
        connect(d->plugin, SIGNAL(paintEvent(const QImage&)),
                this, SLOT(repaintCanvas(const QImage&)));
    }
}


void THCanvasPluginViewer::paintEvent (QPaintEvent *event) {
    if (d->canvasArea.isNull()) {
        QWidget::paintEvent(event);
    } else {
        QPainter p(this);
        p.drawImage(0, 0, d->canvasArea);
        p.end();
    }
}

void THCanvasPluginViewer::resizeEvent (QResizeEvent *event) {
    if (d->plugin != NULL)
        d->plugin->resizeEvent(event->size());
}

void THCanvasPluginViewer::mouseReleaseEvent (QMouseEvent *event) {
    if (d->plugin != NULL)
        d->plugin->mouseEvent(event->pos(), THCanvasPlugin::MouseClick);
}

void THCanvasPluginViewer::mouseMoveEvent (QMouseEvent *event) {
    if (d->plugin != NULL)
        d->plugin->mouseEvent(event->pos(), THCanvasPlugin::MouseMove);
}

void THCanvasPluginViewer::mouseDoubleClickEvent (QMouseEvent *event) {
    if (d->plugin != NULL)
        d->plugin->mouseEvent(event->pos(), THCanvasPlugin::MouseDoubleClick);
}

void THCanvasPluginViewer::repaintCanvas (const QImage& canvasArea) {
    d->canvasArea = canvasArea;
    update();
}

