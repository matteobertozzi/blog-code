#include <QApplication>
#include <QVBoxLayout>
#include <QLibrary>
#include <QLabel>

#include <iostream>

#include "canvaspluginviewer.h"
#include "canvasplugin.h"

typedef THCanvasPlugin *(*LoadPluginFunction) (QObject *parent);
typedef void (*UnloadPluginFunction) (void);

int main (int argc, char **argv) {
    QApplication app(argc, argv);

    if (argc < 2) {
        std::cout << "Usage: CanvasApp <plugin lib>" << std::endl;
        std::cout << "Example: CanvasApp ../CanvasPlugin/libCanvasPlugin.so" << std::endl;
        return(1);
    }

    QLibrary pluginLib(argv[1]);
    if (!pluginLib.load()) {
        std::cout << "Load Plugin Failed: " 
                  << qPrintable(pluginLib.errorString()) 
                  << std::endl;
        return(1);
    }

    // Load Plugin
    LoadPluginFunction loadPlugin = (LoadPluginFunction)
                                     pluginLib.resolve("canvas_plugin_load");
    if (loadPlugin == NULL) {
        std::cout << "Load Plugin Function Not Found" << std::endl;
        return(1);
    }    

    THCanvasPlugin *plugin = loadPlugin(NULL);
    plugin->initialize();

    // Setup Canvas Plugin Viewer
    THCanvasPluginViewer *pluginViewer = new THCanvasPluginViewer;
    pluginViewer->setPlugin(plugin);

    QLabel *label = new QLabel("Hey, Canvas above is not Mine!");
    label->setAlignment(Qt::AlignCenter);

    // Setup Window Widget
    QWidget window;
    window.setWindowTitle("Canvas Plugin Test");
    QVBoxLayout *layout = new QVBoxLayout;
    window.setLayout(layout);
    layout->addWidget(pluginViewer, 1);
    layout->addWidget(label);
    window.setMinimumSize(150, 150);
    window.resize(500, 320);
    window.show();
    app.exec();

    plugin->uninitialize();

    // Unload Plugin
    UnloadPluginFunction unloadPlugin = (UnloadPluginFunction)
                                      pluginLib.resolve("canvas_plugin_unload");
    if (unloadPlugin == NULL) {
        std::cout << "UnLoad Plugin Function Not Found" << std::endl;
        return(1);
    }

    unloadPlugin();

    return(0);
}

