/* 
 * Copyright (C) 2009 Matteo Bertozzi.
 *
 * This file is part of THLibrary.
 * 
 * THLibrary is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * THLibrary is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with THLibrary.  If not, see <http://www.gnu.org/licenses/>.
 */
 
#ifndef _THCANVASPLUGINVIEWER_H_
#define _THCANVASPLUGINVIEWER_H_

#include <QWidget>
class THCanvasPluginViewerPrivate;
class THCanvasPlugin;

class THCanvasPluginViewer : public QWidget {
    Q_OBJECT

    public:
        THCanvasPluginViewer (QWidget *parent = 0);
        ~THCanvasPluginViewer();

        THCanvasPlugin *plugin (void) const;
        void setPlugin (THCanvasPlugin *plugin);

    protected:
        void paintEvent (QPaintEvent *event);
        void resizeEvent (QResizeEvent *event);
        void mouseReleaseEvent (QMouseEvent *event);
        void mouseMoveEvent (QMouseEvent *event);
        void mouseDoubleClickEvent (QMouseEvent *event);

    private Q_SLOTS:
        void repaintCanvas (const QImage& canvasArea);

    private:
        THCanvasPluginViewerPrivate *d;
};

#endif /* !_THCANVASPLUGINVIEWER_H_ */

