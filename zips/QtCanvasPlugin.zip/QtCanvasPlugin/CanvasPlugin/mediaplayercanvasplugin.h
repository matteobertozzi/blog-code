/* 
 * Copyright (C) 2009 Matteo Bertozzi.
 *
 * This file is part of THLibrary.
 * 
 * THLibrary is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * THLibrary is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with THLibrary.  If not, see <http://www.gnu.org/licenses/>.
 */
 
#ifndef _THMEDIAPLAYER_CANVASPLUGIN_H_
#define _THMEDIAPLAYER_CANVASPLUGIN_H_

#include "canvasplugin.h"
class THMediaPlayerCanvasPluginPrivate;

class THMediaPlayerCanvasPlugin : public THCanvasPlugin {
    Q_OBJECT

    public:
        THMediaPlayerCanvasPlugin (QObject *parent = 0);
        ~THMediaPlayerCanvasPlugin();

        void initialize (void);
        void uninitialize (void);

        void resizeEvent (const QSize& newSize);
        void mouseEvent (const QPoint& location, MouseEvent event);

    private Q_SLOTS:
        void render (void);

    private:
        THMediaPlayerCanvasPluginPrivate *d;
};

#endif /* !_THMEDIAPLAYER_CANVASPLUGIN_H_ */

