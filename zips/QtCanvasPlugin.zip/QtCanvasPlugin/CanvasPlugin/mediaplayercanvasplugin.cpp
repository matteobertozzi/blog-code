/* 
 * Copyright (C) 2009 Matteo Bertozzi.
 *
 * This file is part of THLibrary.
 * 
 * THLibrary is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * THLibrary is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with THLibrary.  If not, see <http://www.gnu.org/licenses/>.
 */
 
#include <QPainter>
#include <QImage>
#include <QTimer>
#include <QSize>

#include "mediaplayercanvasplugin.h"

#define TIMEOUT             100
#define SQUARE_SIZE         40
#define SQUARE_XSTEP         4

#define CONTROLS_HEIGHT     100
#define CONTROLS_RECT(size) QRect(10, (size).height() - CONTROLS_HEIGHT + 10, \
                                   60, CONTROLS_HEIGHT - 20)

class THMediaPlayerCanvasPluginPrivate {
    public:
        bool isPlaying;
        QTimer *timer;
        QSize size;
        int x, y;
};

THMediaPlayerCanvasPlugin::THMediaPlayerCanvasPlugin (QObject *parent)
    : THCanvasPlugin(parent)
{
    d = NULL;
}

THMediaPlayerCanvasPlugin::~THMediaPlayerCanvasPlugin() {
    if (d != NULL) uninitialize();
}

void THMediaPlayerCanvasPlugin::initialize (void) {
    d = new THMediaPlayerCanvasPluginPrivate;

    // Initialize Canvas Vals
    d->x = d->y = 0;
    d->isPlaying = true;

    // Initialize Timer
    d->timer = new QTimer(this);
    connect(d->timer, SIGNAL(timeout()), this, SLOT(render()));
    d->timer->start(TIMEOUT);
}

void THMediaPlayerCanvasPlugin::uninitialize (void) {
    if (d != NULL) {
        d->timer->stop();
        d->timer->deleteLater();

        delete d;
        d = NULL;
    }
}

void THMediaPlayerCanvasPlugin::resizeEvent (const QSize& newSize) {
    d->size = newSize;
    render();
}

/* Handle Start/Stop Button on Canvas */
void THMediaPlayerCanvasPlugin::mouseEvent (const QPoint& location,
                                            MouseEvent event) 
{
    if (event == MouseClick && CONTROLS_RECT(d->size).contains(location)) {
        d->isPlaying = !d->isPlaying;
        render();

        if (d->isPlaying)
            d->timer->start();
        else
            d->timer->stop();
    }
}

/* Render the Canvas Image, and send the paintEvent Signal */
void THMediaPlayerCanvasPlugin::render (void) {
    if (d->size.isEmpty())
        return;

    QImage image(d->size, QImage::Format_RGB32);

    QPainter p(&image);
    p.fillRect(QRect(QPoint(0, 0), d->size), Qt::black);
    p.fillRect(d->x, d->y, SQUARE_SIZE, SQUARE_SIZE, Qt::red);

    p.setPen(Qt::lightGray);
    p.drawRect(CONTROLS_RECT(d->size));
    p.drawText(CONTROLS_RECT(d->size), Qt::AlignCenter, 
               d->isPlaying ? "Stop" : "Start");

    p.end();

    if (d->isPlaying)
        d->x += SQUARE_XSTEP;

    if ((d->x + SQUARE_SIZE) >= d->size.width()) {
        d->x = 0;
        d->y += SQUARE_SIZE;
    }

    if ((d->y + SQUARE_SIZE) >= d->size.height() - CONTROLS_HEIGHT)
        d->x = d->y = 0;

    emit paintEvent(image);
}

