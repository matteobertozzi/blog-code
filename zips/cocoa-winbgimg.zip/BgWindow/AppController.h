//
//  AppController.h
//  BgWindow
//
//  Created by Matteo Bertozzi on 10/25/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import "BackgroundImageView.h"

@interface AppController : NSObject {
	IBOutlet BackgroundImageView *_baseView;
	IBOutlet NSTextView *_textView;
}

@end
