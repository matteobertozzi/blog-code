#import "BackgroundImageView.h"

@implementation BackgroundImageView

- (void) dealloc {
	[self clearBackground];
	[super dealloc];
}

#pragma mark -
#pragma mark Reset Methods

- (void) clearBackground {
	if (_image != nil)
		[_image release], _image = nil;

	if (_patternColor != nil)
		[_patternColor release], _patternColor = nil;

	_imageAlpha = 1.0;
	_alpha = 1.0;
}

#pragma mark -
#pragma mark Setup Methods

- (void) setBackgroundAlpha: (float) alpha {
	_alpha = (alpha > 0.0) ? alpha : 0.01;
}

- (void) setBackgroundPattern: (NSImage *) image {
	if (_patternColor != nil)
		[_patternColor release], _patternColor = nil;

	if (image != nil)
		_patternColor = [[NSColor colorWithPatternImage:image] retain];
}

- (void) setBackgroundImage: (NSImage *) image {
	[self setBackgroundImage:image withAlpha:1.0];
}

- (void) setBackgroundImage: (NSImage *) image withAlpha: (float) alpha {
	if (_image != nil)
		[_image release], _image = nil;

	if (image != nil)
		_image = [image retain];

	_imageAlpha = (alpha > 0.0) ? alpha : 0.01;
}

#pragma mark -
#pragma mark Drawing Routines

- (void) drawRect: (NSRect) dirtyRect {
	NSBezierPath *path = [NSBezierPath bezierPathWithRect:[self bounds]];
	[self drawPattern:path];
	[self drawImage:path];
}

- (void) drawPattern: (NSBezierPath *) path {
	if (_patternColor == nil)
		return;

	if (_alpha == 1.0) {
		[[NSGraphicsContext currentContext] saveGraphicsState];

		[[NSGraphicsContext currentContext] 
					setPatternPhase:NSMakePoint(0, [self frame].size.height)];

		[_patternColor set];
		[path fill];

		[[NSGraphicsContext currentContext] restoreGraphicsState];
	} else {
		NSImage *patternImg = [[NSImage alloc] initWithSize:[self bounds].size];
		[patternImg lockFocus];

		[[NSGraphicsContext currentContext] 
					setPatternPhase:NSMakePoint(0, [self frame].size.height)];

		[_patternColor set];
		NSRectFill([self bounds]);

		[patternImg unlockFocus];

		[self drawImage:patternImg withAlpha:_alpha clippingPath:path];
	}
}

- (void) drawImage: (NSBezierPath *) path {
	if (_image != nil)
		[self drawImage:_image withAlpha:_imageAlpha clippingPath: path];
}

- (void) drawImage: (NSImage *) image 
		 withAlpha: (float) alpha
		 clippingPath: (NSBezierPath *) path
{
	NSImage *foregroundImage;

	if (NSEqualSizes([image size], [path bounds].size)) {
		foregroundImage = image;
	} else {
		foregroundImage = [[[NSImage alloc] initWithSize:[self bounds].size] autorelease];

		NSPoint backgroundCenter;
		backgroundCenter.x = [foregroundImage size].width / 2;
		backgroundCenter.y = [foregroundImage size].width / 2;

		NSPoint drawPoint = backgroundCenter;
		drawPoint.x = [image size].width / 2;
		drawPoint.y = [image size].height / 2;

		[foregroundImage lockFocus];
		[image compositeToPoint: drawPoint operation:NSCompositeSourceOver];
		[foregroundImage unlockFocus];
	}

	NSImage *clipImage = [[NSImage alloc] initWithSize:[self bounds].size];
	[clipImage lockFocus];

	[[NSColor blackColor] set];
	[path fill];

	[foregroundImage compositeToPoint:[self bounds].origin operation:NSCompositeSourceIn];

	[clipImage unlockFocus];

	[clipImage compositeToPoint:[self bounds].origin 
					operation:NSCompositeSourceOver 
					fraction:alpha];
}

@end
