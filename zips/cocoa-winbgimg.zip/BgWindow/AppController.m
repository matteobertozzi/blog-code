//
//  AppController.m
//  BgWindow
//
//  Created by Matteo Bertozzi on 10/25/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "AppController.h"


@implementation AppController

- (void) awakeFromNib {
	[_baseView setBackgroundPattern:[NSImage imageNamed:@"note"]];
	
	[_textView setFont:[NSFont fontWithName:@"Marker Felt" size:15]];
}

@end
