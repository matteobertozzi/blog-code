#import <Cocoa/Cocoa.h>

@interface BackgroundImageView : NSView {
	NSColor *_patternColor;
	float _imageAlpha;
	NSImage *_image;
	float _alpha;
}

- (void) clearBackground;

- (void) setBackgroundAlpha: (float) alpha;
- (void) setBackgroundPattern:(NSImage *) image;
- (void) setBackgroundImage: (NSImage *) image;
- (void) setBackgroundImage: (NSImage *) image withAlpha: (float) alpha;

- (void) drawRect: (NSRect) dirtyRect;
- (void) drawPattern: (NSBezierPath *) path;
- (void) drawImage: (NSBezierPath *) path;
- (void) drawImage: (NSImage *) image 
		 withAlpha: (float) alpha
		 clippingPath: (NSBezierPath *) path;

@end

