#!/usr/bin/env python

import os

if __name__ == '__main__':
	print "Content-Type: text/html"
	print

	print "<html>"
	print "<head><title>Hello Python</title></head>"
	print "<body>"
	print "<h1>Hello Python</h1>"
	print "<p><b>Request Method</b>: ", os.environ['REQUEST_METHOD']
	print "<p><b>Query String</b>: ", os.environ['QUERY_STRING']
	print "</body>"
	print "<html>"

