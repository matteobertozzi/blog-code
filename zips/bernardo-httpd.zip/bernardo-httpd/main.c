/* 
 * Copyright (C) 2009 Matteo Bertozzi.
 *
 * Bernardo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Bernardo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Bernardo.  If not, see <http://www.gnu.org/licenses/>.
 */


#define _GNU_SOURCE
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#define BUFFER_SIZE		8192
#define ARGN_DIR		1
#define ARGN_PORT		2

static void write_internal_server_error (int fd) {
	char buffer[64];
	time_t t;

	t = time(NULL);

	snprintf(buffer, 64, "HTTP/1.1 500 Internal Server Error\r\n");
	write(fd, buffer, strlen(buffer));

	snprintf(buffer, 64, "Date: %s", ctime(&t));
	write(fd, buffer, strlen(buffer));

	snprintf(buffer, 64, "Content-Type: text/xml\r\n\r\n");
	write(fd, buffer, strlen(buffer));

	snprintf(buffer, 64, "<error>The Server is Busy, try later</error>\r\n");
	write(fd, buffer, strlen(buffer));
}

static void client_serve (int socket) {
	char buffer[BUFFER_SIZE];
	char path[BUFFER_SIZE];
	int content_length = 0;
	struct stat statbuf;
	int is_post_data = 0;
	ssize_t n;

	while ((n = read(socket, buffer, (BUFFER_SIZE - 1))) > 0) {
		char *token;

		buffer[n] = '\0';
		token = strtok(buffer, "\n");
		while (token != NULL) {
			if (token[0] == '\r') {
				if (content_length == 0)
					goto exec_request;				

				is_post_data = 1;
			} 

			buffer[strlen(buffer) - 1] = '\0';
			if (strcasestr(token, "GET") || strcasestr(token, "POST")) {
				char *saveptr = NULL;
				char *query;

				// Request Method: (GET/POST)
				token = strtok_r(token, " ", &saveptr);
				setenv("REQUEST_METHOD", token, 1);

				// Request URI
				token = strtok_r(NULL, " ", &saveptr);
				setenv("REQUEST_URI", token, 1);

				// Query String
				memset(path, 0, BUFFER_SIZE);
				query = strstr(token, "?");
				if (query == NULL)
					strcpy(path, token);
				else
					strncpy(path, token, query - token);
				setenv("QUERY_STRING", (query != NULL) ? query + 1 : "", 1);
			} else if (strcasestr(token, "Content-Length")) {
				char lenbuf[128];
				content_length = atoi(strstr(token, ":") + 1);
				snprintf(lenbuf, 128, "%d", content_length);
				setenv("CONTENT_LENGTH", lenbuf, 1);
				printf("CONTENT_LEN: %s\n", lenbuf);
			} else if (strcasestr(token, "Content-Type")) {
				setenv("CONTENT_TYPE", strstr(token, ":") + 1, 1);
			} else if (strcasestr(token, "User-Agent")) {
				setenv("HTTP_USER_AGENT", strstr(token, ":") + 1, 1);
			} else if (is_post_data) {
				setenv("HTTP_RAW_POST_DATA", token, 1);
				goto exec_request;
			}

			token = strtok(NULL, "\n");
		}
	}
exec_request:
	// Socket -> Stdout
	dup2(socket, 1);
	close(socket);

	time_t t = time(NULL);
	if (stat(path + 1, &statbuf) != 0 || S_ISDIR(statbuf.st_mode)) {
		printf("HTTP/1.1 404 Not Found\r\n");
		printf("Date: %s", ctime(&t));
		printf("Content-Type: text/xml\r\n\r\n");
		printf("<error>Page '%s' Not Found</error>\r\n", path);
	} else {
		memset(buffer, 0, BUFFER_SIZE);
		getcwd(buffer, BUFFER_SIZE);	
		strcat(buffer, path);

		printf("HTTP/1.1 200 OK\r\n");
		printf("Date: %s", ctime(&t));
		printf("Server: Bernardo HTTPD\r\n");
		if (!statbuf.st_mode & S_IXUSR)
			printf("Content-Length: %lu\r\n", statbuf.st_size);
		fflush(stdout);

		if (statbuf.st_mode & S_IXUSR) {
			setenv("SERVER_SOFTWARE", "Bernardo HTTPD", 1);
			setenv("SERVER_NAME", "localhost", 1);
			setenv("SERVER_ADDR", "127.0.0.1", 1);
			setenv("GATEWAY_INTERFACE", "CGI/1.1", 1);
			setenv("SERVER_PROTOCOL", "HTTP/1.1", 1);
			setenv("SCRIPT_FILENAME", path, 1);
			setenv("SCRIPT_NAME", path, 1);
			setenv("PHP_SELF", path, 1);

			execl(buffer, buffer, NULL); 
		} else {
			execl("/bin/cat", "cat", buffer, NULL);
		}
	}

	exit(0);
}

static int server_listen (int port) {
	struct sockaddr_in srvaddr;
	int sock;

	// Initialize Socket
	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		perror("socket()");
		return(-1);
	}

	// Initialize Server Address
	memset(&srvaddr, 0, sizeof(struct sockaddr_in));
	srvaddr.sin_family = AF_INET;
	srvaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	srvaddr.sin_port = htons(port);

	// Bind Socket
	if (bind(sock, (struct sockaddr *)&srvaddr, sizeof(struct sockaddr_in)) < 0) 
	{
		perror("bind()");
		return(-2);
	}

	// Listen!
	if (listen(sock, 10) < 0) {
		perror("listen()");
		return(-3);
	}

	return(sock);
}

int main (int argc, char **argv) {
	struct sockaddr caddress;
	socklen_t caddrlen;
	int srvsock;
	pid_t pid;
	int fd;

	if (argc < 3) {
		printf("Usage: bernardo-httpd <www dir> <port>\n");
		return(1);
	}

	if (chdir(argv[ARGN_DIR])) {
		printf("Invalid Server Directory: '%s'\n", argv[ARGN_DIR]);
		return(1);
	}

	if ((srvsock = server_listen(atoi(argv[ARGN_PORT]))) < 0)
		return(1);

_server_loop:
	if ((fd = accept(srvsock, (struct sockaddr *)&caddress, &caddrlen)) < 0) {
		perror("accept()");
		close(srvsock);
		return(-2);
	}

	if ((pid = fork()) < 0)
		write_internal_server_error(fd);
	else if (pid == 0)
		client_serve(fd);

	close(fd);

	goto _server_loop;

	return(0);
}

