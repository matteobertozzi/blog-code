#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <ctype.h>
#include <stdio.h>

#include "gldatareader.h"

static char *_glDataReaderTrim (char *s) {
    size_t len = strlen(s);
    size_t lws;

    while (len && isspace(s[len - 1]))
        --len;

    if (len) {
        lws = strspn(s, " \t\n\r\v");
        len -= lws;
        memmove(s, s + lws, len);
    }

    s[len] = '\0';
    return(len == 0 ? NULL : s);
}

static GLDataBool _glDataReaderEndsWith (const char *s, const char *suffix) {
    size_t l1 = strlen(s);
    size_t l2 = strlen(suffix);
    return(l1 < l2 ? GLDATA_FALSE : !strcmp(s + l1 - l2, suffix));
}

#define USE_LIB_PNG
#ifdef USE_LIB_PNG

#include <png.h>

static GLDataBool __imagePngLoad (GLDataImage *image) {
    GLDataBool success = GLDATA_FALSE;
    png_uint_32 i, width, height;
    png_bytepp row_pointers;
    unsigned int row_bytes;
    unsigned char sig[8];
    png_structp png;
    png_infop info;
    int bit_depth;
    char *blob;
    int color;
    FILE *fh;

    if ((fh = fopen(image->name, "rb")) == NULL)
        return(GLDATA_FALSE);

    /* Check for the 8-byte signature */
    if (fread(sig, sizeof(unsigned char), 8, fh) != 8)
        goto _load_png_end_early;

    if (!png_check_sig(sig, 8))
        goto _load_png_end_early;

    /* Set up the PNG structs */
    if (!(png = png_create_read_struct(PNG_LIBPNG_VER_STRING, 0, 0, 0)))
        goto _load_png_end_early;

    if (!(info = png_create_info_struct(png))) {      
        png_destroy_read_struct(&png, NULL, NULL);
        goto _load_png_end_early;
    }

    if (setjmp(png_jmpbuf(png)))
        goto _load_png_end;

    png_init_io(png, fh);
    png_set_sig_bytes(png, 8);
    png_read_info(png, info);
    png_get_IHDR(png, info, &width, &height, &bit_depth, &color, 0, 0, 0);

    if (color & PNG_COLOR_MASK_ALPHA)
        png_set_strip_alpha(png);

    if (bit_depth > 8)
        png_set_strip_16(png);

    if (color == PNG_COLOR_TYPE_GRAY || color == PNG_COLOR_TYPE_GRAY_ALPHA)
        png_set_gray_to_rgb(png);
    else if (color == PNG_COLOR_TYPE_PALETTE)
        png_set_palette_to_rgb(png);

    png_read_update_info(png, info);

    /* Read Size, and Allocate Image Blob */
    row_bytes = png_get_rowbytes(png, info);
    if ((blob = (char *) malloc(row_bytes * height)) == NULL)
        goto _load_png_end;    

    /* Setup Row Pointers */
    if (!(row_pointers = (png_bytepp) malloc(height * sizeof(png_bytepp)))) {
        free(blob);
        goto _load_png_end;    
    }

    for (i = 0; i < height; ++i)
        row_pointers[height - 1 - i] = blob + i * row_bytes;

    /* Read the whole image */
    png_read_image(png, row_pointers);

    free(row_pointers);

    success = GLDATA_TRUE;
    glDataImageSetSize(image, width, height);
    glDataImageSetData(image, blob);

_load_png_end:
    png_destroy_read_struct(&png, &info, NULL);

_load_png_end_early:
    fclose(fh);
    return(success);    
}

#endif /* USE_LIB_PNG */

static GLDataBool __imageBmpLoad (GLDataImage *image) {
    GLDataBool success = GLDATA_FALSE;
    uint32_t width, height;
    uint16_t planes, bpp;
    unsigned int i, size;
    char color;
    char *blob;
    FILE *fh;

    if ((fh = fopen(image->name, "rb")) == NULL)
        return(GLDATA_FALSE);

    /* Seek through the bmp header, up to the width/height */
    fseek(fh, 18, SEEK_CUR);

    /* Read Width */
    if (fread(&width, sizeof(uint32_t), 1, fh) != 1)
        goto _load_bmp_end;

    /* Read Height */
    if (fread(&height, sizeof(uint32_t), 1, fh) != 1)
        goto _load_bmp_end;

    /* Read the planes, must be 1 */
    if (fread(&planes, sizeof(uint16_t), 1, fh) != 1)
        goto _load_bmp_end;

    if (planes != 1)
        goto _load_bmp_end;

    /* Read the bpp, must be 24 */
    if (fread(&bpp, sizeof(uint16_t), 1, fh) != 1)
        goto _load_bmp_end;

    if (bpp != 24)
        goto _load_bmp_end;

    /* Skip the Rest of the Bitmap Header */
    fseek(fh, 24, SEEK_CUR);

    /* Alloc Image Blob */
    size = (width * height * 3);
    if ((blob = (char *) malloc(size)) == NULL)
        goto _load_bmp_end;

    /* Read Image Blob */
    if (fread(blob, size, 1, fh) != 1) {
        free(blob);
        goto _load_bmp_end;
    }

    /* Reverse all the colors. (BGR -> RGB) */
    for (i = 0; i < size; i += 3) {
        color = blob[i];
        blob[i] = blob[i + 2];
        blob[i + 2] = color;
    }

    success = GLDATA_TRUE;
    glDataImageSetSize(image, width, height);
    glDataImageSetData(image, blob);

_load_bmp_end:
    fclose(fh);
    return(success);
}

static GLDataBool _glDataImageLoad (GLDataImage *image) {
#ifdef USE_LIB_PNG
    if (_glDataReaderEndsWith(image->name, ".png"))
        return(__imagePngLoad(image));
    else 
#endif /* USE_LIB_PNG */
    if (_glDataReaderEndsWith(image->name, ".bmp"))
        return(__imageBmpLoad(image));
    return(GLDATA_FALSE);
}

/* ===========================================================================
 *  GLData GTS
 */
typedef enum {
    GTS_STATE_READY,
    GTS_STATE_VERTEX,
    GTS_STATE_EDGES,
    GTS_STATE_FACES,
    GTS_STATE_FINISHED
} FormatGtsState;

typedef struct {
    GLDataUInt nvertexes;
    GLDataUInt nedges;
    GLDataUInt nfaces;
} FormatGtsData;

static GLDataBool _glDataReaderGts (GLDataReader *reader,
                                    const char *filename)
{
    return(GLDATA_FALSE);
}

/* ===========================================================================
 *  GLData GLD
 */
typedef enum {
    GLD_STATE_READY,
    GLD_STATE_MESH,
    GLD_STATE_END_MESH,
    GLD_STATE_VERTEXES,
    GLD_STATE_FACES,
    GLD_STATE_TEXTURE_UVS,
    GLD_STATE_TEXTURE_FACES,
    GLD_STATE_TEXTURE_IMAGES
} FormatGldState;

typedef struct {
    GLDataList *texture_faces;
    GLDataList *texture_uvs;
    GLDataList *vertexes;
    GLDataList *faces;

    GLDataMesh *mesh;
} FormatGldData;

static GLDataBool _glDataReaderGldReadFace (const char *buffer,
                                            GLDataList *face_list)
{
    GLDataUInt idxs[4];
    GLDataFace *face;
    int i, n;

    n = sscanf(buffer, "%u %u %u %u", idxs, idxs+1, idxs+2, idxs+3);

    if (!(face = glDataFaceInit(glDataFaceAlloc(), n)))
        return(GLDATA_FALSE);

    for (i = 0; i < n; ++i)
        glDataFaceSetPoint(face, i, idxs[i]);

    if (!glDataListAppend(face_list, face)) {
        glDataFaceRelease(face);
        return(GLDATA_FALSE);
    }

    return(GLDATA_TRUE);
}

static GLDataBool _glDataReaderGldReadPoint (const char *buffer,
                                             GLDataList *vertex_list)
{
    GLDataFloat x, y, z;
    GLDataPoint *point;

    sscanf(buffer, "%f %f %f", &x, &y, &z);

    if (!(point = glDataPointInit(glDataPointAlloc(), x, y, z)))
        return(GLDATA_FALSE);

    if (!glDataListAppend(vertex_list, point)) {
        glDataPointRelease(point);
        return(GLDATA_FALSE);
    }

    return(GLDATA_TRUE);
}

static GLDataBool _glDataReaderGldReadUv (const char *buffer,
                                          GLDataList *uv_list)
{
    GLDataUVPoint *point;
    GLDataFloat x, y;

    sscanf(buffer, "%f %f", &x, &y);

    if (!(point = glDataUVPointInit(glDataUVPointAlloc(), x, y)))
        return(GLDATA_FALSE);

    if (!glDataListAppend(uv_list, point)) {
        glDataUVPointRelease(point);
        return(GLDATA_FALSE);
    }

    return(GLDATA_TRUE);
}

static GLDataBool _glDataReaderGldMeshSetupTexture (GLDataUInt index,
                                                    void *data, 
                                                    void *userData) 
{
    GLDataUVSurface *textureMap;
    GLDataUVPolygon *polygon;
    FormatGldData *fdata;
    GLDataUInt i;
    void *p;
    
    fdata = ((void **)userData)[0];
    textureMap = ((void **)userData)[1];

    polygon = glDataUVPolygonInit(glDataUVPolygonAlloc(), 
                                  glDataFace(data)->npoints);
    for (i = 0; i < polygon->npoints; ++i) {
        p = glDataListAt(fdata->texture_uvs, glDataFace(data)->points[i]);
        glDataUVPolygonSetPoint(polygon, i, glDataUVPoint(p));
    }

    glDataUVSurfaceSetPolygon(textureMap, index, polygon);
    glDataUVPolygonRelease(polygon);

    return(GLDATA_FALSE);
}

static GLDataBool _glDataReaderGldMeshSetupSurface (GLDataUInt index,
                                                    void *data, 
                                                    void *userData) 
{
    GLDataSurface *surface;
    GLDataPolygon *polygon;
    FormatGldData *fdata;
    GLDataUInt i;
    void *p;

    fdata = ((void **)userData)[0];
    surface = ((void **)userData)[1];

    polygon = glDataPolygonInit(glDataPolygonAlloc(), 
                                glDataFace(data)->npoints);
    for (i = 0; i < polygon->npoints; ++i) {        
        p = glDataListAt(fdata->vertexes, glDataFace(data)->points[i]);
        glDataPolygonSetPoint(polygon, i, glDataPoint(p));
    }

    glDataSurfaceSetPolygon(surface, index, polygon);
    glDataPolygonRelease(polygon);

    return(GLDATA_FALSE);
}

static void _glDataReaderGldMesh (FormatGldData *fdata) {
    GLDataUVSurface *textureMap;
    GLDataSurface *surface;
    void *userData[2];

    userData[0] = fdata;

    /* Setup Texture Map */
    textureMap = glDataUVSurfaceInit(glDataUVSurfaceAlloc(), 
                                     glDataListSize(fdata->texture_faces));
    userData[1] = textureMap;
    glDataListForeach(fdata->texture_faces, 
                      _glDataReaderGldMeshSetupTexture, 
                      userData);

    /* Setup Surface */
    surface = glDataSurfaceInit(glDataSurfaceAlloc(),
                                glDataListSize(fdata->faces));
    userData[1] = surface;
    glDataListForeach(fdata->faces, 
                      _glDataReaderGldMeshSetupSurface, 
                      userData);
    
    glDataMeshSetSurface(fdata->mesh, surface);
    glDataMeshSetTextureMap(fdata->mesh, textureMap);

    glDataSurfaceRelease(surface);
    glDataUVSurfaceRelease(textureMap);
}

GLDataBool _glReaderFindTextureByName (void *data, void *userData) {
    return(!strcmp(glDataImage(data)->name, (const char *)userData));
}

static GLDataBool _glDataReaderGld (GLDataReader *reader,
                                    const char *filename)
{
    FormatGldState state = GLD_STATE_READY;
    GLDataBool success = GLDATA_FALSE;
    FormatGldData fdata;
    char buffer[1024];
    FILE *fh;

    if ((fh = fopen(filename, "r")) == NULL)
        return(GLDATA_FALSE);

    fdata.texture_faces = glDataListAlloc();
    fdata.texture_uvs = glDataListAlloc();
    fdata.vertexes = glDataListAlloc();
    fdata.faces = glDataListAlloc();

    while (fgets(buffer, sizeof(buffer) - 1, fh) != NULL) {
        if (_glDataReaderTrim(buffer) == NULL)
            continue;

        /* Skip Comment */
        if (buffer[0] == '#')
            continue;

        if (!strncmp(buffer, "MESH", 4)) {
            state = GLD_STATE_MESH;
        } else if (!strncmp(buffer, "END-MESH", 8)) {
            state = GLD_STATE_END_MESH;
        } else if (!strncmp(buffer, "VERTEXES", 8)) {
            state = GLD_STATE_VERTEXES;
            continue;
        } else if (!strncmp(buffer, "FACES", 5)) {
            state = GLD_STATE_FACES;
            continue;
        } else if (!strncmp(buffer, "TEXTURE-UVS", 11)) {
            state = GLD_STATE_TEXTURE_UVS;
            continue;
        } else if (!strncmp(buffer, "TEXTURE-FACES", 13)) {
            state = GLD_STATE_TEXTURE_FACES;
            continue;
        } else if (!strncmp(buffer, "TEXTURE-IMAGES", 14)) {
            state = GLD_STATE_TEXTURE_IMAGES;
            continue;
        }

        switch (state) {
            case GLD_STATE_READY: {
                break;
            } case GLD_STATE_MESH: {
                success = GLDATA_FALSE;

                /* Setup New Mesh */
                if (!(fdata.mesh = glDataMeshInit(glDataMeshAlloc())))
                    goto _gld_read_end;

                /* Read Mesh Name */
                sscanf(buffer, "MESH %s", buffer);
                glDataMeshSetName(fdata.mesh, buffer);
                break;
            } case GLD_STATE_END_MESH: {
                _glDataReaderGldMesh(&fdata);
                glDataListAppend(reader->meshes, fdata.mesh);

                glDataListClear(fdata.texture_faces, (GLDataReleaseFunc)glDataFaceRelease);
                glDataListClear(fdata.texture_uvs, (GLDataReleaseFunc)glDataUVPointRelease);
                glDataListClear(fdata.vertexes, (GLDataReleaseFunc)glDataPointRelease);
                glDataListClear(fdata.faces, (GLDataReleaseFunc)glDataFaceRelease);

                success = GLDATA_TRUE;
                break;
            } case GLD_STATE_VERTEXES: {
                if (!_glDataReaderGldReadPoint(buffer, fdata.vertexes))
                    goto _gld_read_end;
                break;
            } case GLD_STATE_FACES: {
                if (!_glDataReaderGldReadFace(buffer, fdata.faces))
                    goto _gld_read_end;
                break;
            } case GLD_STATE_TEXTURE_UVS: {
                if (!_glDataReaderGldReadUv(buffer, fdata.texture_uvs))
                    goto _gld_read_end;
                break;
            } case GLD_STATE_TEXTURE_FACES: {
                if (!_glDataReaderGldReadFace(buffer, fdata.texture_faces))
                    goto _gld_read_end;
                break;
            } case GLD_STATE_TEXTURE_IMAGES: {
                GLDataImage *image;

                /* Check if This Texture was already loaded */
                image = glDataImage(glDataListSearch(reader->textures, 
                                                     _glReaderFindTextureByName,
                                                     buffer));
                if (image == NULL) {
                    image = glDataImageInit(glDataImageAlloc(), buffer);
                    glDataListAppend(reader->textures, image);
                    
                    if (!_glDataImageLoad(image))
                        printf("Warning Texture Load Failed: %s\n", image->name);
                }

                glDataMeshSetTextureImage(fdata.mesh, image);
                break;
            }
        }
    }

_gld_read_end:
    glDataListRelease(fdata.texture_faces);
    glDataListRelease(fdata.texture_uvs);
    glDataListRelease(fdata.vertexes);
    glDataListRelease(fdata.faces);

    fclose(fh);
    return(success);
}

GLDataReader *glDataReaderAlloc (void) {
    GLDataReader *reader;

    if ((reader = (GLDataReader *) malloc(sizeof(GLDataReader))) == NULL)
        return(NULL);

    reader->textures = glDataListAlloc();
    reader->meshes = glDataListAlloc();

    return(reader);
}

void glDataReaderRelease (GLDataReader *reader) {
    if (reader != NULL) {
        glDataListRelease(reader->textures);

        glDataListClear(reader->meshes, (GLDataReleaseFunc)glDataMeshRelease);
        glDataListRelease(reader->meshes);

        free(reader);
    }
}

GLDataBool glDataReaderRead (GLDataReader *reader,
                             const char *filename,
                             GLDataFormat format)
{
    switch (format) {
        case GLDATA_FORMAT_GLD:
            return(_glDataReaderGld(reader, filename));
        case GLDATA_FORMAT_GTS:
            return(_glDataReaderGts(reader, filename));
    }

    return(GLDATA_FALSE);
}

