//
//  AppController.m
//  VBoxScrollView
//
//  Created by Matteo Bertozzi on 11/15/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "AppController.h"
#import "MessageView.h"

@implementation AppController

- (void)awakeFromNib {
	[scrollView setBackgroundColor:[NSColor colorWithCalibratedRed:0.64 green:0.66 blue:0.71 alpha:1.0]];
	
	int i;
	for (i=0; i < 6; ++i) {
		MessageView *field = [[MessageView alloc] initWithFrame:NSMakeRect(0, 0, 250, 80)];
		[vboxView addItem:field];
	}
}

@end
