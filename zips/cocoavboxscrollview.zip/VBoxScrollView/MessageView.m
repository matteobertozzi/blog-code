//
//  MessageView.m
//  VBoxScrollView
//
//  Created by Matteo Bertozzi on 11/15/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "MessageView.h"


@implementation MessageView

- (void)sizeToFit {
	// NOT IMPLEMENTED YET.
}

- (void)drawRect:(NSRect)frameRect {
	NSString *string = [NSString stringWithString:@"Hi, I'm Testing Cocoa Drawing System...\nIt's Really Nice..."];

    [NSGraphicsContext saveGraphicsState];

    /* Draw Shadow */
    NSShadow *shadow = [[NSShadow alloc] init];
    [shadow setShadowColor:[[NSColor blackColor] colorWithAlphaComponent:0.5]];
    [shadow setShadowOffset:NSMakeSize(4.0, -4.0)];
    [shadow setShadowBlurRadius:3.0];
    [shadow set];

    /* Draw Control */
	NSRect myRect = NSMakeRect(80, 10, frameRect.size.width - 120, 60);
    NSBezierPath *path = [NSBezierPath bezierPath];
    [path setLineJoinStyle:NSRoundLineJoinStyle];
    [path appendBezierPathWithRoundedRect:myRect xRadius:8.0 yRadius:8.0];    
	
	[path moveToPoint:NSMakePoint(80, 35)];
	[path lineToPoint:NSMakePoint(65, 45)];
	[path lineToPoint:NSMakePoint(80, 55)];
	
	NSColor *startingColor = [NSColor colorWithCalibratedRed:0.90 green:0.92 blue:0.85 alpha:1.0];
	NSColor *endingColor = [NSColor colorWithCalibratedRed:0.81 green:0.83 blue:0.76 alpha:1.0];
	NSGradient *gradient = [[[NSGradient alloc] initWithStartingColor:startingColor endingColor:endingColor] autorelease];
	[path fill];
	[gradient drawInBezierPath:path angle:90];

    [NSGraphicsContext restoreGraphicsState];

    [shadow release];
	
	NSImage *image = [NSImage imageNamed:NSImageNameUser];
	[image drawInRect:NSMakeRect(15, 10, 50, 50) fromRect:NSZeroRect operation:NSCompositeSourceOver fraction:1.0];
	
	[string drawInRect:NSMakeRect(90, 20, frameRect.size.width - 140, 45) withAttributes:nil];
}

@end
