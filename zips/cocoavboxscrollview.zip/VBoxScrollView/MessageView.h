//
//  MessageView.h
//  VBoxScrollView
//
//  Created by Matteo Bertozzi on 11/15/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface MessageView : NSView {

}

-(void)sizeToFit;

@end
