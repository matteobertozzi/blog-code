//
//  TouchDragHitAppDelegate.m
//  TouchDragHit
//
//  Created by Matteo Bertozzi on 5/1/09.
//  Copyright Matteo Bertozzi 2009. All rights reserved.
//

#import "TouchDragHitAppDelegate.h"
#import "TouchDragHitViewController.h"

@implementation TouchDragHitAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
