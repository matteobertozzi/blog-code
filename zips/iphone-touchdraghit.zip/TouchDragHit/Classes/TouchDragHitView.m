//
//  TouchDragHitView.m
//  TouchDragHit
//
//  Created by Matteo Bertozzi on 5/1/09.
//  Copyright Matteo Bertozzi 2009. All rights reserved.
//

#import "TouchDragHitView.h"

@implementation TouchDragHitView

@synthesize hitDelegate;

- (void)dealloc {
	hitDelegate = nil;

	[dragView release];
	[hitView release];
	[super dealloc];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
	UITouch *touch = [touches anyObject];
	_dragActive = ([touch view] == dragView);
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
	UITouch *touch = [touches anyObject];

	if (_dragActive && [touch view] == dragView) {
		[UIView beginAnimations:@"dragView" context:nil];
		[UIView setAnimationBeginsFromCurrentState:YES];
		[UIView setAnimationDuration:0.25];

		dragView.center = [touch locationInView:self];

		[UIView commitAnimations];
	}
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
	UITouch *touch = [touches anyObject];

	if (_dragActive && [touch view] == dragView) {
		CGPoint touchLocation = [touch locationInView:self];
		if (CGRectContainsPoint([hitView frame], touchLocation)) {
			if ([hitDelegate respondsToSelector:@selector(touchDragHitView:hitEvent:)])
				[hitDelegate touchDragHitView:self hitEvent:touchLocation];
		} else {
			if ([hitDelegate respondsToSelector:@selector(touchDragHitView:missEvent:)])
				[hitDelegate touchDragHitView:self missEvent:touchLocation];
		}
	}

	_dragActive = NO;
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event {
	if (_dragActive) {
		[UIView beginAnimations:@"dragView" context:nil];
		[UIView setAnimationBeginsFromCurrentState:YES];
		[UIView setAnimationDuration:0.5];

		dragView.center = self.center;

		[UIView commitAnimations];
	}

	_dragActive = NO;
}

@end

