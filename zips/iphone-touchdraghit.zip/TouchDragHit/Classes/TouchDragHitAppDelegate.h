//
//  TouchDragHitAppDelegate.h
//  TouchDragHit
//
//  Created by Matteo Bertozzi on 5/1/09.
//  Copyright Matteo Bertozzi 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TouchDragHitViewController;

@interface TouchDragHitAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    TouchDragHitViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet TouchDragHitViewController *viewController;

@end

