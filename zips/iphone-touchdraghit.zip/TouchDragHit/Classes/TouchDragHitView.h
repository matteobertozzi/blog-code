//
//  TouchDragHitView.h
//  TouchDragHit
//
//  Created by Matteo Bertozzi on 5/1/09.
//  Copyright Matteo Bertozzi 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol TouchDragHitDelegate;

@interface TouchDragHitView : UIView {
	id<TouchDragHitDelegate> hitDelegate;

	IBOutlet UIView *dragView;
	IBOutlet UIView *hitView;

	BOOL _dragActive;
}

@property(nonatomic, assign) id<TouchDragHitDelegate> hitDelegate;

@end

@protocol TouchDragHitDelegate

@required

- (void)touchDragHitView:(TouchDragHitView *)view hitEvent:(CGPoint)location;
- (void)touchDragHitView:(TouchDragHitView *)view missEvent:(CGPoint)location;

@end

