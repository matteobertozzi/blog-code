#!/usr/bin/env python

FLICKR_API_KEY = 'YOUR FLICKR KEY'
FLICKR_PHOTO_ATTRIBUTES = ['id', 'secret', 'server', 'farm', 'title']
FLICKR_PHOTO_TAG = 'photo'

def fetch_url(url):
	import urllib2
	
	fd = urllib2.urlopen(url)
	flickrXml = fd.read()
	fd.close()

	return(flickrXml)

def parse_xml(xmlData, objTag, attributes):
	import xml.dom.minidom

	xmlDom = xml.dom.minidom.parseString(xmlData)
	xmlElements = xmlDom.documentElement.getElementsByTagName(objTag)
	
	elements = []
	for xmlElement in xmlElements:
		elementInfo = {}
		for attr in attributes:
			elementInfo[attr] = xmlElement.getAttribute(attr)
		elements.append(elementInfo)

	return(elements)

def write_photo_file(fileName, blob):
	fd = open(fileName, 'wb')
	fd.write(blob)
	fd.close()
	
def flickr_search(apiKey, text, tags):	
	# <photo id="3529002533" owner="7901942@N04" secret="121ce81fcf" server="3596" 
	#            farm="4" title="PyConTre" ispublic="1" isfriend="0" isfamily="0" /> 
	flickrUrl  = 'http://api.flickr.com/services/rest/?method=flickr.photos.search'
	flickrUrl += '&api_key=' + apiKey + '&tags=' + tags
	flickrUrl += '&text=' + text + '&per_page=500'
	
	return(fetch_url(flickrUrl))
	
def flickr_photo(farmId, serverId, id, secret, format='jpg'):
	# http://farm{farm-id}.static.flickr.com/{server-id}/{id}_{o-secret}_o.(jpg|gif|png)
	flickrUrl  = 'http://farm' + farmId + '.static.flickr.com/'
	flickrUrl += serverId + '/' + id + '_' + secret + '_b_d.' + format
	return(fetch_url(flickrUrl))

