#!/usr/bin/env python
# 
# Usage: pycon3-flickr.py [-save]
#

from PyQt4 import QtCore, QtGui
from flickr import *

import sys

IMAGE_PREVIEW_HEIGHT = 115
IMAGE_PREVIEW_WIDTH  = 160

FLICKR_PYCON3_URL = 'http://www.flickr.com/photos/tags/pycon3'

class FlickrThread(QtCore.QThread):
	def __init__(self, parent=None):
		QtCore.QThread.__init__(self, parent)
	
	def run(self):
		pyConTexts = 'PyCon3'
		pyConTags = 'PyCon3'

		saveToFile = self.hasSaveArg()		
		photos = parse_xml(flickr_search(FLICKR_API_KEY, pyConTags, pyConTexts), 
										FLICKR_PHOTO_TAG, FLICKR_PHOTO_ATTRIBUTES)
		for photo in photos:
			blob = flickr_photo(photo['farm'], photo['server'], photo['id'], photo['secret'], 'jpg')
			if (saveToFile): write_photo_file(photo['id'] + '.jpg', blob)
			
			image = QtGui.QImage.fromData(blob)
			self.emit(QtCore.SIGNAL('flickrImage(const QImage&, const QString&)'), image, photo['title'])
	
	def hasSaveArg(self):
		for arg in sys.argv:
			if (arg == '-save'):
				return(True)
		return(False)

class FlickrViewer(QtGui.QListView):
	def __init__(self, parent=None):
		QtGui.QListView.__init__(self, parent)
		
		self.setViewMode(QtGui.QListView.IconMode)
		self.itemModel = QtGui.QStandardItemModel()		
		self.setModel(self.itemModel)
		self.setWrapping(True)
		self.setWordWrap(True)	

		# Setup Font
		qFont = self.font()
		qFont = QtGui.QFont(qFont.family(), qFont.pointSize(), QtGui.QFont.Bold)
		self.setFont(qFont)		
		
		# Setup Background and Foreground Colors
		qPalette = self.palette()
		qPalette.setColor(QtGui.QPalette.Foreground, QtGui.QColor(0xFF, 0xFF, 0xFF))
		qPalette.setColor(QtGui.QPalette.Text, QtGui.QColor(0xFF, 0xFF, 0xFF))	
		qPalette.setColor(QtGui.QPalette.Background, QtGui.QColor(0x77, 0x77, 0x77))
		qPalette.setColor(QtGui.QPalette.Base, QtGui.QColor(0x77, 0x77, 0x77))
		self.setPalette(qPalette)
		
		self.setForegroundRole(QtGui.QPalette.Foreground)
		self.setBackgroundRole(QtGui.QPalette.Background)
		
		self.setResizeMode(QtGui.QListView.Adjust)
		self.setIconSize(QtCore.QSize(IMAGE_PREVIEW_WIDTH, IMAGE_PREVIEW_HEIGHT))
		self.setGridSize(QtCore.QSize(	IMAGE_PREVIEW_WIDTH + 20,
										IMAGE_PREVIEW_HEIGHT + 25))
		self.setSpacing(2)
		
		# Setup ContextMenu
		self.setContextMenuPolicy(QtCore.Qt.DefaultContextMenu)
	
	def loadData(self):			
		self.thread = FlickrThread()
		self.connect(self.thread,
					 QtCore.SIGNAL('flickrImage(const QImage&, const QString&)'),
					 self.addImage)
		self.thread.start()

	def addImage(self, image, title):
		rootItem = self.itemModel.invisibleRootItem()
		item = QtGui.QStandardItem(QtGui.QIcon(QtGui.QPixmap.fromImage(image)), title)
		item.setEditable(False)
		rootItem.appendRow(item)
	
def main():	
	app = QtGui.QApplication(sys.argv)
	
	flickrViewer = FlickrViewer()
	flickrLabelUrl = QtGui.QLabel(format('<a href="%s">%s</a>' % (FLICKR_PYCON3_URL, FLICKR_PYCON3_URL)))
	flickrLabelUrl.setAlignment(QtCore.Qt.AlignVCenter | QtCore.Qt.AlignRight)
	flickrLabelUrl.setOpenExternalLinks(True)
	
	layout = QtGui.QVBoxLayout()
	layout.addWidget(flickrViewer)
	layout.addWidget(flickrLabelUrl)
	layout.setContentsMargins(6, 6, 6, 6)
	
	w = QtGui.QWidget()
	w.setWindowTitle('PyCon3 Italia - Flickr Photos')
	w.setWindowIcon(QtGui.QIcon('flickr.ico'))
	w.setLayout(layout)
	w.resize(580, 360)
	
	flickrViewer.loadData()	
	
	w.show()
	
	sys.exit(app.exec_())
	
if (__name__ == '__main__'):
	main()

