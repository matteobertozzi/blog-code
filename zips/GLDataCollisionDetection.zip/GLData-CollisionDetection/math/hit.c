#include "vectors.h"
#include "maths.h"
#include "hit.h"

static GLDataHitType __boxContainsBox (GLDataBox *box1, GLDataBox *box2) {
    if (box2->max.x < box1->min.x || box2->min.x > box1->max.x ||
        box2->max.y < box1->min.y || box2->min.y > box1->max.y ||
        box2->max.z < box1->min.z || box2->min.z > box1->max.z)
    {
        return(GLDATA_HIT_TYPE_DISJOINT);
    }

    if (box2->min.x >= box1->min.x && box2->max.x <= box1->max.x &&
        box2->min.y >= box1->min.y && box2->max.y <= box1->max.y &&
        box2->min.z >= box1->min.z && box2->max.z <= box1->max.z)
    {
        return(GLDATA_HIT_TYPE_CONTAINS);
    }

    return(GLDATA_HIT_TYPE_INTERSECTS);
}

static GLDataHitType __boxContainsSphere (GLDataBox *box, GLDataSphere *sphere)
{
    GLDataFloat d = 0.0f;

    if ((sphere->center.x - box->min.x) > sphere->radius &&
        (sphere->center.y - box->min.y) > sphere->radius &&
        (sphere->center.z - box->min.z) > sphere->radius &&
        (box->max.x - sphere->center.x) > sphere->radius &&
        (box->max.y - sphere->center.y) > sphere->radius &&
        (box->max.z - sphere->center.z) > sphere->radius)
    {
        return(GLDATA_HIT_TYPE_CONTAINS);
    }

    if ((sphere->center.x - box->min.x) <= sphere->radius)
        d += glDataPow2(sphere->center.x - box->min.x);
    else if ((box->max.x - sphere->center.x) <= sphere->radius)
        d += glDataPow2(sphere->center.x - box->max.x);

    if ((sphere->center.y - box->min.y) <= sphere->radius)
        d += glDataPow2(sphere->center.y - box->min.y);
    else if ((box->max.y - sphere->center.y) <= sphere->radius)
        d += glDataPow2(sphere->center.y - box->max.y);

    if ((sphere->center.z - box->min.z) <= sphere->radius)
        d += glDataPow2(sphere->center.z - box->min.z);
    else if ((box->max.z - sphere->center.z) <= sphere->radius)
        d += glDataPow2(sphere->center.z - box->max.z);

    if (d <= glDataPow2(sphere->radius))
        return(GLDATA_HIT_TYPE_INTERSECTS);

    return(GLDATA_HIT_TYPE_DISJOINT);
}

static GLDataHitType __boxContainsPoint (GLDataBox *box, GLDataPoint *point) 
{
    if (point->x < box->min.x || point->x > box->max.x ||
        point->y < box->min.y || point->y > box->max.y ||
        point->z < box->min.z || point->z > box->max.z)
    {
        return(GLDATA_HIT_TYPE_DISJOINT);
    }

    if (point->x == box->min.x || point->x == box->max.x ||
        point->y == box->min.y || point->y == box->max.y ||
        point->z == box->min.z || point->z == box->max.z)
    {
        return(GLDATA_HIT_TYPE_INTERSECTS);
    }

    return(GLDATA_HIT_TYPE_CONTAINS);
}

static GLDataHitType __sphereContainsPoint (GLDataSphere *sphere, GLDataPoint *point)
{
    GLDataFloat distance;

    distance = glDataVectorDistance(point, &(sphere->center));

    if (distance > sphere->radius)
        return(GLDATA_HIT_TYPE_DISJOINT);

    if (distance < sphere->radius)
        return(GLDATA_HIT_TYPE_CONTAINS);

    return(GLDATA_HIT_TYPE_INTERSECTS);
}

static GLDataHitType __sphereContainsBox (GLDataSphere *sphere, GLDataBox *box)
{
    GLDataPoint boxCorners[8];
    GLDataFloat d = 0.0f;
    GLDataUInt i;

    glDataPointInit(&(boxCorners[0]), box->min.x, box->max.y, box->max.z);
    glDataPointInit(&(boxCorners[1]), box->max.x, box->max.y, box->max.z);
    glDataPointInit(&(boxCorners[2]), box->max.x, box->min.y, box->max.z);
    glDataPointInit(&(boxCorners[3]), box->min.x, box->min.y, box->max.z);
    glDataPointInit(&(boxCorners[4]), box->min.x, box->max.y, box->min.z);
    glDataPointInit(&(boxCorners[5]), box->max.x, box->max.y, box->min.z);
    glDataPointInit(&(boxCorners[6]), box->max.x, box->min.y, box->min.z);
    glDataPointInit(&(boxCorners[7]), box->min.x, box->min.y, box->min.z);

    for (i = 0; i < 8; ++i) {
        if (__sphereContainsPoint(sphere, &boxCorners[i]) == GLDATA_HIT_TYPE_DISJOINT)
            goto __sphere_box_not_inside;
    }

    return(GLDATA_HIT_TYPE_CONTAINS);

__sphere_box_not_inside:
    if (sphere->center.x < box->min.x)
        d += glDataPow2(sphere->center.x - box->min.x);
    else if (sphere->center.x > box->max.x)
        d += glDataPow2(sphere->center.x - box->max.x);

    if (sphere->center.y < box->min.y)
        d += glDataPow2(sphere->center.y - box->min.y);
    else if (sphere->center.y > box->max.y)
        d += glDataPow2(sphere->center.y - box->max.y);

    if (sphere->center.z < box->min.z)
        d += glDataPow2(sphere->center.z - box->min.z);
    else if (sphere->center.y > box->max.y)
        d += glDataPow2(sphere->center.z - box->max.z);

    if (d <= glDataPow2(sphere->radius))
        return(GLDATA_HIT_TYPE_INTERSECTS);

    return(GLDATA_HIT_TYPE_DISJOINT);
}

static GLDataHitType __sphereContainsSphere (GLDataSphere *s1, GLDataSphere *s2)
{
    GLDataFloat distance;

    distance = glDataVectorDistance(&(s2->center), &(s1->center));

    if (distance > (s2->radius + s1->radius))
        return(GLDATA_HIT_TYPE_DISJOINT);

    if (distance <= (s1->radius - s2->radius))
        return(GLDATA_HIT_TYPE_CONTAINS);

    return(GLDATA_HIT_TYPE_INTERSECTS);
}


GLDataBool glDataHitDisjoint (GLDataHitObject *obj1, GLDataHitObject *obj2) {
    return(glDataHitInfo(obj1, obj2) == GLDATA_HIT_TYPE_DISJOINT);
}

GLDataBool glDataHitContains (GLDataHitObject *obj1, GLDataHitObject *obj2) {
    return(glDataHitInfo(obj1, obj2) == GLDATA_HIT_TYPE_CONTAINS);
}

GLDataBool glDataHitCollision (GLDataHitObject *obj1, GLDataHitObject *obj2) {
    return(glDataHitInfo(obj1, obj2) != GLDATA_HIT_TYPE_DISJOINT);
}

GLDataBool glDataHitIntersects (GLDataHitObject *obj1, GLDataHitObject *obj2) {
    return(glDataHitInfo(obj1, obj2) == GLDATA_HIT_TYPE_INTERSECTS);
}

GLDataHitType glDataHitInfo (GLDataHitObject *obj1, GLDataHitObject *obj2) {
    if (glDataHitObjectIsBox(obj1)) {
        if (glDataHitObjectIsBox(obj2))
            return(__boxContainsBox(glDataHitBox(obj1), glDataHitBox(obj2)));
        /* else if (glDataHitObjectIsSphere(obj2)) */
        return(__boxContainsSphere(glDataHitBox(obj1), glDataHitSphere(obj2)));
        /* ... more types ... */
    } 

    if (glDataHitObjectIsSphere(obj1)) {
        if (glDataHitObjectIsBox(obj2))
            return(__sphereContainsBox(glDataHitSphere(obj1), glDataHitBox(obj2)));
        /* else if (glDataHitObjectIsSphere(obj2)) */
        return(__sphereContainsSphere(glDataHitSphere(obj1), glDataHitSphere(obj2)));
        /* ... more types ... */
    }

    /* Unreached... */
    return(GLDATA_HIT_TYPE_DISJOINT);
}

GLDataHitType glDataHitPointInfo (GLDataHitObject *obj, GLDataPoint *point) {
    if (glDataHitObjectIsBox(obj))
        return(__boxContainsPoint(glDataHitBox(obj), point));
    
    if (glDataHitObjectIsSphere(obj))
        return(__sphereContainsPoint(glDataHitSphere(obj), point));

    /* Unreached... */
    return(GLDATA_HIT_TYPE_DISJOINT);
}

