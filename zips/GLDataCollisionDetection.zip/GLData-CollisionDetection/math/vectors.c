/*
 *  vectors.c
 *  GLDataEngine
 *
 *  Created by Matteo Bertozzi on 11/15/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#include <math.h>

#include "vectors.h"

void glDataVectorAdd (GLDataPoint *dest, 
                      GLDataPoint *v1,
                      GLDataPoint *v2)
{
    dest->x = v1->x + v2->x;
    dest->y = v1->y + v2->y;
    dest->z = v1->z + v2->z;
}

void glDataVectorSub (GLDataPoint *dest, 
                      GLDataPoint *v1,
                      GLDataPoint *v2)
{
    dest->x = v1->x - v2->x;
    dest->y = v1->y - v2->y;
    dest->z = v1->z - v2->z;
}

void glDataVectorMul (GLDataPoint *dest, 
                      GLDataPoint *v,
                      GLDataFloat k)
{
    dest->x = v->x * k;
    dest->y = v->y * k;
    dest->z = v->z * k;
}

void glDataVectorDiv (GLDataPoint *dest, 
                      GLDataPoint *v,
                      GLDataFloat k)
{
    dest->x = v->x / k;
    dest->y = v->y / k;
    dest->z = v->z / k;
}

void glDataVectorNormalize (GLDataPoint *v) {
    GLDataFloat r;
    
    if ((r = sqrt((v->x * v->x) + (v->y * v->y) + (v->z * v->z))) == 0.0f)
        return;
    
    v->x /= r;
    v->y /= r;
    v->z /= r;
}

void glDataVectorCrossProduct (GLDataPoint *dest, 
                               GLDataPoint *v1,
                               GLDataPoint *v2)
{
    dest->x = (v1->y * v2->z) - (v1->z * v2->y);
    dest->y = (v1->z * v2->x) - (v1->x * v2->z);
    dest->z = (v1->x * v2->y) - (v1->y * v2->x);
}

GLDataFloat glDataVectorDotProduct (GLDataPoint *v1,
                                    GLDataPoint *v2)
{
    return((v1->x * v2->x) + (v1->y * v2->y) + (v1->z * v2->z));
}

GLDataFloat glDataVectorDistance (GLDataPoint *v1,
                                  GLDataPoint *v2)
{
    return(sqrt(((v1->x - v2->x) * (v1->x - v2->x)) +
                ((v1->y - v2->y) * (v1->y - v2->y)) +
                ((v1->z - v2->z) * (v1->z - v2->z))));
}
