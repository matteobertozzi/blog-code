#ifndef _GLDATA_MATH_H_
#define _GLDATA_MATH_H_

#define GLDATA_MATH_PI          (3.1415926535897931f)
#define GLDATA_EPSILON          (1.0E-20)

#define glDataIsZero(x)         ((x) > -GLDATA_EPSILON && (x) < GLDATA_EPSILON)

#define glDataMin(a, b)         (((a) < (b)) ? (a) : (b))
#define glDataMax(a, b)         (((a) < (b)) ? (a) : (b))

#define glDataPow2(x)           ((x) * (x))

#define glDataRadToDeg(rad)     ((rad * 180.0f) / GLDATA_MATH_PI)
#define glDataDegToRad(deg)     ((deg * GLDATA_MATH_PI) / 180.0f)

#endif /* !_GLDATA_MATH_H_ */

