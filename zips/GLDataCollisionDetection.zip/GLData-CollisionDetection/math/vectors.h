/*
 *  vectors.h
 *  GLDataEngine
 *
 *  Created by Matteo Bertozzi on 11/15/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */
 
#ifndef _GLDATA_VECTORS_H_
#define _GLDATA_VECTORS_H_

#include <GLData/Objects.h>
#include <GLData/Types.h>

void        glDataVectorNormalize    (GLDataPoint *v);

void        glDataVectorAdd          (GLDataPoint *dest, 
                                      GLDataPoint *v1,
                                      GLDataPoint *v2);

void        glDataVectorSub          (GLDataPoint *dest, 
                                      GLDataPoint *v1,
                                      GLDataPoint *v2);

void        glDataVectorMul          (GLDataPoint *dest, 
                                      GLDataPoint *v,
                                      GLDataFloat k);

void        glDataVectorDiv          (GLDataPoint *dest, 
                                      GLDataPoint *v,
                                      GLDataFloat k);


void        glDataVectorCrossProduct (GLDataPoint *dest, 
                                      GLDataPoint *v1,
                                      GLDataPoint *v2);

GLDataFloat glDataVectorDotProduct   (GLDataPoint *v1,
                                      GLDataPoint *v2);

GLDataFloat glDataVectorDistance     (GLDataPoint *v1,
                                      GLDataPoint *v2);


#endif /* !_GLDATA_VECTORS_H_ */
