#ifndef _GLDATA_HIT_H_
#define _GLDATA_HIT_H_

#include <GLData/Objects.h>
#include <GLData/Types.h>

typedef enum {
    GLDATA_HIT_TYPE_DISJOINT,
    GLDATA_HIT_TYPE_INTERSECTS,
    GLDATA_HIT_TYPE_CONTAINS
} GLDataHitType;

typedef enum {
    GLDATA_HIT_OBJECT_TYPE_BOX,
    GLDATA_HIT_OBJECT_TYPE_SPHERE,
} GLDataHitObjectType;

typedef struct {
    union {
        GLDataBox box;
        GLDataSphere sphere;
    } shape;
    GLDataHitObjectType type;
} GLDataHitObject;

#define glDataHitBox(p)             (&((p)->shape.box))
#define glDataHitSphere(p)          (&((p)->shape.sphere))
#define glDataHitObjectIsBox(p)     ((p)->type == GLDATA_HIT_OBJECT_TYPE_BOX)
#define glDataHitObjectIsSphere(p)  ((p)->type == GLDATA_HIT_OBJECT_TYPE_SPHERE)

#define glDataHitSetBoxType(p)      ((p)->type = GLDATA_HIT_OBJECT_TYPE_BOX)
#define glDataHitSetSphereType(p)   ((p)->type = GLDATA_HIT_OBJECT_TYPE_SPHERE)

GLDataBool glDataHitDisjoint     (GLDataHitObject *obj1, GLDataHitObject *obj2);
GLDataBool glDataHitContains     (GLDataHitObject *obj1, GLDataHitObject *obj2);
GLDataBool glDataHitCollision    (GLDataHitObject *obj1, GLDataHitObject *obj2);
GLDataBool glDataHitIntersects   (GLDataHitObject *obj1, GLDataHitObject *obj2);

GLDataHitType glDataHitInfo      (GLDataHitObject *obj1, GLDataHitObject *obj2);
GLDataHitType glDataHitPointInfo (GLDataHitObject *obj, GLDataPoint *point);

#endif /* !_GLDATA_HIT_H_ */

