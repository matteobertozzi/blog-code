#!/usr/bin/env python
#-*- coding: utf-8 -*-

import commands
import string
import sys
import os

def execCommand(cmd):
    return commands.getstatusoutput(cmd)

class Build:
    def __init__(self, cflags=None, defines=None, includes=None, ldlibs=None):
        # Compiler
        self.cc = self._findCompiler()

        # Setup Temp Directories
        self.dir_obj = '.BUILD-OBJ'
        self.dir_out = 'BUILD-OUT'

        # CFlags
        self.cflags = self._defaultCFlags()
        if not cflags is None:
            self.cflags.extend(cflags)

        # Defines
        self.defines = self._defaultDefines()
        if not defines is None:
            self.defines.extend(defines)

        # Include Paths
        self.includes = self._defaultIncludes()
        if not includes is None:
            self.includes.extend(includes)

        # LD Libs
        self.ldlibs = self._defaultLdLibs()
        if not ldlibs is None:
            self.ldlibs.extend(ldlibs)

    def addCFlags(self, cflags):
        self.cflags.extend(cflags)

    def addDefines(self, defines):
        self.defines.extend(defines)

    def addIncludePaths(self, includes):
        self.includes.extend(includes)

    def addLdLibs(self, ldlibs):
        self.ldlibs.extend(ldlibs)

    def setDirObj(self, dir_path):
        self.dir_obj = dir_path
        if not os.path.exists(self.dir_obj):
            os.makedirs(self.dir_obj)

    def setDirOutput(self, dir_path):
        self.dir_out = dir_path
        if not os.path.exists(self.dir_out):
            os.makedirs(self.dir_out)

    def cleanup(self):
        self._removeDirectory(self.dir_obj)

    def buildApp(self, app_name, dirs_src):
        print 'Building %s' % (app_name)
        print '-' * 60

        self.compileDirectory(dir_src)

        obj_list = os.listdir(self.dir_obj)
        obj_list = [os.path.join(self.dir_obj, f) for f in obj_list]

        app_path = os.path.join(self.dir_out, app_name)

        cmd = '%s -o %s %s %s' %                   \
                (self.cc, app_path,                \
                 string.join(obj_list, ' '),       \
                 string.join(self.ldlibs, ' '))

        print ' [LD]', app_name
        exit_code, output = execCommand(cmd)
        if exit_code != 0:
            print ' * Failed with Status', exit_code
            print ' *', cmd
            print output
            sys.exit(1)
        print

    def buildLibrary(self, libname, libversion, dirs_src):
        print 'Building %s %s Library' % (libname, libversion)
        print '-' * 60

        for dir_src in dirs_src:
            self.compileDirectory(dir_src)

        obj_list = os.listdir(self.dir_obj)
        obj_list = [os.path.join(self.dir_obj, f) for f in obj_list]

        libversion_maj = libversion[:libversion.index('.')]
        lib_ext = 'dlib' if os.uname()[0] == 'Darwin' else 'so'
        lib_name = 'lib%s.%s' % (libname, lib_ext)
        lib_name_maj = 'lib%s.%s.%s' % (libname, lib_ext, libversion_maj)
        lib_name_full = 'lib%s.%s.%s' % (libname, lib_ext, libversion)
        lib_path = os.path.join(self.dir_out, lib_name_full)

        if os.uname()[0] == 'Darwin':
            cmd = '%s -o %s -dynamiclib %s %s' % \
		            (self.cc, lib_path,       \
        	         string.join(obj_list, ' '),            \
            	     string.join(self.ldlibs, ' '))
        else:
	        cmd = '%s -shared -Wl,-soname,%s -o %s %s %s' % \
    	            (self.cc, lib_name_maj, lib_path,           \
        	         string.join(obj_list, ' '),            \
            	     string.join(self.ldlibs, ' '))

        print
        print ' [LD]', lib_name_full
        exit_code, output = execCommand(cmd)
        if exit_code != 0:
            print ' * Failed with Status', exit_code
            print ' *', cmd
            print output
            sys.exit(1)

        cwd = os.getcwd()
        os.chdir(self.dir_out)
        for name in (lib_name, lib_name_maj):
            print ' [LN]', name
            execCommand('ln -s %s %s' % (lib_name_full, name))
        os.chdir(cwd)

        print

    def buildMiniTools(self, name, dir_src):
        print 'Building %s' % (name)
        print '-' * 60

        self.compileDirectory(dir_src)

        for obj_name in os.listdir(self.dir_obj):
            app_name = obj_name[:-2]
            app_path = os.path.join(self.dir_out, app_name)
            obj_path = os.path.join(self.dir_obj, obj_name)

            cmd = '%s -o %s %s %s' %                   \
                    (self.cc, app_path, obj_path,      \
                     string.join(self.ldlibs, ' '))
            print ' [LD]', app_name
            exit_code, output = execCommand(cmd)
            if exit_code != 0:
                print ' * Failed with Status', exit_code
                print ' *', cmd
                print output
                sys.exit(1)
        print

    def compileDirectory(self, dir_src):
        for root, dirs, files in os.walk(dir_src, topdown=False):
            for name in files:
                if name.endswith('.c'):
                    self.compileFile(os.path.join(root, name))

    def compileFile(self, filename):
        objfile = os.path.basename(filename)
        objfile = objfile[:objfile.rindex('.')] + '.o'
        objfile = os.path.join(self.dir_obj, objfile)

        cmd = '%s -c %s %s %s %s -o %s' %         \
               (self.cc,                          \
                string.join(self.cflags, ' '),    \
                string.join(self.defines, ' '),   \
                string.join(self.includes, ' '),  \
                filename,
                objfile)

        print ' [CC]', filename
        exit_code, output = execCommand(cmd)
        if exit_code != 0:
            print ' * Failed with Status', exit_code
            print ' * %s' % (cmd)
            print output
            sys.exit(1)

    def _removeFile(self, path):
        if os.path.exists(path):
            os.remove(path)

    def _removeDirectory(self, path):
        if os.path.exists(path):
            for root, dirs, files in os.walk(path, topdown=False):
                for name in files:
                    os.remove(os.path.join(root, name))
            os.removedirs(path)

    def _findCompiler(self):
        return('/usr/bin/gcc')

    def _defaultCFlags(self):
        return ['-g', '-O3', '-Wall', '-fno-strict-aliasing', '-Werror']

    def _defaultDefines(self):
        return ['-D__USE_FILE_OFFSET64']

    def _defaultIncludes(self):
        return []

    def _defaultLdLibs(self):
        return ['-lm']

class GLDataBuild:
    def __init__(self):
        self.lib_version = '1.0.0'
        self.lib_name = 'gldata'

        self.dir_obj = './.BUILD-LIB-OBJ'
        self.dir_out = './BUILD-OUT'

        Build()._removeDirectory(self.dir_obj)

        self._generatePubHeaders()

    def _generatePubHeaders(self):
        dirs_src = [ 'core', 'images', 'math' ]
        dir_pubhead = './GLData'

        if os.path.exists(dir_pubhead):
            Build()._removeDirectory(dir_pubhead)
        os.makedirs(dir_pubhead)

        replaceNames = {'imagereader.h':'ImageReader.h',
                        'meshreader.h':'MeshReader.h'}

        for dir_src in dirs_src:
            for root, dirs, files in os.walk(dir_src, topdown=False):
                if root.endswith('private'):
                    continue

                for name in files:
                    if name.endswith('.h'):
                        in_path = os.path.join(root, name)
                        
                        if name in replaceNames:
                            out_name = replaceNames[name]
                        else:
                            out_name = name[0].upper() + name[1:]

                        out_path = os.path.join(dir_pubhead, out_name)
                        cmd = 'cp %s %s' % (in_path, out_path)
                        exit_code, output = execCommand(cmd)

    def buildLibrary(self):
        _, pngInclude = execCommand('libpng12-config --cflags')
        _, pngLib = execCommand('libpng12-config --libs')

        includes = ['-I./', '-I../', '-I./core/', '-I./images/', '-I./math', pngInclude]
        dirs_src = [ './core', './images', './math' ]
        cflags = [ '-fPIC' ]
        ldlibs = [pngLib, '-L/usr/X11/lib']

        build = Build()
        build.setDirObj(self.dir_obj)
        build.setDirOutput(self.dir_out)
        build.addLdLibs(ldlibs)
        build.addCFlags(cflags)
        build.addIncludePaths(includes)
        build.buildLibrary(self.lib_name, self.lib_version, dirs_src)
        build.cleanup()

    def buildTests(self):
        _, pngInclude = execCommand('libpng12-config --cflags')
        _, pngLib = execCommand('libpng12-config --libs')

        includes = ['-I./', '-I../', '-I./core/', '-I./images/', '-I./math', pngInclude]
        if os.uname()[0] == 'Darwin':
            ldlibs = ['%s.dlib' % os.path.join(self.dir_out, 'lib' + self.lib_name), pngLib,
                      '-L/usr/X11/lib', '-framework GLUT', '-framework OpenGL']
        else:
            ldlibs = ['-L%s -l%s' % (self.dir_out, self.lib_name), pngLib, '-lglut', '-lGL', '-lGLU']
        dir_src = './tests'

        build = Build()
        build.setDirObj(self.dir_obj)
        build.setDirOutput(self.dir_out)
        build.addLdLibs(ldlibs)
        build.addIncludePaths(includes)
        build.buildMiniTools('Tools', dir_src)
        build.cleanup()

    def executeTests(self):
        print ' [T] GLData Tests'
        cmd = 'LD_LIBRARY_PATH=%s:./libs %s' %     \
                (self.dir_out, os.path.join(self.dir_out, 'test-hit'))
        exit_code, output = execCommand(cmd)
        if exit_code != 0:
            print ' * Failed with Status', exit_code
            print ' * ', cmd
        print output

def main(argv):
    glDataBuild = GLDataBuild()
    glDataBuild.buildLibrary()
    glDataBuild.buildTests()
    glDataBuild.executeTests()

if __name__ == '__main__':
    main(sys.argv)

