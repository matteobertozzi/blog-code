#ifndef _GLDATA_LIST_H_
#define _GLDATA_LIST_H_

#include <GLData/Types.h>

typedef struct _GLDataList GLDataList;

typedef GLDataBool (*GLDataForeachFunc)   (GLDataUInt index,
                                           void *data, 
                                           void *userData);

typedef GLDataBool (*GLDataSearchCmpFunc) (void *data, 
                                           void *userData);

GLDataList *glDataListAlloc    (void);
void        glDataListRelease  (GLDataList *list, GLDataReleaseFunc releaseFunc);

void        glDataListClear    (GLDataList *list, GLDataReleaseFunc releaseFunc);

GLDataUInt  glDataListSize     (GLDataList *list);
GLDataBool  glDataListAppend   (GLDataList *list, void *data);

void *      glDataListAt       (GLDataList *list, GLDataUInt index);
GLDataBool  glDataListContains (GLDataList *list, void *data);

void        glDataListForeach  (GLDataList *list,
                                GLDataForeachFunc func,
                                void *userData);
void *      glDataListSearch   (GLDataList *list,
                                GLDataSearchCmpFunc func,
                                void *userData);

#endif /* !_GLDATA_LIST_H_ */

