#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "alloc.h"

void *__glDataAlloc (unsigned int size,
                     const char *file, int line, const char *func)
{
    void *ptr;

    if ((ptr = malloc(size)) == NULL) {
        fprintf(stderr, "%s %d %s %fKb ", file, line, func, (float)size / 1024.0f);
        perror("malloc()");
        abort();
    }

    return(ptr);
}

void *__glDataZAlloc (unsigned int size,
                      const char *file, int line, const char *func)
{
    void *ptr;

    if ((ptr = __glDataAlloc(size, file, line, func)) != NULL)
        memset(ptr, 0, size);

    return(ptr);
}

void __glDataFree (void *ptr) {
    free(ptr);
}

