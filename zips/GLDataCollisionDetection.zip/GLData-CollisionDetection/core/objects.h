#ifndef _GLDATA_OBJECTS_H_
#define _GLDATA_OBJECTS_H_

#include <GLData/Types.h>

typedef struct {
    GLDataBool internalAlloc;
    GLDataUInt retainCount;
} GLDataType;

#define GLDATA_OBJECT                 GLDataType _base;
#define glDataGetBase(p)              (&(p->_base))

GLDataType *_glDataInit            (GLDataType *data, GLDataBool internalAlloc);
GLDataType *_glDataRetain          (GLDataType *data);
GLDataBool  _glDataRelease         (GLDataType *data);
GLDataBool  _glDataInternalAlloc   (GLDataType *data);
GLDataUInt  glDataGetRetainCount   (GLDataType *data);

typedef struct {
    GLDataFloat x;
    GLDataFloat y;
} GLDataUVPoint;

typedef struct {
    GLDataFloat x;
    GLDataFloat y;
    GLDataFloat z;
} GLDataPoint;

typedef struct {
    GLDataPoint a;
    GLDataPoint b;
    GLDataPoint c;
    GLDataPoint d;
} GLDataMatrix;

typedef struct {
    GLDataPoint min;
    GLDataPoint max;
} GLDataBox;

typedef struct {
    GLDataPoint center;
    GLDataFloat radius;
} GLDataSphere;

typedef struct {
    GLDATA_OBJECT

    GLDataUVPoint *points;
    GLDataUInt npoints;
} GLDataUVPolygon;

typedef struct {
    GLDATA_OBJECT

    GLDataPoint *points;
    GLDataUInt npoints;
} GLDataPolygon;

typedef struct {
    GLDATA_OBJECT

    GLDataUInt *points;
    GLDataUInt npoints;
} GLDataFace;

typedef GLDataPolygon GLDataTriangle;
typedef GLDataPolygon GLDataQuad;

typedef struct {
    GLDATA_OBJECT

    GLDataPolygon **polygons;
    GLDataUInt npolygons;
} GLDataSurface;

typedef struct {
    GLDATA_OBJECT

    GLDataUVPolygon **polygons;
    GLDataUInt npolygons;
} GLDataUVSurface;

/* UV Point */
#define        glDataUVPoint(p)       ((GLDataUVPoint *)(p))
GLDataUVPoint *glDataUVPointAlloc     (void);
void           glDataUVPointRelease   (GLDataUVPoint *point);

GLDataUVPoint *glDataUVPointInit      (GLDataUVPoint *uv,
                                       GLDataFloat x,
                                       GLDataFloat y);
GLDataUVPoint *glDataUVPointInitCopy  (GLDataUVPoint *uv,
                                       const GLDataUVPoint *other);

GLDataUVPoint *glDataUVPointCopy      (GLDataUVPoint *dest,
                                       const GLDataUVPoint *src);
GLDataBool     glDataUVPointEqual     (const GLDataUVPoint *point,
                                       const GLDataUVPoint *other);
GLDataBool     glDataUVPointNotEqual  (const GLDataUVPoint *point,
                                       const GLDataUVPoint *other);

/* Point */
#define        glDataPoint(p)         ((GLDataPoint *)(p))
GLDataPoint *  glDataPointAlloc       (void);
void           glDataPointRelease     (GLDataPoint *point);

GLDataPoint *  glDataPointInit        (GLDataPoint *point,
                                       GLDataFloat x,
                                       GLDataFloat y,
                                       GLDataFloat z);
GLDataPoint *  glDataPointInitCopy    (GLDataPoint *point,
                                       const GLDataPoint *other);

GLDataPoint *  glDataPointCopy        (GLDataPoint *dest,
                                       const GLDataPoint *src);
GLDataBool     glDataPointEqual       (const GLDataPoint *point,
                                       const GLDataPoint *other);
GLDataBool     glDataPointNotEqual    (const GLDataPoint *point,
                                       const GLDataPoint *other);

/* Face */
#define        glDataFace(p)          ((GLDataFace *)(p))
GLDataFace *   glDataFaceInit         (GLDataFace *face,
                                       GLDataUInt npoints);
GLDataFace *   glDataFaceRetain       (GLDataFace *face);
void           glDataFaceRelease      (GLDataFace *face);
void           glDataFaceSetPoint     (GLDataFace *face,
                                       GLDataUInt index,
                                       GLDataUInt point);
void           glDataFaceSetPoints    (GLDataFace *face,
                                       GLDataUInt npoints,
                                       const GLDataUInt *points);

/* UV Polygon */
#define          glDataUVPolygon(p)        ((glDataUVPolygon *)(p))
GLDataUVPolygon *glDataUVPolygonInit       (GLDataUVPolygon *polygon,
                                            GLDataUInt npoints);
GLDataUVPolygon *glDataUVPolygonRetain     (GLDataUVPolygon *polygon);
void             glDataUVPolygonRelease    (GLDataUVPolygon *polygon);
GLDataUVPoint *  glDataUVPolygonGetPoint   (GLDataUVPolygon *polygon,
                                            GLDataUInt index);
void             glDataUVPolygonSetPoint   (GLDataUVPolygon *polygon,
                                            GLDataUInt index,
                                            GLDataUVPoint *point);


/* Polygon */
#define         glDataPolygon(p)        ((GLDataPolygon *)(p))
GLDataPolygon * glDataPolygonInit       (GLDataPolygon *polygon,
                                         GLDataUInt npoints);
GLDataPolygon * glDataPolygonRetain     (GLDataPolygon *polygon);
void            glDataPolygonRelease    (GLDataPolygon *polygon);
GLDataPoint *   glDataPolygonGetPoint   (GLDataPolygon *polygon,
                                         GLDataUInt index);
void            glDataPolygonSetPoint   (GLDataPolygon *polygon,
                                         GLDataUInt index,
                                         GLDataPoint *point);


/* Triangle */
#define         glDataTriangle(p)     ((GLDataTriangle *)(p))
GLDataTriangle *glDataTriangleInit    (GLDataTriangle *triangle,
                                       GLDataPoint *a,
                                       GLDataPoint *b,
                                       GLDataPoint *c);
GLDataTriangle *glDataTriangleRetain  (GLDataTriangle *triangle);
void            glDataTriangleRelease (GLDataTriangle *triangle);


/* Quad */
#define         glDataQuad(p)         ((GLDataQuad *)(p))
GLDataQuad *    glDataQuadInit        (GLDataQuad *quad,
                                       GLDataPoint *a,
                                       GLDataPoint *b,
                                       GLDataPoint *c,
                                       GLDataPoint *d);
GLDataQuad *    glDataQuadRetain      (GLDataQuad *quad);
void            glDataQuadRelease     (GLDataQuad *quad);


/* UV Surface */
#define          glDataUVSurface(p)         ((GLDataUVSurface *)(p))
GLDataUVSurface *glDataUVSurfaceInit        (GLDataUVSurface *surface,
                                             GLDataUInt npolygons);
GLDataUVSurface *glDataUVSurfaceRetain      (GLDataUVSurface *surface);
void             glDataUVSurfaceRelease     (GLDataUVSurface *surface);
GLDataUVPolygon *glDataUVSurfaceGetPolygon  (GLDataUVSurface *surface,
                                             GLDataUInt index);
void             glDataUVSurfaceSetPolygon  (GLDataUVSurface *surface,
                                             GLDataUInt index,
                                             GLDataUVPolygon *polygon);
void             glDataUVSurfaceSetPolygons (GLDataUVSurface *surface,
                                             GLDataUInt npolygons,
                                             GLDataUVPolygon **polygons);

/* Surface */
#define         glDataSurface(p)         ((GLDataSurface *)(p))
GLDataSurface * glDataSurfaceInit        (GLDataSurface *surface,
                                          GLDataUInt npolygons);
GLDataSurface * glDataSurfaceRetain      (GLDataSurface *surface);
void            glDataSurfaceRelease     (GLDataSurface *surface);
GLDataPolygon * glDataSurfaceGetPolygon  (GLDataSurface *surface,
                                          GLDataUInt index);
void            glDataSurfaceSetPolygon  (GLDataSurface *surface,
                                          GLDataUInt index,
                                          GLDataPolygon *polygon);
void            glDataSurfaceSetPolygons (GLDataSurface *surface,
                                          GLDataUInt npolygons,
                                          GLDataPolygon **polygons);

#endif /* !_GLDATA_OBJECTS_H_ */

