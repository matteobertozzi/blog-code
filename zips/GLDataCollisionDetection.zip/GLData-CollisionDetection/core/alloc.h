#ifndef _GLDATA_ALLOC_H_
#define _GLDATA_ALLOC_H_

void *__glDataAlloc  (unsigned int size, 
                      const char *file, int line, const char *func);
void *__glDataZAlloc (unsigned int size, 
                      const char *file, int line, const char *func);
void  __glDataFree   (void *ptr);

#define glDataAlloc(type)                           \
    ((type *) __glDataAlloc(sizeof(type),           \
                            __FILE__, __LINE__,     \
                            __PRETTY_FUNCTION__))

#define glDataZAlloc(type)                          \
    ((type *) __glDataZAlloc(sizeof(type),          \
                            __FILE__, __LINE__,     \
                            __PRETTY_FUNCTION__))

#define glDataAllocArray(type, n)                   \
    ((type *) __glDataAlloc((n) * sizeof(type),     \
                            __FILE__, __LINE__,     \
                            __PRETTY_FUNCTION__))

#define glDataZAllocArray(type, n)                  \
    ((type *) __glDataZAlloc((n) * sizeof(type),    \
                            __FILE__, __LINE__,     \
                            __PRETTY_FUNCTION__))

#define glDataFree(ptr)                       \
    __glDataFree(ptr)

#endif /* !_GLDATA_ALLOC_H_ */

