#include <string.h>
#include <ctype.h>

#include "strings.h"

char *glDataStringTrim (char *s) {
    size_t len = strlen(s);
    size_t lws;

    while (len && isspace(s[len - 1]))
        --len;

    if (len) {
        lws = strspn(s, " \t\n\r\v");
        len -= lws;
        memmove(s, s + lws, len);
    }

    s[len] = '\0';
    return(len == 0 ? NULL : s);
}

GLDataBool glDataStringEndsWith (const char *s, const char *suffix) {
    size_t l1 = strlen(s);
    size_t l2 = strlen(suffix);
    return(l1 < l2 ? GLDATA_FALSE : !strcmp(s + l1 - l2, suffix));
}

