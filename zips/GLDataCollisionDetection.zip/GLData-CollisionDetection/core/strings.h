#ifndef _GLDATA_STRING_H_
#define _GLDATA_STRING_H_

#include <GLData/Types.h>

char *     glDataStringTrim     (char *s);
GLDataBool glDataStringEndsWith (const char *s, const char *suffix);

#endif /* !_GLDATA_STRING_H_ */

