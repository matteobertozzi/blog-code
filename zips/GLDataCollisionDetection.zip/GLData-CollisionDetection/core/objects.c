#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "objects.h"
#include "assert.h"

#if defined(GLDATA_DEBUG)
    #define glDataDebug(x)          fprintf(stderr, x)
#else
    #define glDataDebug(x)          if (1) {} else fprintf(stderr, x)
#endif

/**
 * ===========================================================================
 * GLDataType:
 * Base class for all GLData Objects. 
 * It contains helper for Retain/Release Allocation Model.
 */
GLDataType *_glDataInit (GLDataType *data, GLDataBool internalAlloc) {
    data->retainCount = 1;
    data->internalAlloc = internalAlloc;
    return(data);
}

GLDataType *_glDataRetain (GLDataType *data) {
    data->retainCount++;
    return(data);
}

GLDataBool _glDataRelease (GLDataType *data) {
    return((--(data->retainCount)) == 0);
}

GLDataUInt glDataGetRetainCount (GLDataType *data) {
    return(data->retainCount);
}

GLDataBool _glDataInternalAlloc (GLDataType *data) {
    return(data->internalAlloc);
}

/**
 * GLDataUVPoint:
 * Represents a 2d Point (UV).
 */
GLDataUVPoint *glDataUVPointAlloc (void) {
    GLDataUVPoint *uv;

    uv = glDataAlloc(GLDataUVPoint);
    glDataReturnValueIfNull(uv, NULL);

    uv->x = 0;
    uv->y = 0;

    return(uv);
}

void glDataUVPointRelease (GLDataUVPoint *uv) {
    if (uv != NULL)
        glDataFree(uv);
}

GLDataUVPoint *glDataUVPointInit (GLDataUVPoint *uv,
                                  GLDataFloat x,
                                  GLDataFloat y)
{
    glDataReturnValueIfNull(uv, NULL);

    uv->x = x;
    uv->y = y;

    return(uv);
}

GLDataUVPoint *glDataUVPointInitCopy (GLDataUVPoint *uv,
                                      const GLDataUVPoint *other)
{
    glDataReturnValueIfNull(uv, NULL);
    glDataReturnValueIfNull(other, NULL);

    uv->x = other->x;
    uv->y = other->y;

    return(uv);
}

GLDataUVPoint *glDataUVPointCopy (GLDataUVPoint *dest,
                                  const GLDataUVPoint *src)
{
    glDataReturnValueIfNull(dest, NULL);
    glDataReturnValueIfNull(src, dest);

    dest->x = src->x;
    dest->y = src->y;
    return(dest);
}

GLDataBool glDataUVPointEqual (const GLDataUVPoint *point,
                               const GLDataUVPoint *other)
{
    glDataReturnValueIfNull(point, GLDATA_FALSE);
    glDataReturnValueIfNull(other, GLDATA_FALSE);
    return((point->x != other->x) && (point->y != other->y));
}

GLDataBool glDataUVPointNotEqual (const GLDataUVPoint *point,
                                  const GLDataUVPoint *other)
{
    return(!glDataUVPointNotEqual(point, other));
}

/**
 * ===========================================================================
 * GLDataPoint: 
 * Represents a 3d point.
 */
GLDataPoint *glDataPointAlloc (void) {
    GLDataPoint *point;

    point = glDataAlloc(GLDataPoint);
    glDataReturnValueIfNull(point, NULL);

    point->x = 0;
    point->y = 0;

    return(point);
}

void glDataPointRelease (GLDataPoint *point) {
    if (point != NULL)
        glDataFree(point);
}

GLDataPoint *glDataPointInit (GLDataPoint *point,
                              GLDataFloat x,
                              GLDataFloat y,
                              GLDataFloat z)
{
    glDataReturnValueIfNull(point, NULL);

    point->x = x;
    point->y = y;
    point->z = z;

    return(point);
}

GLDataPoint *glDataPointInitCopy (GLDataPoint *point,
                                  const GLDataPoint *other)
{
    glDataReturnValueIfNull(point, NULL);
    glDataReturnValueIfNull(other, NULL);

    point->x = other->x;
    point->y = other->y;
    point->z = other->z;

    return(point);
}

GLDataPoint *glDataPointCopy (GLDataPoint *dest,
                              const GLDataPoint *src)
{
    glDataReturnValueIfNull(dest, NULL);
    glDataReturnValueIfNull(src, dest);

    dest->x = src->x;
    dest->y = src->y;
    dest->z = src->z;
    return(dest);
}

GLDataBool glDataPointEqual (const GLDataPoint *point,
                             const GLDataPoint *other)
{
    glDataReturnValueIfNull(point, GLDATA_FALSE);
    glDataReturnValueIfNull(other, GLDATA_FALSE);

    return((point->x != other->x) && 
           (point->y != other->y) && 
           (point->z != other->z));
}

GLDataBool glDataPointNotEqual (const GLDataPoint *point,
                                const GLDataPoint *other)
{
    return(!glDataPointEqual(point, other));
}

/**
 * ===========================================================================
 * GLDataFace: 
 * Represents a 3d Face.
 */
GLDataFace *glDataFaceInit (GLDataFace *face,
                            GLDataUInt npoints)
{
    GLDataBool internalAlloc = (face == NULL);
    if (face == NULL) face = glDataAlloc(GLDataFace);
    glDataReturnValueIfNull(face, NULL);    
    _glDataInit(glDataGetBase(face), internalAlloc);
    
    face->points = glDataAllocArray(GLDataUInt, npoints);
    face->npoints = npoints;

    return(face);
}

GLDataFace *glDataFaceRetain (GLDataFace *face) {
    glDataReturnValueIfNull(face, NULL);

    _glDataRetain(glDataGetBase(face));
    return(face);
}

void glDataFaceRelease (GLDataFace *face) {
    glDataReturnIfNull(face);
    glDataReturnIfFalse(_glDataRelease(glDataGetBase(face)));

    glDataFree(face->points);

    if (_glDataInternalAlloc(glDataGetBase(face)))
        glDataFree(face);
}

void glDataFaceSetPoint (GLDataFace *face,
                         GLDataUInt index,
                         GLDataUInt point)
{
    glDataReturnIfNull(face);
    face->points[index] = point;
}

void glDataFaceSetPoints (GLDataFace *face,
                          GLDataUInt npoints,
                          const GLDataUInt *points)
{
    GLDataUInt i;

    glDataReturnIfNull(face);

    for (i = 0; i < npoints; ++i)
        face->points[i] = points[i];
}


/**
 * ===========================================================================
 * GLDataPolygon: 
 * Represents a 3d Polygon.
 */
GLDataUVPolygon *glDataUVPolygonInit (GLDataUVPolygon *polygon,
                                      GLDataUInt npoints)
{
    GLDataBool internalAlloc = (polygon == NULL);
    if (polygon == NULL) polygon = glDataAlloc(GLDataUVPolygon);
    glDataReturnValueIfNull(polygon, NULL);
    _glDataInit(glDataGetBase(polygon), internalAlloc);
    
    polygon->points = glDataZAllocArray(GLDataUVPoint, npoints);
    polygon->npoints = npoints;

    return(polygon);
}

GLDataUVPolygon *glDataUVPolygonRetain (GLDataUVPolygon *polygon) {
    glDataReturnValueIfNull(polygon, NULL);

    _glDataRetain(glDataGetBase(polygon));
    return(polygon);
}

void glDataUVPolygonRelease (GLDataUVPolygon *polygon) {
    glDataReturnIfNull(polygon);
    glDataReturnIfFalse(_glDataRelease(glDataGetBase(polygon)));

    glDataFree(polygon->points);

    if (_glDataInternalAlloc(glDataGetBase(polygon)))
        glDataFree(polygon);
}

GLDataUVPoint *glDataUVPolygonGetPoint (GLDataUVPolygon *polygon,
                                        GLDataUInt index)
{
    glDataReturnValueIfNull(polygon, NULL);
    return(&(polygon->points[index]));
}

void glDataUVPolygonSetPoint (GLDataUVPolygon *polygon,
                              GLDataUInt index,
                              GLDataUVPoint *point)
{
    glDataReturnIfNull(polygon);

    glDataUVPointInitCopy(&(polygon->points[index]), point);
}

/**
 * ===========================================================================
 * GLDataPolygon: 
 * Represents a 3d Polygon.
 */
GLDataPolygon *glDataPolygonInit (GLDataPolygon *polygon,
                                  GLDataUInt npoints)
{
    GLDataBool internalAlloc = (polygon == NULL);
    if (polygon == NULL) polygon = glDataAlloc(GLDataPolygon);
    glDataReturnValueIfNull(polygon, NULL);
    _glDataInit(glDataGetBase(polygon), internalAlloc);

    polygon->points = glDataZAllocArray(GLDataPoint, npoints);
    polygon->npoints = npoints;

    return(polygon);
}

GLDataPolygon *glDataPolygonRetain (GLDataPolygon *polygon) {
    glDataReturnValueIfNull(polygon, NULL);

    _glDataRetain(glDataGetBase(polygon));
    return(polygon);
}

void glDataPolygonRelease (GLDataPolygon *polygon) {
    glDataReturnIfNull(polygon);
    glDataReturnIfFalse(_glDataRelease(glDataGetBase(polygon)));

    glDataFree(polygon->points);

    if (_glDataInternalAlloc(glDataGetBase(polygon)))
        glDataFree(polygon);
}

GLDataPoint *glDataPolygonGetPoint (GLDataPolygon *polygon,
                                    GLDataUInt index)
{
    glDataReturnValueIfNull(polygon, NULL);
    return(&(polygon->points[index]));
}

void glDataPolygonSetPoint (GLDataPolygon *polygon,
                            GLDataUInt index,
                            GLDataPoint *point)
{
    glDataReturnIfNull(polygon);

    glDataPointInitCopy(&(polygon->points[index]), point);
}

/**
 * ===========================================================================
 * GLDataTriangle: 
 * Represents a 3d Triangle, It's a specialization of Polygon.
 */
GLDataTriangle *glDataTriangleInit (GLDataTriangle *triangle,
                                    GLDataPoint *a,
                                    GLDataPoint *b,
                                    GLDataPoint *c)
{
    if (glDataPolygonInit((GLDataPolygon *)triangle, 3)) {
        glDataPolygonSetPoint((GLDataPolygon *)triangle, 0, a);
        glDataPolygonSetPoint((GLDataPolygon *)triangle, 1, b);
        glDataPolygonSetPoint((GLDataPolygon *)triangle, 2, c);
    }

    return(triangle);
}

GLDataTriangle *glDataTriangleRetain (GLDataTriangle *triangle) {
    return(glDataPolygonRetain((GLDataPolygon *)triangle));
}

void glDataTriangleRelease (GLDataTriangle *triangle) {
    glDataPolygonRelease((GLDataPolygon *)triangle);
}

/**
 * ===========================================================================
 * GLDataQuad: 
 * Represents a 3d Quad, It's a specialization of Polygon.
 */
GLDataQuad *glDataQuadInit (GLDataQuad *quad,
                            GLDataPoint *a,
                            GLDataPoint *b,
                            GLDataPoint *c,
                            GLDataPoint *d)
{
    if (glDataPolygonInit((GLDataPolygon *)quad, 4)) {
        glDataPolygonSetPoint((GLDataPolygon *)quad, 0, a);
        glDataPolygonSetPoint((GLDataPolygon *)quad, 1, b);
        glDataPolygonSetPoint((GLDataPolygon *)quad, 2, c);
        glDataPolygonSetPoint((GLDataPolygon *)quad, 3, d);
    }

    return(quad);
}

GLDataQuad *glDataQuadRetain (GLDataQuad *quad) {
    return(glDataPolygonRetain((GLDataPolygon *)quad));
}

void glDataQuadRelease (GLDataQuad *quad) {
    glDataPolygonRelease((GLDataPolygon *)quad);
}

/**
 * ===========================================================================
 * GLDataSurface: 
 * Represents a 3d Surface, It's a collection of Polygons.
 */
GLDataUVSurface *glDataUVSurfaceInit (GLDataUVSurface *surface,
                                      GLDataUInt npolygons)
{
    GLDataBool internalAlloc = (surface == NULL);
    if (surface == NULL) surface = glDataAlloc(GLDataUVSurface);
    glDataReturnValueIfNull(surface, NULL);
    _glDataInit(glDataGetBase(surface), internalAlloc);

    surface->polygons = glDataZAllocArray(GLDataUVPolygon *, npolygons);
    surface->npolygons = npolygons;

    return(surface);
}

GLDataUVSurface *glDataUVSurfaceRetain (GLDataUVSurface *surface) {
    glDataReturnValueIfNull(surface, NULL);

    _glDataRetain(glDataGetBase(surface));
    return(surface);
}

void glDataUVSurfaceRelease (GLDataUVSurface *surface) {
    GLDataUInt i;

    glDataReturnIfNull(surface);
    glDataReturnIfFalse(_glDataRelease(glDataGetBase(surface)));

    for (i = 0; i < surface->npolygons; ++i)
        glDataUVPolygonRelease(surface->polygons[i]);

    glDataFree(surface->polygons);

    if (_glDataInternalAlloc(glDataGetBase(surface)))
        glDataFree(surface);
}

GLDataUVPolygon *glDataUVSurfaceGetPolygon (GLDataUVSurface *surface,
                                            GLDataUInt index)
{
    glDataReturnValueIfNull(surface, NULL);
    return(surface->polygons[index]);
}

void glDataUVSurfaceSetPolygon (GLDataUVSurface *surface,
                                GLDataUInt index,
                                GLDataUVPolygon *polygon)
{
    glDataReturnIfNull(surface);

    surface->polygons[index] = glDataUVPolygonRetain(polygon);
}

void glDataUVSurfaceSetPolygons (GLDataUVSurface *surface,
                                 GLDataUInt npolygons,
                                 GLDataUVPolygon **polygons)
{
    GLDataUInt i;

    glDataReturnIfNull(surface);

    for (i = 0; i < npolygons; ++i)
        surface->polygons[i] = glDataUVPolygonRetain(polygons[i]);
}

/**
 * ===========================================================================
 * GLDataSurface: 
 * Represents a 3d Surface, It's a collection of Polygons.
 */
GLDataSurface *glDataSurfaceInit (GLDataSurface *surface,
                                  GLDataUInt npolygons)
{
    GLDataBool internalAlloc = (surface == NULL);
    if (surface == NULL) surface = glDataAlloc(GLDataSurface);
    glDataReturnValueIfNull(surface, NULL);
    _glDataInit(glDataGetBase(surface), internalAlloc);

    surface->polygons = glDataZAllocArray(GLDataPolygon *, npolygons);
    surface->npolygons = npolygons;

    return(surface);
}

GLDataSurface *glDataSurfaceRetain (GLDataSurface *surface) {
    glDataReturnValueIfNull(surface, NULL);

    _glDataRetain(glDataGetBase(surface));
    return(surface);
}

void glDataSurfaceRelease (GLDataSurface *surface) {
    GLDataUInt i;

    glDataReturnIfNull(surface);
    glDataReturnIfFalse(_glDataRelease(glDataGetBase(surface)));

    for (i = 0; i < surface->npolygons; ++i)
        glDataPolygonRelease(surface->polygons[i]);

    glDataFree(surface->polygons);

    if (_glDataInternalAlloc(glDataGetBase(surface)))
        glDataFree(surface);
}

GLDataPolygon *glDataSurfaceGetPolygon (GLDataSurface *surface,
                                        GLDataUInt index)
{
    glDataReturnValueIfNull(surface, NULL);
    return(surface->polygons[index]);
}

void glDataSurfaceSetPolygon (GLDataSurface *surface,
                              GLDataUInt index,
                              GLDataPolygon *polygon)
{
    glDataReturnIfNull(surface);

    surface->polygons[index] = glDataPolygonRetain(polygon);
}

void glDataSurfaceSetPolygons (GLDataSurface *surface,
                               GLDataUInt npolygons,
                               GLDataPolygon **polygons)
{
    GLDataUInt i;

    glDataReturnIfNull(surface);

    for (i = 0; i < npolygons; ++i)
        surface->polygons[i] = glDataPolygonRetain(polygons[i]);
}

