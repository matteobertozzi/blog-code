#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>

#include "assert.h"

/**
 * Prints specified message on the stderr.
 */
void glDataWarning (const char *format, ...) {
    va_list arg_list;

    va_start(arg_list, format);
    vfprintf(stderr, format, arg_list);
    va_end(arg_list);
}

/**
 * Prints specified message on stderr and call abort().
 */
void glDataError (const char *format, ...) {
    va_list arg_list;

    va_start(arg_list, format);
    vfprintf(stderr, format, arg_list);
    va_end(arg_list);

    abort();
}

/**
 * Used internally by GLDATA_ASSERT() and GLDATA_ASSERT_HINT(). 
 * Prints out some information before abort() if expression result is false.
 */
void glDataAssert (const char *hint, int expr, const char *text,
                   const char *file, int line, const char *func)
{
    glDataReturnIfTrue(expr);

    if (hint != NULL) {
        glDataError("%s: Assertion (%s) at %s:%d in function %s() failed.\n",
                    hint, text, file, line, func);
    } else {
        glDataError("Assertion (%s) at %s:%d in function %s() failed.\n",
                    text, file, line, func);
    }
}

