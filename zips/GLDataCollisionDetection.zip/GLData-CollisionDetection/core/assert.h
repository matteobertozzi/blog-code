#ifndef _GLDATA_ASSERT_H_
#define _GLDATA_ASSERT_H_

#include <GLData/Alloc.h>
#include <GLData/Types.h>

#define glDataReturnIfTrue(expr)                    \
    if (expr) return

#define glDataReturnIfFalse(expr)                   \
    if (!(expr)) return

#define glDataReturnIfNull(ptr)                     \
    if ((ptr) == NULL) return

#define glDataReturnValueIfTrue(expr, retval)       \
    if (expr) return(retval)

#define glDataReturnValueIfFalse(expr, retval)      \
    if (!(expr)) return(retval)

#define glDataReturnValueIfNull(ptr, retval)       \
    if ((ptr) == NULL) return(retval)

void glDataAssert (const char *hint, int expr, const char *text,
                   const char *file, int line, const char *func);

#define GLDATA_ASSERT(expr)                         \
    do {                                            \
        glDataAssert(NULL, expr, #expr,             \
                     __FILE__, __LINE__,            \
                     __PRETTY_FUNCTION__);          \
    } while(0)

#define GLDATA_ASSERT_HINT(expr, hint)              \
    do {                                            \
        glDataAssert(hint, expr, #expr,             \
                     __FILE__, __LINE__,            \
                     __PRETTY_FUNCTION__);          \
    } while(0)

void glDataWarning (const char *format, ...);
void glDataError (const char *format, ...);

#endif /* !_GLDATA_ASSERT_H_ */

