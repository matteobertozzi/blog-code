#ifndef _GLDATA_TYPES_H_
#define _GLDATA_TYPES_H_

#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>

typedef uint64_t    GLDataUInt64;
typedef uint32_t    GLDataUInt32;
typedef uint16_t    GLDataUInt16;
typedef uint8_t     GLDataUInt8;

typedef int64_t     GLDataInt64;
typedef int32_t     GLDataInt32;
typedef int16_t     GLDataInt16;
typedef int8_t      GLDataInt8;

typedef void        GLDataVoid;
typedef uint8_t     GLDataByte;
typedef uint32_t    GLDataUInt;
typedef int32_t     GLDataInt;

typedef double      GLDataDouble;
typedef float       GLDataFloat;

#define GLDATA_FALSE        (0)
#define GLDATA_TRUE         (1)
typedef uint8_t     GLDataBool;

#define glDataBool(p)           ((GLDataBool *)(p))
#define glDataBoolValue(p)      (*glDataBool(p))

typedef void (*GLDataReleaseFunc) (void *p);

#endif /* !_GLDATA_TYPES_H_ */

