#ifndef _GLDATA_PNG_H_
#define _GLDATA_PNG_H_

#include <GLData/ImageReader.h>
#include <GLData/Image.h>
#include <GLData/Types.h>

extern GLDataImageReaderFormat glDataImagePngReader;

GLDataBool glDataImageIsPng     (FILE *fh);
GLDataBool glDataImageLoadPng   (GLDataImage *image, FILE *fh);

#endif /* !_GLDATA_PNG_H_ */
