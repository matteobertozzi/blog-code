#include "imagebmp.h"
#include "assert.h"

/**
 * Returns true if specified file is Bitmap.
 */
GLDataBool glDataImageIsBmp (FILE *fh) {
    unsigned char magic[2];

    fseek(fh, 0, SEEK_SET);
    if (fread(magic, sizeof(unsigned char), 2, fh) != 2)
        return(GLDATA_FALSE);

    return(!memcmp(magic, "BM", 2));
}

/**
 * Returns True and fill Image Data Structure with specified file.
 */
GLDataBool glDataImageLoadBmp (GLDataImage *image, FILE *fh) {
    GLDataUInt32 width, height;
    GLDataUInt16 planes, bpp;
    GLDataUInt32 i, blobSize;
    GLDataByte color;
    GLDataByte *blob;

    /* Seek through the BMP header */
    fseek(fh, 18, SEEK_SET);

    /* Read Width/Height */
    if (fread(&width, sizeof(GLDataUInt32), 1, fh) != 1)
        return(GLDATA_FALSE);

    if (fread(&height, sizeof(GLDataUInt32), 1, fh) != 1)
        return(GLDATA_FALSE);

    /* Read the Planes, MUST BE 1 */
    if (fread(&planes, sizeof(GLDataUInt16), 1, fh) != 1)
        return(GLDATA_FALSE);

    glDataReturnValueIfFalse(planes == 1, GLDATA_FALSE);

    /* Read the BPP, MUST BE 24 */
    if (fread(&bpp, sizeof(GLDataUInt16), 1, fh) != 1)
        return(GLDATA_FALSE);

    glDataReturnValueIfFalse(bpp == 24, GLDATA_FALSE);

    /* Skip the Rest of the Header */
    fseek(fh, 24, SEEK_CUR);

    /* Calculate Blob Size */
    blobSize = (width * height * 3);

    /* Alloc Image Blob */
    blob = glDataAllocArray(GLDataByte, blobSize);
    glDataReturnValueIfNull(blob, GLDATA_FALSE);

    /* Read Image Blob */
    if (fread(blob, blobSize, 1, fh) != 1) {
        glDataFree(blob);
        return(GLDATA_FALSE);
    }

    /* Reverse all the Colors (BGR -> RGB) */
    for (i = 0; i < blobSize; i += 3) {
        color = blob[i];
        blob[i] = blob[i + 2];
        blob[i + 2] = color;
    }

    /* Setup Image */
    glDataImageSetFormat(image, GLDATA_IMAGE_FORMAT_RGB);
    glDataImageSetSize(image, width, height);
    glDataImageSetData(image, blob, blobSize);

    return(GLDATA_TRUE);
}

GLDataImageReaderFormat glDataImageBmpReader = {
    .name = "BMP",
    .isImageFormat = glDataImageIsBmp,
    .loadImageFormat = glDataImageLoadBmp,
    .loadMipMapFormat = NULL    
};

