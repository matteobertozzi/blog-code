#include <png.h>

#include "imagepng.h"
#include "assert.h"

/**
 * Returns true if specified file is PNG.
 */
GLDataBool glDataImageIsPng (FILE *fh) {
    unsigned char sig[8];

    fseek(fh, 0, SEEK_SET);

    if (fread(sig, sizeof(unsigned char), 8, fh) != 8)
        return(GLDATA_FALSE);

    return(png_check_sig(sig, 8));
}

/**
 * Returns True and fill Image Data Structure with specified file.
 */
GLDataBool glDataImageLoadPng (GLDataImage *image, FILE *fh) {
    png_uint_32 width, height;
    png_uint_32 i, rowBytes;
    png_bytepp rowPointers;
    int bitDepth, color;
    GLDataByte *blob;   
    png_structp png;
    png_infop info;

    /* Create PNG Read Struct */
    png = png_create_read_struct(PNG_LIBPNG_VER_STRING, 0, 0, 0);
    glDataReturnValueIfNull(png, GLDATA_FALSE);

    /* Create Info Struct */
    if (!(info = png_create_info_struct(png))) {
        png_destroy_read_struct(&png, NULL, NULL);
        return(GLDATA_FALSE);
    }

    setjmp(png_jmpbuf(png));

    png_init_io(png, fh);
    png_set_sig_bytes(png, 8);
    png_read_info(png, info);
    png_get_IHDR(png, info, &width, &height, &bitDepth, &color, 0, 0, 0);

	switch (png_get_color_type(png, info)) {
		case PNG_COLOR_TYPE_PALETTE:
            png_set_palette_to_rgb(png);
			break;
		case PNG_COLOR_TYPE_GRAY:
            png_set_gray_to_rgb(png);
			break;
		case PNG_COLOR_TYPE_GRAY_ALPHA:
			break;
		case PNG_COLOR_TYPE_RGB:
            if(png_get_valid(png, info, PNG_INFO_tRNS))
                png_set_tRNS_to_alpha(png);
            else
                png_set_filler(png, 0xff, PNG_FILLER_AFTER);
			break;
		case PNG_COLOR_TYPE_RGB_ALPHA:
			break;
		default:
            break;
	}

    if (bitDepth > 8)
        png_set_strip_16(png);

    png_read_update_info(png, info);

    /* Alloc Image Blob */
    rowBytes = png_get_rowbytes(png, info);
    blob = glDataAllocArray(GLDataByte, width * height * 4);
    glDataReturnValueIfNull(blob, GLDATA_FALSE);

    /* Alloc Row Pointers */
    if (!(rowPointers = glDataAllocArray(png_bytep, height))) {
        glDataFree(blob);
        return(GLDATA_FALSE);
    }

    /* Setup Row Pointers */
    for (i = 0; i < height; ++i)
        rowPointers[height - 1 - i] = (png_bytep) blob + i * (width * 4);

    /* Read the Whole Image */
    png_read_image(png, rowPointers);

    /* Free PNG Resources */
    glDataFree(rowPointers);
    png_destroy_read_struct(&png, &info, NULL);

    /* Setup Image */
    glDataImageSetFormat(image, GLDATA_IMAGE_FORMAT_RGBA); 
    glDataImageSetSize(image, width, height);
    glDataImageSetData(image, blob, rowBytes * height);

    return(GLDATA_TRUE);
}

GLDataBool glDataMipMapLoadPng (GLDataMipMap *mipMap, FILE *fh) {
    GLDataImage *image;

    glDataMipMapInit(mipMap, 1);
    image = glDataMipMapImage(mipMap, 0);
    glDataImageLoadPng(image, fh);

    return(GLDATA_TRUE);
}

GLDataImageReaderFormat glDataImagePngReader = {
    .name = "PNG",
    .isImageFormat = glDataImageIsPng,
    .loadImageFormat = glDataImageLoadPng,
    .loadMipMapFormat = glDataMipMapLoadPng
};

