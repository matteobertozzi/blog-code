#ifndef _GLDATA_BMP_H_
#define _GLDATA_BMP_H_

#include <GLData/ImageReader.h>
#include <GLData/Image.h>
#include <GLData/Types.h>

extern GLDataImageReaderFormat glDataImageBmpReader;

GLDataBool glDataImageIsBmp     (FILE *fh);
GLDataBool glDataImageLoadBmp   (GLDataImage *image, FILE *fh);

#endif /* !_GLDATA_BMP_H_ */
