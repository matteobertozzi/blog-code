#ifndef _GLDATA_IMAGE_READER_H_
#define _GLDATA_IMAGE_READER_H_

#include <GLData/Image.h>
#include <GLData/Types.h>

typedef struct {
    const char *name;
    GLDataBool (*isImageFormat)    (FILE *fh);
    GLDataBool (*loadImageFormat)  (GLDataImage *mipMap, FILE *fh);
    GLDataBool (*loadMipMapFormat) (GLDataMipMap *mipMap, FILE *fh);
} GLDataImageReaderFormat;

#define glDataImageReaderFormat(p)      ((GLDataImageReaderFormat *)(p))

void glDataImageReaderRegisterFormat (GLDataImageReaderFormat *format);

GLDataBool glDataImageFromFile  (GLDataImage *image, const char *filename);
GLDataBool glDataMipMapFromFile (GLDataMipMap *mipMap, const char *filename);

#endif /* !_GLDATA_IMAGE_READER_H_ */

