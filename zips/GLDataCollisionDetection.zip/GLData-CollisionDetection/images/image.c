#include "assert.h"
#include "alloc.h"
#include "image.h"

void glDataImageRelease (GLDataImage *image) {
    glDataFree(image->blob);
}

GLDataMipMap *glDataMipMapAlloc (void) {
    GLDataMipMap *mipMap;

    mipMap = glDataAlloc(GLDataMipMap);
    glDataReturnValueIfNull(mipMap, NULL);

    mipMap->images = NULL;
    mipMap->numMipMaps = 0;

    return(mipMap);
}

GLDataMipMap *glDataMipMapInit (GLDataMipMap *mipMap, GLDataUInt numMipMaps) {
    mipMap->images = glDataAllocArray(GLDataImage, numMipMaps);
    mipMap->numMipMaps = numMipMaps;
    return(mipMap);
}

void glDataMipMapRelease (GLDataMipMap *mipMap) {
    GLDataUInt i;

    glDataReturnIfNull(mipMap);

    for (i = 0; i < mipMap->numMipMaps; ++i)
        glDataImageRelease(&(mipMap->images[i]));

    glDataFree(mipMap->images);
    glDataFree(mipMap);
}

GLDataImage *glDataMipMapImage (GLDataMipMap *mipMap, GLDataUInt level) {
    return(&(mipMap->images[level]));
}

