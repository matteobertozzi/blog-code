#include "imagereader.h"
#include "list.h"

#include "private/imagebmp.h"
#include "private/imagepng.h"

typedef struct {
    GLDataList *formats;
} GLDataImageReader;

static GLDataImageReader __globalImageReader = {
    .formats = NULL
};

GLDataImageReader *glDataImageReaderInstance (void) {
    if (__globalImageReader.formats == NULL) {
        __globalImageReader.formats = glDataListAlloc();
        glDataListAppend(__globalImageReader.formats, &glDataImagePngReader);
        glDataListAppend(__globalImageReader.formats, &glDataImageBmpReader);
    }
    return(&__globalImageReader);
}

void glDataImageReaderRegisterFormat (GLDataImageReaderFormat *format) {
    glDataListAppend(glDataImageReaderInstance()->formats, format);    
}

GLDataBool glDataImageFromFile (GLDataImage *image, const char *filename) {
    GLDataBool success = GLDATA_FALSE;
    GLDataImageReaderFormat *f;
    GLDataImageReader *reader;
    GLDataUInt i, n;
    FILE *fh;

    if ((fh = fopen(filename, "rb")) == NULL)
        return(GLDATA_FALSE);

    reader = glDataImageReaderInstance();
    n = glDataListSize(reader->formats);
    for (i = 0; i < n; ++i) {
        f = glDataImageReaderFormat(glDataListAt(reader->formats, i));

        /* Check if this Format Plugin is Compatible */
        if (f->loadImageFormat == NULL || !f->isImageFormat(fh))
            continue;

        /* Try Load Image with this Plugin */
        if ((success = f->loadImageFormat(image, fh)))
            break;
    }

    fclose(fh);
    return(success);
}

GLDataBool glDataMipMapFromFile (GLDataMipMap *mipMap, const char *filename) {
    GLDataBool success = GLDATA_FALSE;
    GLDataImageReaderFormat *f;
    GLDataImageReader *reader;
    GLDataUInt i, n;
    FILE *fh;

    if ((fh = fopen(filename, "rb")) == NULL)
        return(GLDATA_FALSE);
    printf("%s\n", filename);

    reader = glDataImageReaderInstance();
    n = glDataListSize(reader->formats);
    for (i = 0; i < n; ++i) {
        f = glDataImageReaderFormat(glDataListAt(reader->formats, i));

        /* Check if this Format Plugin is Compatible */
        if (f->loadMipMapFormat == NULL || !f->isImageFormat(fh))
            continue;

        /* Try Load MipMap with this Plugin */
        if ((success = f->loadMipMapFormat(mipMap, fh)))
            break;
    }

    fclose(fh);
    return(success);
}

