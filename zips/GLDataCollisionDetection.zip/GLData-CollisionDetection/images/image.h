#ifndef _GLDATA_IMAGE_H_
#define _GLDATA_IMAGE_H_

#include <GLData/Types.h>

typedef enum {
    GLDATA_IMAGE_FORMAT_UNKNOWN,
    GLDATA_IMAGE_FORMAT_RGB,
    GLDATA_IMAGE_FORMAT_RGBA
} GLDataImageFormat;

typedef struct {
    GLDataImageFormat format;
    GLDataUInt  height;
    GLDataUInt  width;
    GLDataByte *blob;
    GLDataUInt  size;
} GLDataImage;

typedef struct {
    GLDataImage *images;
    GLDataUInt numMipMaps;
} GLDataMipMap;

#define glDataImage(p)                    ((GLDataImage *)(p))
#define glDataImageData(image_ptr)        ((image_ptr)->blob)
#define glDataImageWidth(image_ptr)       ((image_ptr)->width)
#define glDataImageHeight(image_ptr)      ((image_ptr)->height)
#define glDataImageFormat(image_ptr)      ((image_ptr)->format)

#define glDataImageSetSize(image_ptr, w, h)            \
    do {                                               \
        (image_ptr)->height = (h);                     \
        (image_ptr)->width = (w);                      \
    } while (0)

#define glDataImageSetFormat(image_ptr, frmt)          \
    do {                                               \
        (image_ptr)->format = (frmt);                  \
    } while (0)

#define glDataImageSetData(image_ptr, data, dataSize)  \
    do {                                               \
        (image_ptr)->blob = (data);                    \
        (image_ptr)->size = (dataSize);                \
    } while (0)

void glDataImageRelease (GLDataImage *image);

GLDataMipMap *glDataMipMapAlloc   (void);
GLDataMipMap *glDataMipMapInit    (GLDataMipMap *mipMap, GLDataUInt numMipMaps);
void          glDataMipMapRelease (GLDataMipMap *mipMap);

GLDataImage * glDataMipMapImage   (GLDataMipMap *mipMap, GLDataUInt level);

#endif /* !_GLDATA_IMAGE_H_ */

