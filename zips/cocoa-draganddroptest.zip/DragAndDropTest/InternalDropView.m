//
//  InternalDropView.m
//  DragAndDropTest
//
//  Created by Matteo Bertozzi on 2/28/09.
//  Copyright 2009 Matteo Bertozzi. All rights reserved.
//

#import "InternalDropView.h"
#import "NSImageUtils.h"

@implementation InternalDropView

- (id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
		[self registerForDraggedTypes:[NSArray arrayWithObjects:
										@"MyDragType", nil]];
		draggedImage = nil;
    }
    return self;
}

- (void)drawRect:(NSRect)rect {
	int centerX = rect.size.width / 2;
	
	if (draggedImage != nil) {
		NSImage *image = [draggedImage imageByScalingProportionallyToSize:rect.size];
		CGFloat imageCenterX = centerX - [image size].width / 2;
		CGFloat imageWidth = [image size].width;
		CGFloat imageHeigth = [image size].height;
		
		[image drawAtPoint:NSMakePoint(imageCenterX, 0) fromRect:NSMakeRect(0, 0, imageWidth, imageHeigth) operation:NSCompositeSourceOver fraction:1.0];
	}
}


- (NSDragOperation)draggingEntered:(id <NSDraggingInfo>)sender {
    NSPasteboard *pboard;
    NSDragOperation sourceDragMask;
 
    sourceDragMask = [sender draggingSourceOperationMask];
    pboard = [sender draggingPasteboard];
 
    if ( [[pboard types] containsObject:@"MyDragType"] ) {
        if (sourceDragMask & NSDragOperationLink) {
            return NSDragOperationLink;
        } else if (sourceDragMask & NSDragOperationCopy) {
            return NSDragOperationCopy;
        }
    }
    return NSDragOperationNone;
}

- (BOOL)performDragOperation:(id <NSDraggingInfo>)sender {
    NSPasteboard *pboard;
    NSDragOperation sourceDragMask;
 
    sourceDragMask = [sender draggingSourceOperationMask];
    pboard = [sender draggingPasteboard];
 
	if ([[pboard types] containsObject:@"MyDragType"]) {
		NSData *data = [pboard dataForType:@"MyDragType"];
		draggedImage = [[NSImage alloc] initWithData:data];

        [self setNeedsDisplay:YES];
    }
    return YES;
}


@end
