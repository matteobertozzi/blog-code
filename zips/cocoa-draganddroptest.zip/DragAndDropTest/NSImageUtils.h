//
//  NSImageUtils.h
//  DragAndDropTest
//
//  Created by Matteo Bertozzi on 2/28/09.
//  Copyright 2009 Matteo Bertozzi. All rights reserved.
//

@interface NSImage (Utils)

- (NSImage *)imageByScalingProportionallyToSize:(NSSize)aSize;

@end
