//
//  AppController.m
//  DragAndDropTest
//
//  Created by Matteo Bertozzi on 2/28/09.
//  Copyright 2009 Matteo Bertozzi. All rights reserved.
//

#import "AppController.h"
#import "FileDropView.h"

@implementation AppController

- (void)awakeFromNib {
	[window setContentBorderThickness:24 forEdge:NSMinYEdge];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)app {
	return YES;
}

@end
