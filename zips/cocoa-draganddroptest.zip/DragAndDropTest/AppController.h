//
//  AppController.h
//  DragAndDropTest
//
//  Created by Matteo Bertozzi on 2/28/09.
//  Copyright 2009 Matteo Bertozzi. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class FileDropView;

@interface AppController : NSObject {
	IBOutlet NSWindow *window;
}

@end
