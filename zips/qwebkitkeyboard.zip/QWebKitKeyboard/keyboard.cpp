#include <QSignalMapper>
#include <QPushButton>
#include <QGridLayout>

#include "keyboard.h"

/* ============================================================================
 *  PUBLIC Constructor/Destructor
 */
KeyboardWidget::KeyboardWidget (QWidget *parent)
	: QWidget(parent)
{
	setupKeyboard();
}

KeyboardWidget::~KeyboardWidget() {
}

/* ============================================================================
 *  PRIVATE Methods
 */
void KeyboardWidget::setupKeyboard (void) {
	QString keys[4][10] = {
		{ "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" },
		{ "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P" },
		{ "+", "A", "S", "F", "G", "H", "J", "K", "L", "@" },
		{ "-", "_", "Z", "X", "C", "V", "B", "N", "M", "." }
	};

	// Setup Signal Mapper
	QSignalMapper *signalMapper = new QSignalMapper;
	connect(signalMapper, SIGNAL(mapped(const QString&)),
			this, SIGNAL(keySelected(const QString&)));

	// Setup Layout
	QGridLayout *layout = new QGridLayout;
	setLayout(layout);

	// Setup Virtual Keyboard
	for (int i = 0; i < 4; ++i) {
		for (int j = 0; j < 10; ++j) {
			QPushButton *button = new QPushButton(keys[i][j]);
			connect(button, SIGNAL(clicked()), signalMapper, SLOT(map()));
			signalMapper->setMapping(button, keys[i][j]);

			layout->addWidget(button, i, j);
		}
	}
}

