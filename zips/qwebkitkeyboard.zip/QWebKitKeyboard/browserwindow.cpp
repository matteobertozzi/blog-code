#include <QVBoxLayout>
#include <QLineEdit>

#include "browserwindow.h"
#include "keyboard.h"
#include "webview.h"

/* ============================================================================
 *  PRIVATE Class
 */
class BrowserWindowPrivate {
	public:
		QString formId;
		QString formName;
		QString formAction;
		QString inputType;
		QString inputId;							
		QString inputName;

		KeyboardWidget *keyboard;
		QLineEdit *urlEdit;
		WebView *webView;
};

/* ============================================================================
 *  PUBLIC Constructor/Destructor
 */
BrowserWindow::BrowserWindow (QWidget *parent)
	: QWidget(parent), d(new BrowserWindowPrivate)
{
	// Setup URL Edit
	d->urlEdit = new QLineEdit;
	connect(d->urlEdit, SIGNAL(returnPressed()),
			this, SLOT(urlEditingFinished()));

	// Setup Keyboard
	d->keyboard = new KeyboardWidget;
	d->keyboard->setVisible(false);
	connect(d->keyboard, SIGNAL(keySelected(const QString&)),
			this, SLOT(keySelected(const QString&)));

	// Setup WebView
	d->webView = new WebView;
	connect(d->webView, SIGNAL(inputFormFocused(const QString&, const QString&, 
				const QString&, const QString&, const QString&, const QString&)),
			this, SLOT(inputFormFocused(const QString&, const QString&, 
				const QString&, const QString&, const QString&, const QString&)));
	connect(d->webView, SIGNAL(inputFormLostFocus()), d->keyboard, SLOT(hide()));

	// Setup Layout
	QVBoxLayout *layout = new QVBoxLayout;
	layout->addWidget(d->urlEdit);
	layout->addWidget(d->webView);
	layout->addWidget(d->keyboard);
	setLayout(layout);
}

BrowserWindow::~BrowserWindow() {
	delete d;
}

/* ============================================================================
 *  PUBLIC Slots
 */
void BrowserWindow::load (const QString& url) {
	d->urlEdit->setText(url);
	d->webView->load(url);
}

/* ============================================================================
 *  PRIVATE Slots
 */
void BrowserWindow::inputFormFocused (	const QString& formId,
										const QString& formName,
										const QString& formAction,
										const QString& inputType,
										const QString& inputId,							
										const QString& inputName)
{
	d->formId = formId;
	d->formName = formName;
	d->formAction = formAction;
	d->inputType = inputType;
	d->inputId = inputId;
	d->inputName = inputName;
	d->keyboard->setVisible(true);
}

void BrowserWindow::keySelected (const QString& key) {
	d->webView->formFocusedAddValue(d->formId,
									d->formName,
									d->formAction,
									d->inputType,
									d->inputId,
									d->inputName,
									key);
}

void BrowserWindow::urlEditingFinished (void) {
	d->webView->load(d->urlEdit->text());
}

