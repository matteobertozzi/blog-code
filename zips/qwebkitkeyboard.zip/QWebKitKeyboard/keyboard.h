#ifndef _KEYBOARD_WIDGET_H_
#define _KEYBOARD_WIDGET_H_

#include <QWidget>

class KeyboardWidget : public QWidget {
	Q_OBJECT

	public:
		KeyboardWidget (QWidget *parent = 0);
		~KeyboardWidget();

	Q_SIGNALS:
		void keySelected (const QString& key);

	private:
		void setupKeyboard (void);
};

#endif /* !_KEYBOARD_WIDGET_H_ */

