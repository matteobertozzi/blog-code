#include <QWebFrame>
#include "webview.h"

/* ============================================================================
 *  PUBLIC Constructor/Destructor
 */
WebView::WebView (QWidget *parent) 
	: QWebView(parent)
{
	connect(page()->mainFrame(), SIGNAL(javaScriptWindowObjectCleared()),
			this, SLOT(populateJavaScriptWindowObject()));
	connect(this, SIGNAL(loadFinished(bool)), this, SLOT(onLoadFinished(bool)));
}

WebView::~WebView() {
}

/* ============================================================================
 *  PUBLIC Slots
 */
void WebView::formFocusedAddValue (	const QString& formId,
									const QString& formName,
									const QString& formAction,
									const QString& inputType,
									const QString& inputId,
									const QString& inputName,
									const QString& value)
{
	QString scriptSource;
	
	if (!inputId.isEmpty()) {
		scriptSource = "document.getElementById('" + inputId + "').value += '" + value + "';";
	} else if (!formId.isEmpty()) {
		scriptSource = 
			"var inputList = document.getElementById('" + formId + "').getElementsByTagName('" + inputType + "');"
			"for (var i = 0; i < inputList.length; ++i) {"
				"if (inputList[i].name == '" + inputName + "') {"
					"inputList[i].value += '" + value + "';"
					"break;"
				"}"
			"}";
	} else if (!formAction.isEmpty()) {
		scriptSource = 
			"var formList = document.getElementsByTagName('form');"
			"for (var i = 0; i < formList.length; ++i) {"
				"if (formList[i].action == '" + formAction + "') {"
					"var inputList = formList[i].getElementsByTagName('" + inputType + "');"
					"for (var j = 0; j < inputList.length; ++j) {"
						"if (inputList[j].name == '" + inputName + "') {"
							"inputList[j].value += '" + value + "';"
							"break;"
						"}"
					"}"
					"break;"
				"}"
			"}";
	} else if (!formName.isEmpty()) {
		scriptSource = 
			"var formList = document.getElementsByTagName('form');"
			"for (var i = 0; i < formList.length; ++i) {"
				"if (formList[i].name == '" + formName + "') {"
					"var inputList = formList[i].getElementsByTagName('" + inputType + "');"
					"for (var j = 0; j < inputList.length; ++j) {"
						"if (inputList[j].name == '" + inputName + "') {"
							"inputList[j].value += '" + value + "';"
							"break;"
						"}"
					"}"
					"break;"
				"}"
			"}";
	} else {
		scriptSource = 
			"var inputList = document.getElementsByTagName('" + inputType + "');"
			"for (var i = 0; i < inputList.length; ++i) {"
				"if (inputList[i].name == '" + inputName + "') {"
					"inputList[i].value += '" + value + "';"
					"break;"
				"}"
			"}";
	}
	
	page()->mainFrame()->evaluateJavaScript(scriptSource);
}

void WebView::formFocused (	const QString& formId,
							const QString& formName,
							const QString& formAction,
							const QString& inputType,
							const QString& inputId,
							const QString& inputName)
{
	emit inputFormFocused(formId, formName, formAction, inputType, inputId, inputName);
}

void WebView::formLostFocus (void) {
	emit inputFormLostFocus();
}

/* ============================================================================
 *  PRIVATE Slots
 */
void WebView::onLoadFinished (bool ok) {
	if (ok) {
		addFormsFocusEvent();
	}
}

void WebView::populateJavaScriptWindowObject (void) {
	page()->mainFrame()->addToJavaScriptWindowObject("__qWebViewWidget", this);
}

/* ============================================================================
 *  PRIVATE Methods
 */
void WebView::addFormsFocusEvent (void) {
	QString scriptSource =
		"function addFocusHandler(tagName) {"
			"var inputList = document.getElementsByTagName(tagName);"
			"for (var i = 0; i < inputList.length; ++i) {"
				"var formAction = inputList[i].form.action;"
				"var formName = inputList[i].form.name;"
				"var formId = inputList[i].form.id;"
				"var inputName = inputList[i].name;"				
				"var inputId = inputList[i].id;"						
				
				"if (tagName == 'input') {"
					"var inputType = inputList[i].type;"
					"if (inputType != 'password' && inputType != 'text')"
						"continue;"
				"}"

				"inputList[i].setAttribute('onclick', \"__qWebViewWidget.formFocused('\" + formId + \"', '\" + formName + \"', '\" + formAction + \"','\" + tagName + \"','\" + inputId + \"','\" + inputName + \"')\");"
				"inputList[i].setAttribute('onblur', '__qWebViewWidget.formLostFocus()');"
			"}"
		"}"
		"addFocusHandler('input');"
		"addFocusHandler('textarea');";

	page()->mainFrame()->evaluateJavaScript(scriptSource);
}

