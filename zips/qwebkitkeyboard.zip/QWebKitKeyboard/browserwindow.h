#ifndef _BROWSER_WINDOW_H_
#define _BROWSER_WINDOW_H_

#include <QWidget>
class BrowserWindowPrivate;

class BrowserWindow : public QWidget {
	Q_OBJECT

	public:
		BrowserWindow (QWidget *parent = 0);
		~BrowserWindow();

	public Q_SLOTS:
		void load (const QString& url);

	private Q_SLOTS:
		void inputFormFocused (	const QString& formId,
								const QString& formName,
								const QString& formAction,
								const QString& inputType,
								const QString& inputId,							
								const QString& inputName);

		void keySelected (const QString& key);

		void urlEditingFinished (void);

	private:
		BrowserWindowPrivate *d;
};

#endif /* !_BROWSER_WINDOW_H_ */

