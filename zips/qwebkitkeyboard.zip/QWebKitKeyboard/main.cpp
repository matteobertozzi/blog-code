#include <QApplication>
#include "browserwindow.h"

int main (int argc, char **argv) {
	QApplication app(argc, argv);

	BrowserWindow window;
	window.load("http://www.google.com");
	window.show();

	return(app.exec());
}

