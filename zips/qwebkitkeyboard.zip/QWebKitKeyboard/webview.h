#ifndef _WEBVIEW_H_
#define _WEBVIEW_H_

#include <QWebView>

class WebView : public QWebView {
	Q_OBJECT

	public:
		WebView (QWidget *parent = 0);
		~WebView();

	Q_SIGNALS:
		void inputFormFocused (	const QString& formId,
								const QString& formName,
								const QString& formAction,
								const QString& inputType,
								const QString& inputId,							
								const QString& inputName);

		void inputFormLostFocus (void);

	public Q_SLOTS:
		void formLostFocus (void);

		void formFocused (	const QString& formId,
							const QString& formName,
							const QString& formAction,
							const QString& inputType,
							const QString& inputId,							
							const QString& inputName);

		void formFocusedAddValue (	const QString& formId,
									const QString& formName,
									const QString& formAction,
									const QString& inputType,
									const QString& inputId,
									const QString& inputName,
									const QString& value);

	private Q_SLOTS:
		void onLoadFinished (bool ok);
		void populateJavaScriptWindowObject (void);

	private:
		void addFormsFocusEvent (void);
};

#endif /* !_WEBVIEW_H_ */

